<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1" />
    <link rel="icon" href="../img/logo.png">
    <title>Pet Pro care | Nurse Page</title>
    <link rel="stylesheet" href="../css/swiper.css">
    <link rel="stylesheet" href="../css/jquery.scrollbar.css">
    <link rel="stylesheet" href="../css/daterangepicker.css">
    <link rel="stylesheet" href="../css/select2.css">
    <link rel="stylesheet" href="../css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="../css/dashboard.min.css">
    <link rel="icon" href="../img/logo.png">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
</head>
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure the user is logged in by checking `staff_id`
if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php");
    exit();
}

// Ensure the user is logged in by checking `staff_id`
if (isset($_SESSION['staff_id'])) {
    $staff_id = $_SESSION['staff_id'];

    // Fetch staff information from the database
    $stmt_staff = $_db->prepare("SELECT * FROM staff WHERE staffID = :staff_id");
    $stmt_staff->bindParam(':staff_id', $staff_id, PDO::PARAM_INT);
    $stmt_staff->execute();
    $staff = $stmt_staff->fetch(PDO::FETCH_OBJ);

    if (!$staff) {
        echo "Staff data not found.";
        exit();
    }
} else {
    echo "Staff ID is not set.";
    exit();
}

$staff_id = $_SESSION['staff_id'];
if (isset($staff) && $staff) {
    $profilePhoto = htmlspecialchars($staff->profilePhoto ?? 'unknown.jpg');
} else {
    $profilePhoto = 'unknown.jpg'; // Default photo if $staff is not set
}


$staff_id = $_SESSION['staff_id'];
// Assuming you have fetched the staff details
$_SESSION['profilePhoto'] = $staff->profilePhoto;

?>

<body>


    <div class="dashboard-wrap">

        <header class="sidebar-header">
            <h1 class="sidebar-header__logo">Pet<span>pro<strong>care</strong></span></h1>
        </header>

        <!-- Section sidebar -->
        <div class="section section--sidebar" id="sidebar">

            <nav class="sidebar-menu">
                <ul>
                    <li class="dashboard"><a href="../nurse/nrDashBoard.php"><b>Dashboard</b></a></li>
                    <li class="components has-submenu"><a href="../nurse/nrReport.php"><b>Components<span class="submenu-arrow"></span></b></a>
                        <ul class="sidebar-menu__submenu">
                            <li><a href="#">Charts</a></li>
                        </ul>
                    </li>
                    <li class="appointment"><a href="../nurse/nrMakeAppointment.php"><b>Appointments</b></a></li>
                    <li class="doctors has-submenu"><a href="../nurse/nrViewDoctor.php"><b>Doctors<span class="submenu-arrow"></span></b></a>
                    </li>
                 
                    <li class="logout"><a href="../nurse/nrViewMedicine.php"><b>View Medicine</b></a></li>
                    <li class="logout"><a href="../logout.php"><b>Logout</b></a></li>
                </ul>
            </nav>

        </div>

        <div class="section section--content" id="content">
            <header class="content-header">

                <div class="sidebar-resize"></div>
                <div class="mobile-menu">
                    <div class="st-burger-icon st-burger-icon--medium"><span></span></div>
                </div>

                <div class="content-header__user content-header__dropdown">
                    <div class="content-header__user-avatar content-header__dropdown-activate" data-dropdown="userdropdown">
                        <div class="content-header__user-thumb">
                            <img src="../img/staffPhoto/<?= htmlspecialchars($_SESSION['profilePhoto'] ?? 'unknown1.jpg') ?>" alt="Profile Photo" title="<?= htmlspecialchars($_SESSION['name'] ?? 'Staff Member') ?>" />
                        </div>
                        <span class="content-header__user-name"><?= htmlspecialchars($_SESSION['name'] ?? 'Staff Member') ?></span>
                    </div>
                    <nav class="dropdown-menu dropdown-menu--header dropdown-menu--user-menu " id="userdropdown">
                        <h3 class="dropdown-menu__subtitle">User menu</h3>
                        <ul>
                            <li><a href="../nurse/nrProfile.php">My profile</a></li>
                            <li><a href="#">Activity</a></li>
                            <li><a href="#">Switch account</a></li>
                            <li><a href="#">Support</a></li>
                            <li class="logout"><a href="../logout.php" class="button button--general button--red-border">Logout</a></li>
                        </ul>
                    </nav>
                </div>

                <div class="content-header__notifications content-header__dropdown">
                    <div class="content-header__notifications-icon content-header__icon content-header__dropdown-activate" data-dropdown="notificationsdropdown">
                        <img src="../img/icon/icons-24-gray/notifications.png" alt="" title="" />
                        <span class="content-header__icon-bubble">6</span>
                    </div>
                    <nav class="dropdown-menu dropdown-menu--header dropdown-menu--notifications-menu" id="notificationsdropdown">
                        <h3 class="dropdown-menu__subtitle">You have <strong>6</strong> notifications</h3>
                        <ul>
                            <li class="d-flex justify-sb"><span class="important">IMPORTANT</span>Michael D. kidney surgery <b class="task-time">today</b></li>
                            <li class="d-flex justify-sb"><span class="important">IMPORTANT</span>FLU Alert report generated <b class="task-time">today</b></li>

                            <li class="d-flex justify-sb"><span>Meeting with <strong>Dr. Joshua</strong> </span> <b class="task-time">tomorrow</b></li>
                            <li class="d-flex justify-sb"><span>Remember to create prescriptions for <strong>Alexander P.</strong></span> <b class="task-time">tomorrow</b></li>
                            <li class="d-flex justify-sb"><span><strong>Jada Sacks</strong> canceled the appointment at Cardiology, Dr. Michael V. </span> <b class="task-time">24 jan, 19</b></li>
                            <li class="d-flex justify-sb"><span>Sarah D. registered as new patient of <strong>Dr. George</strong> at Dermatology </span> <b class="task-time">28 jan, 19</b></li>
                            <li class="view-all"><a href="#" class="button button--general button--blue-border">View all</a></li>
                        </ul>
                    </nav>
                </div>

                <div class="content-header__quicklinks content-header__dropdown">
                    <div class="content-header__quicklinks-icon content-header__icon content-header__dropdown-activate" data-dropdown="quicklinksdropdown">
                        <img src="../img/icon/icons-24-gray/submenu.png" alt="" title="" />
                    </div>
                    <nav class="dropdown-menu dropdown-menu--header dropdown-menu--quicklinks-menu" id="quicklinksdropdown">
                        <h3 class="dropdown-menu__subtitle">Quick links</h3>
                        <ul>
                            <li><a href="#">Add new doctor</a></li>
                            <li><a href="#">Add new patient</a></li>
                            <li><a href="#">Generate reports</a></li>
                        </ul>
                    </nav>
                </div>

                <div class="mobile-submenu"></div>

                <nav class="content-header__menu">
                    <ul>
                        <li class="appointment selected modal-toggle" data-openpopup="appointment"><a href="../appointment.php">Make an appointment</a></li>
                        <li class="prescription modal-toggle" data-openpopup="prescription"><a href="#">Write a prescription</a></li>
                        <li class="reports modal-toggle" data-openpopup="reports"><a href="#">Generate report</a></li>
                    </ul>
                </nav>

            </header>
            <div class="content-subheader">

                <div class="content-subheader__titles">

                    <nav class="content-subheader__breadcrumb-menu">
                        <ul>
                            <li><a href="../nurse/nrDashBoard.php">Dashboard</a></li>
                        </ul>
                    </nav>
                </div>


                <div class="content-subheader__options">

                    <div class="content-subheader__buttons">
                        <a href="#" class="button button--blue-border button--general selected">Daily</a>
                        <a href="#" class="button button--blue-border button--general">Monthly</a>
                    </div>

                    <div class="content-subheader__switcher switcher">
                        <div class="switcher__buttons">
                            <div class="switcher__button switcher__button--enabled">All</div>
                            <div class="switcher__button">Urgent</div>
                            <div class="switcher__border"></div>
                        </div>
                    </div>

                    <div class="content-subheader__dropdown" id="reportrange">
                        <span class="content-subheader__more show-more show-more--select show-more--select-gray"></span>
                    </div>

                    <div class="content-subheader__slider-nav">
                        <div class="timeline__button--next swiper-button-next"></div>
                        <div class="timeline__button--prev swiper-button-prev"></div>
                    </div>

                </div>

            </div>
            <script src="../js/jquery-3.3.1.min.js"></script>
            <script src="../js/Chart.min.js"></script>
            <script src="../js/chartjs-plugin-style.min.js"></script>
            <script src="../js/charts-custom-dashboard.js"></script>
            <script src="../js/moment.min.js"></script>
            <script src="../js/calendar.js"></script>
            <script src="../js/swiper.min.js"></script>
            <script src="../js/select2.min.js"></script>
            <script src="../js/jquery.scrollbar.js"></script>
            <script src="../js/jquery.countdown.min.js"></script>
            <script src="../js/daterangepicker.min.js"></script>
            <script src="../js/ion.rangeSlider.min.js"></script>
            <script src="../js/jquery.dashboard-custom.js"></script>
</body>

</html>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle user menu dropdown
        const userDropdownActivator = document.querySelector('[data-dropdown="userdropdown"]');
        const userDropdown = document.getElementById('userdropdown');

        if (userDropdownActivator && userDropdown) {
            userDropdownActivator.addEventListener('click', function() {
                userDropdown.classList.toggle('active'); // Assuming you have CSS for 'active' class
            });
        }

        // Toggle notifications dropdown
        const notificationsDropdownActivator = document.querySelector('[data-dropdown="notificationsdropdown"]');
        const notificationsDropdown = document.getElementById('notificationsdropdown');

        if (notificationsDropdownActivator && notificationsDropdown) {
            notificationsDropdownActivator.addEventListener('click', function() {
                notificationsDropdown.classList.toggle('active');
            });
        }

        // Toggle quick links dropdown
        const quicklinksDropdownActivator = document.querySelector('[data-dropdown="quicklinksdropdown"]');
        const quicklinksDropdown = document.getElementById('quicklinksdropdown');

        if (quicklinksDropdownActivator && quicklinksDropdown) {
            quicklinksDropdownActivator.addEventListener('click', function() {
                quicklinksDropdown.classList.toggle('active');
            });
        }
    });


    function navigateSlides(direction) {
        const visibleSlides = Array.from(slides).filter(slide => slide.style.display !== "none");

        if (visibleSlides.length === 0) return; // No slides visible

        currentSlideIndex = (currentSlideIndex + direction + visibleSlides.length) % visibleSlides.length;

        visibleSlides.forEach((slide, index) => {
            if (index === currentSlideIndex) {
                slide.scrollIntoView({
                    behavior: "smooth",
                    block: "center"
                });
            }
        });
    }

    function filterAppointmentsByRange(startDate, endDate) {
        let hasVisibleSlides = false;

        slides.forEach(slide => {
            const slideDate = new Date(slide.getAttribute("data-date"));
            if (slideDate >= startDate && slideDate <= endDate) {
                slide.style.display = "block";
                hasVisibleSlides = true;
            } else {
                slide.style.display = "none";
            }
        });

        if (!hasVisibleSlides) {
            alert("No appointments found in the selected range.");
        }
    }
    const filterButtons = document.querySelectorAll(".content-subheader__buttons .button");
    filterButtons.forEach(button => {
        button.addEventListener("click", function() {
            filterButtons.forEach(btn => btn.classList.remove("selected"));
            this.classList.add("selected");
        });
    });
    $("#customRange").daterangepicker({
        opens: 'left',
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, function(start, end) {
        filterAppointmentsByRange(new Date(start.format('YYYY-MM-DD')), new Date(end.format('YYYY-MM-DD')));
    });
</script>

<noscript>
    <div style="background-color: #ffcccc; padding: 10px; text-align: center;">
        This site requires JavaScript to function properly. Please enable JavaScript in your browser settings.
    </div>
</noscript>