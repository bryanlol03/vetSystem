<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/design.css">
    <link rel="icon" href="../img/logo.png">
    <title>Header</title>
</head>
<style>
    
    .notification_dropdown {
        display: none;
        position: absolute;
        top: 30px;
        right: 0;
        background-color: white;
        border: 1px solid #ddd;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        width: 300px;
        z-index: 1000;
        max-height: 400px;
        overflow-y: auto;
    }

    .notification_dropdown h4 {
        margin: 0;
        padding: 10px;
        background-color: #007BFF;
        color: white;
        text-align: center;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
    }

    .notification_dropdown .notification_item {
        padding: 10px;
        border-bottom: 1px solid #ddd;
    }

    .notification_dropdown .notification_item:last-child {
        border-bottom: none;
    }

    .notification_dropdown .notification_item p {
        margin: 0;
        font-size: 16px;
    }

    .notification_dropdown .notification_item a {
        color: #007BFF;
        text-decoration: none;
    }

    .notification_dropdown .notification_item a:hover {
        text-decoration: underline;
    }
</style>
<?php
include_once __DIR__ . '/../_base.php'; // Ensure the correct path

$is_logged_in = isset($_SESSION['user_id']);
$username = $is_logged_in ? htmlspecialchars($_SESSION['username']) : null;

// Set profile photo or fallback to 'unknown1.jpg'
$profile_photo = $is_logged_in && !empty($_SESSION['profile_photo']) && file_exists("../img/userPhoto/" . $_SESSION['profile_photo'])
    ? htmlspecialchars($_SESSION['profile_photo'])
    : 'unknown1.jpg';

$profile_photo_url = "../img/userPhoto/" . $profile_photo;

if ($is_logged_in) {
    $user_id = $_SESSION['user_id'];

    // Fetch unread notifications
    $query = "
    SELECT message, is_read, created_at
    FROM notifications
    WHERE petOwnerID = :user_id AND is_read = 'No'
    ORDER BY created_at DESC
";

    $stmt = $_db->prepare($query);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $notifications = [];
}
?>

<body>
    <header class="header">
        <nav class="nav container">
            <div class="nav__data">
                <a href="../index.php" class="nav__logo">
                    <i class="fas fa-paw" style="font-size:30px"></i> PetPro Care
                </a>
                <div class="nav__toggle" id="nav-toggle">
                    <i class="ri-menu-line nav__toggle-menu"></i>
                    <i class="ri-close-line nav__toggle-close"></i>
                </div>
            </div>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li><a href="../user/calendar.php" class="nav__link">Calendar</a></li>
                    <li><a href="../queue.php" class="nav__link">Queue</a></li>
                    <li><a href="../user/appointmentHistory.php" class="nav__link">Appointment History</a></li>

                    <li><a href="../contactUs.php" class="nav__link">Contact Us</a></li>
                    <li><a href="../aboutUs.php" class="nav__link">About Us</a></li>

                    <!-- Notification Icon -->
                    <li>
                        <div class="notification_icon">
                            <i class="ri-notification-3-line" onclick="toggleNotificationDropdown()"></i>
                            <span id="notificationCount" class="badge">
                                <?= htmlspecialchars(count(array_filter($notifications, fn($n) => $n['is_read'] === 'No'))) ?>
                            </span>
                            <div id="notificationDropdown" class="notification_dropdown">
                                <h4>Notifications</h4>
                                <div id="notificationList">
                                    <?php if (!empty($notifications)): ?>
                                        <?php foreach ($notifications as $notification): ?>
                                            <div class="notification_item">
                                                <p>
                                                    <?= htmlspecialchars($notification['message']) ?>
                                                    <?php if (!empty($notification['serviceName'])): ?>
                                                        (Service: <?= htmlspecialchars($notification['serviceName']) ?>)
                                                    <?php endif; ?>
                                                </p>
                                                <a href="../reschedule.php">Reschedule</a>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <p>No new notifications.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </li>

                    <?php if ($is_logged_in): ?>
                        <li class="dropdown__item">
                            <div class="nav_link dropdown_button">
                                <img src="<?= $profile_photo_url ?>" alt="Profile Photo" class="profile-photo" width="30" height="30" style="border-radius: 50%;">
                                <?= htmlspecialchars($username) ?>
                                <i class="ri-arrow-down-s-line dropdown__arrow"></i>
                            </div>
                            <div class="dropdown__container">
                                <div class="dropdown__content">
                                    <ul class="dropdown__list">
                                        <li><a href="../user/profile.php" class="dropdown__link">Profile</a></li>
                                        <li><a href="../logout.php" class="dropdown__link">Logout</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    <?php else: ?>
                        <li><a href="../login.php" class="nav__link"><img src="../img/login icon.png" width="50" height="50"></a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </header>

    <script>
        function toggleNotificationDropdown() {
            const dropdown = document.getElementById('notificationDropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notificationDropdown');
            const icon = document.querySelector('.notification_icon i');
            if (!dropdown.contains(event.target) && event.target !== icon) {
                dropdown.style.display = 'none';
            }
        });

        const showMenu = (toggleId, navId) => {
            const toggle = document.getElementById(toggleId),
                nav = document.getElementById(navId);

            if (toggle && nav) {
                toggle.addEventListener('click', () => {
                    nav.classList.toggle('show-menu');
                    toggle.classList.toggle('show-icon');
                });
            }
        };

        showMenu('nav-toggle', 'nav-menu');
    </script>
</body>

</html>