<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1" />
    <link rel="icon" href="../img/logo.png">
    <title>Pet Pro care | Admin Page</title>
    <link rel="stylesheet" href="../css/swiper.css">
    <link rel="stylesheet" href="../css/jquery.scrollbar.css">
    <link rel="stylesheet" href="../css/daterangepicker.css">
    <link rel="stylesheet" href="../css/select2.css">
    <link rel="stylesheet" href="../css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="../css/dashboard.min.css">
    <link rel="icon" href="../img/logo.png">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
</head>
<?php
include_once '../_base.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure the user is logged in by checking `staff_id`
if (isset($_SESSION['staff_id'])) {
    $staff_id = $_SESSION['staff_id'];

    // Fetch staff information from the database
    $stmt_staff = $_db->prepare("SELECT * FROM staff WHERE staffID = :staff_id");
    $stmt_staff->bindParam(':staff_id', $staff_id, PDO::PARAM_INT);
    $stmt_staff->execute();
    $staff = $stmt_staff->fetch(PDO::FETCH_OBJ);

    // Check if the staff data is found
    if (!$staff) {
        echo "Staff data not found.";
        exit();
    }
} else {
    echo "Staff ID is not set.";
    exit();
}

// Ensure $staff is set and not null
if (isset($staff) && $staff) {
    $profilePhoto = htmlspecialchars($staff->profilePhoto ?? 'unknown.jpg');
} else {
    $profilePhoto = 'unknown.jpg'; // Default photo if $staff is not set
}

$staff_id = $_SESSION['staff_id'];
$_SESSION['profilePhoto'] = $staff->profilePhoto;
?>

<body>

    <div class="dashboard-wrap">
        <header class="sidebar-header">
            <h1 class="sidebar-header__logo">Pet<span>pro<strong>care</strong></span></h1>
        </header>

        <div class="section section--sidebar" id="sidebar">
            <nav class="sidebar-menu">
                <ul>
                    <li class="dashboard"><a href="../admin/adDashboard.php"><b>Dashboard</b></a></li>
                    <li class="components has-submenu"><a href="../admin/adReport.php"><b>Components<span class="submenu-arrow"></span></b></a>
                        <ul class="sidebar-menu__submenu">
                            <li><a href="../admin/adReport.php">Charts</a></li>
                        </ul>
                    </li>
                    <li class="appointment"><a href="../admin/adAppointment.php"><b>Appointments</b></a></li>
                    <li class="doctors has-submenu"><a href="../admin/adManageDoctor.php"><b>Doctors<span class="submenu-arrow"></span></b></a>
                        <ul class="sidebar-menu__submenu">
                            <li><a href="../admin/adManageDoctor.php">Manage Doctor</a></li>
                            <li><a href="../admin/adAddDoctor.php">Add Doctor</a></li>
                        </ul>
                    </li>
                    <li class="patients has-submenu"><a href="../admin/adManageUser.php"><b>Patients<span class="submenu-arrow"></span></b></a>
                        <ul class="sidebar-menu__submenu">
                            <li><a href="../admin/adAddPatient.php">Add new patient</a></li>
                            <li><a href="../admin/adManagePatient.php">View all patients</a></li>
                        </ul>
                    </li>
                    <li class="inbox"><a href="../admin/adManageService.php"><b>Service</b></a></li>
                    <li class="inbox"><a href="../admin/adGeneratePayment.php"><b>Generate Payment<span class="submenu-bubble">3</span></b></a></li>
                    <li class="logout"><a href="../admin/adListSchedule.php"><b>Schedule</b></a></li>
                </ul>
            </nav>

        </div>

        <div class="section section--content" id="content">
            <header class="content-header">

                <div class="sidebar-resize"></div>
                <div class="mobile-menu">
                    <div class="st-burger-icon st-burger-icon--medium"><span></span></div>
                </div>

                <div class="content-header__user content-header__dropdown">
                    <div class="content-header__user-avatar content-header__dropdown-activate" data-dropdown="userdropdown">
                        <div class="content-header__user-thumb">
                            <img src="../img/staffPhoto/<?= htmlspecialchars($_SESSION['profilePhoto'] ?? 'unknown1.jpg') ?>" alt="Profile Photo" title="<?= htmlspecialchars($_SESSION['name'] ?? 'Staff Member') ?>" />

                        </div>
                        <span class="content-header__user-name"><?= htmlspecialchars($_SESSION['name'] ?? 'Staff Member') ?></span>
                    </div>
                    <nav class="dropdown-menu dropdown-menu--header dropdown-menu--user-menu " id="userdropdown">
                        <h3 class="dropdown-menu__subtitle">User menu</h3>
                        <ul>
                            <li><a href="../admin/adProfile.php">My profile</a></li>
                            <li><a href="#">Activity</a></li>
                            <li><a href="#">Switch account</a></li>
                            <li><a href="#">Support</a></li>
                            <li class="logout"><a href="../logout.php" class="button button--general button--red-border">Logout</a></li>
                        </ul>
                    </nav>
                </div>

                <div class="content-header__notifications content-header__dropdown">
                    <div class="content-header__notifications-icon content-header__icon content-header__dropdown-activate" data-dropdown="notificationsdropdown">
                        <img src="../img/icon/icons-24-gray/notifications.png" alt="" title="" />
                        <span class="content-header__icon-bubble">6</span>
                    </div>
                    <nav class="dropdown-menu dropdown-menu--header dropdown-menu--notifications-menu" id="notificationsdropdown">
                        <h3 class="dropdown-menu__subtitle">You have <strong>6</strong> notifications</h3>
                        <ul>
                            <li class="d-flex justify-sb"><span class="important">IMPORTANT</span>Michael D. kidney surgery <b class="task-time">today</b></li>
                            <li class="d-flex justify-sb"><span class="important">IMPORTANT</span>FLU Alert report generated <b class="task-time">today</b></li>

                            <li class="d-flex justify-sb"><span>Meeting with <strong>Dr. Joshua</strong> </span> <b class="task-time">tomorrow</b></li>
                            <li class="d-flex justify-sb"><span>Remember to create prescriptions for <strong>Alexander P.</strong></span> <b class="task-time">tomorrow</b></li>
                            <li class="d-flex justify-sb"><span><strong>Jada Sacks</strong> canceled the appointment at Cardiology, Dr. Michael V. </span> <b class="task-time">24 jan, 19</b></li>
                            <li class="d-flex justify-sb"><span>Sarah D. registered as new patient of <strong>Dr. George</strong> at Dermatology </span> <b class="task-time">28 jan, 19</b></li>
                            <li class="view-all"><a href="#" class="button button--general button--blue-border">View all</a></li>
                        </ul>
                    </nav>
                </div>

                <div class="content-header__quicklinks content-header__dropdown">
                    <div class="content-header__quicklinks-icon content-header__icon content-header__dropdown-activate" data-dropdown="quicklinksdropdown">
                        <img src="../img/icon/icons-24-gray/submenu.png" alt="" title="" />
                    </div>
                    <nav class="dropdown-menu dropdown-menu--header dropdown-menu--quicklinks-menu" id="quicklinksdropdown">
                        <h3 class="dropdown-menu__subtitle">Quick links</h3>
                        <ul>
                            <li><a href="../admin/adAddDoctor.php">Add new doctor</a></li>
                            <li><a href="../admin/adAddPatient.php">Add new patient</a></li>
                            <li><a href="../admin/adReport.php">Generate reports</a></li>
                        </ul>
                    </nav>
                </div>

                <div class="mobile-submenu"></div>

                <nav class="content-header__menu">
                    <ul>
                        <li class="appointment selected modal-toggle" data-openpopup="appointment"><a href="../admin/adAppointment.php">Make an appointment</a></li>
                        <li class="prescription modal-toggle"><a href="../admin/adOnlineQueue.php">Manage Queue</a></li>
                        <!-- <li class="reports modal-toggle" data-openpopup="reports"><a href="#">Generate report</a></li> -->
                    </ul>
                </nav>

            </header>
            <div class="content-subheader">

                <div class="content-subheader__titles">

                    <nav class="content-subheader__breadcrumb-menu">
                        <ul>
                            <li><a href="../admin/adDashboard.php">Dashboard</a></li>
                        </ul>
                    </nav>
                </div>


                <div class="content-subheader__options">

                    <div>
                    </div>
                    <div>
                    </div>

                    <div class="content-subheader__dropdown" id="reportrange">
                        <span class="content-subheader__more show-more show-more--select show-more--select-gray"></span>
                    </div>

                    <div class="content-subheader__slider-nav">
                        <div class="timeline__button--next swiper-button-next"></div>
                        <div class="timeline__button--prev swiper-button-prev"></div>
                    </div>

                </div>

            </div>
            <script src="../js/jquery-3.3.1.min.js"></script>
            <script src="../js/Chart.min.js"></script>
            <script src="../js/chartjs-plugin-style.min.js"></script>
            <script src="../js/charts-custom-dashboard.js"></script>
            <script src="../js/moment.min.js"></script>
            <script src="../js/calendar.js"></script>
            <script src="../js/swiper.min.js"></script>
            <script src="../js/select2.min.js"></script>
            <script src="../js/jquery.scrollbar.js"></script>
            <script src="../js/jquery.countdown.min.js"></script>
            <script src="../js/daterangepicker.min.js"></script>
            <script src="../js/ion.rangeSlider.min.js"></script>
            <script src="../js/jquery.dashboard-custom.js"></script>
</body>

</html>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle user menu dropdown
        const userDropdownActivator = document.querySelector('[data-dropdown="userdropdown"]');
        const userDropdown = document.getElementById('userdropdown');

        if (userDropdownActivator && userDropdown) {
            userDropdownActivator.addEventListener('click', function() {
                userDropdown.classList.toggle('active'); // Assuming you have CSS for 'active' class
            });
        }

        // Toggle notifications dropdown
        const notificationsDropdownActivator = document.querySelector('[data-dropdown="notificationsdropdown"]');
        const notificationsDropdown = document.getElementById('notificationsdropdown');

        if (notificationsDropdownActivator && notificationsDropdown) {
            notificationsDropdownActivator.addEventListener('click', function() {
                notificationsDropdown.classList.toggle('active');
            });
        }

        // Toggle quick links dropdown
        const quicklinksDropdownActivator = document.querySelector('[data-dropdown="quicklinksdropdown"]');
        const quicklinksDropdown = document.getElementById('quicklinksdropdown');

        if (quicklinksDropdownActivator && quicklinksDropdown) {
            quicklinksDropdownActivator.addEventListener('click', function() {
                quicklinksDropdown.classList.toggle('active');
            });
        }
    });
</script>

<noscript>
    <div style="background-color: #ffcccc; padding: 10px; text-align: center;">
        This site requires JavaScript to function properly. Please enable JavaScript in your browser settings.
    </div>
</noscript>
<script>
    $(document).ready(function() {
        // Initialize the date range picker
        $('#reportrange').daterangepicker({
            // Options for the date range picker
            startDate: moment().startOf('day'),
            endDate: moment().endOf('day'),
            locale: {
                format: 'MM/DD/YYYY'
            }
        }, function(start, end) {
            // Callback function when the date range is selected
            console.log("Date range selected: " + start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
            // You can use the selected dates here
        });
    });
</script>