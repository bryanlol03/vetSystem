<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" href="../img/logo.png">
    <title>Footer</title>
</head>

<body>
    <footer>
        <div class="footerContainer">
            <div class="socialIcons">
                <a href="https://www.facebook.com"><i class="fa-brands fa-facebook"></i></a>
                <a href="https://www.instagram.com"><i class="fa-brands fa-instagram"></i></a>
                <a href="https://x.com/?lang=en"><i class="fa-brands fa-twitter"></i></a>
                <a
                    href="https://accounts.google.com/v3/signin/identifier?ifkv=AdF4I77l2djCi5fWXk7euIgup5T9QKr0IGu56o-JO1LJ1v-sns9aV1BpEL9fCvlFncKqqDFXhhR_yQ&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S-1506418317%3A1722836707373259&ddm=0"><i
                        class="fa-brands fa-google-plus"></i></a>
                <a href="https://www.youtube.com/watch?v=omj7BI7f71Y"><i class="fa-brands fa-youtube"></i></a>
            </div>
            <div class="footerNav">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Appointment</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Threatment</a></li>
                </ul>
            </div>
        </div>
        <div class="footerBottom">
            <hr>
            <p>&copy; 2024 Pet Pro Care. Designed by<span class="designer">Shuyen</span>.
                <small>All Right Reserved</small>
            </p>
        </div>

    </footer>
</body>

</html>