<!DOCTYPE html>
<html lang="en">
<?php
include '_base.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle POST request for login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = req('email');
    $password = req('password');

    // Initialize an array to store error messages
    $_SESSION['err'] = [];

    // Validate email input
    if ($email == '') {
        $_SESSION['err']['email'] = 'Email is required';
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['err']['email'] = 'Invalid email format';
    }

    // Validate password input
    if ($password == '') {
        $_SESSION['err']['password'] = 'Password is required';
    }

    // If there are any validation errors, redirect back to login page
    if (!empty($_SESSION['err'])) {
        redirect('login.php');
        exit; // Prevent further execution
    }

    // No validation errors, check the database for pet owner first
    $stm = $_db->prepare('SELECT * FROM petowner WHERE email = ?');
    $stm->execute([$email]);
    $u = $stm->fetch();

    if ($u && $u->password === sha1($password)) {
        // Login as Pet Owner (User)
        $_SESSION['user_id'] = $u->petOwnerID;
        $_SESSION['username'] = $u->username;
        $_SESSION['role'] = 'User'; // Set the role for the pet owner

        // Redirect to the pet owner's homepage
        temp('info', 'Login successfully');
        redirect('../index.php');
        exit;
    } else {
        // Check if user exists in the staff table (Admin, Veterinarian, or Nurse)
        $stm = $_db->prepare('SELECT * FROM staff WHERE email = ?');
        $stm->execute([$email]);
        $staff = $stm->fetch();

        if ($staff) {
            // Check if password matches
            if ($staff->password !== sha1($password)) {
                $_SESSION['err']['login'] = 'Password does not match.';
                redirect('login.php');
                exit;
            }

            // Staff login success
            $_SESSION['staff_id'] = $staff->staffID;
            $_SESSION['username'] = $staff->username;
            $_SESSION['role'] = $staff->role; // Set the role from the staff table

            // Redirect based on staff role
            if ($staff->role === 'Admin') {
                temp('info', 'Admin login successful');
                redirect('admin/adDashboard.php');
            } elseif ($staff->role === 'Veterinarian') {
                temp('info', 'Veterinarian login successful');
                redirect('doctor/docDashboard.php');
            } elseif ($staff->role === 'Nurse') {
                temp('info', 'Nurse login successful');
                redirect('nurse/nrDashBoard.php');
            } else {
                // Handle any other unexpected roles
                $_SESSION['err']['login'] = 'Invalid role detected.';
                redirect('login.php');
            }
            exit;
        } else {
            // If no account is found in either table
            $_SESSION['err']['login'] = 'No account found with that email address.';
            redirect('login.php');
        }
    }
}

// Handle POST request for registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $_err = []; // Initialize the error array
    $username = req('username');
    $email = req('email');
    $password = req('password');
    $confirm = req('confirm');

    // Validate: username
    if (!$username) {
        $_err['username'] = 'Required';
    } else if (strlen($username) > 100) {
        $_err['username'] = 'Maximum 100 characters';
    }

    // Validate: email
    if (!$email) {
        $_err['email'] = 'Required';
    } else if (strlen($email) > 100) {
        $_err['email'] = 'Maximum 100 characters';
    } else if (!is_email($email)) {
        $_err['email'] = 'Invalid email';
    } else if (!is_unique($email, 'petOwner', 'email')) {
        $_err['email'] = 'Email already exists';
    }

    // Validate: password
    if (!$password) {
        $_err['password'] = 'Required';
    } else if (strlen($password) < 5 || strlen($password) > 100) {
        $_err['password'] = 'Between 5-100 characters';
    }

    // Validate: confirm
    if (!$confirm) {
        $_err['confirm'] = 'Required';
    } else if ($confirm != $password) {
        $_err['confirm'] = 'Passwords do not match';
    }

    if (!$_err) {
        // Hash the password using SHA1 (note: SHA1 is less secure than password_hash)
        $hashedPassword = sha1($password);

        // Insert into the database
        $stm = $_db->prepare('
            INSERT INTO petOwner (username, email, password, profile_photo)
            VALUES (?, ?, ?, "unknown.jpg")
        ');
        $stm->execute([$username, $email, $hashedPassword]);

        temp('info', 'Registration successful. You can log in now.');
        redirect('login.php');
        exit;
    } else {
        // Store errors in session
        $_SESSION['err'] = $_err;
        redirect('register.php');
        exit;
    }
}

// ----------------------------------------------------------------------------

$_title = 'User | Register Pet Owner';
?>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../css/login.css" />
    <link rel="icon" href="../img/logo.png">
    <title>Sign Up | Sign In</title>
</head>
<style>
    .error-message {
        color: red;
        font-size: 0.9em;
        margin-top: 5px;
    }

    .social-media {
        display: flex;
        justify-content: center;
        margin-top: 10px;
    }

    .social-icon {
        text-decoration: none;
        margin: 0 10px;
        color: #333;
        /* Change color as needed */
        font-size: 1.5em;
    }
</style>

<body>
    <div class="container">
        <div class="forms-container">
            <div class="signin-signup">
                <form method="POST" class="sign-in-form">
                    <h2 class="title">🏠Login</h2>

                    <!-- Email Input -->
                    <div class="input-field">
                        <i class="fas fa-envelope"></i>
                        <input type="email" name="email" placeholder="Email" required />
                        <?php if (isset($_SESSION['err']['email'])): ?>
                            <span class="error-message"><?= $_SESSION['err']['email']; ?></span>
                            <?php unset($_SESSION['err']['email']); ?>
                        <?php endif; ?>
                    </div>

                    <!-- Password Input -->
                    <div class="input-field">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="password" placeholder="Password" required />
                        <?php if (isset($_SESSION['err']['password'])): ?>
                            <span class="error-message"><?= $_SESSION['err']['password']; ?></span>
                            <?php unset($_SESSION['err']['password']); ?>
                        <?php endif; ?>
                    </div>

                    <!-- Login Error Message -->
                    <?php if (isset($_SESSION['err']['login'])): ?>
                        <div class="error-message"><?= $_SESSION['err']['login']; ?></div>
                        <?php unset($_SESSION['err']['login']); ?>
                    <?php endif; ?>

                    <!-- Forgot Password Link -->
                    <a href="/user/forgotPsw.php" class="forgot-password">Forgot Password?</a>

                    <!-- Login Button -->
                    <input type="submit" name="login" value="Login" class="btn solid" />

                    <!-- Social Media Follow Section -->
                    <p class="social-text">Follow Our Social Media Accounts</p>
                    <div class="social-media">
                        <a href="#" class="social-icon">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="social-icon">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="social-icon">
                            <i class="fab fa-google"></i>
                        </a>
                        <a href="#" class="social-icon">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </div>

                </form>

                <form method="POST" class="sign-up-form">
                    <h2 class="title">🐾Register🐾</h2>

                    <div class="input-field">
                        <i class="fas fa-user"></i>
                        <input type="text" name="username" placeholder="Username" maxlength="100" required />
                        <?php if (isset($_SESSION['err']['username'])): ?>
                            <span class="error-message"><?= $_SESSION['err']['username']; ?></span>
                            <?php unset($_SESSION['err']['username']); ?>
                        <?php endif; ?>
                    </div>

                    <div class="input-field">
                        <i class="fas fa-envelope"></i>
                        <input type="email" name="email" placeholder="Email" maxlength="100" required />
                        <?php if (isset($_SESSION['err']['email'])): ?>
                            <span class="error-message"><?= $_SESSION['err']['email']; ?></span>
                            <?php unset($_SESSION['err']['email']); ?>
                        <?php endif; ?>
                    </div>

                    <div class="input-field">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="password" placeholder="Password" maxlength="100" required />
                        <?php if (isset($_SESSION['err']['password'])): ?>
                            <span class="error-message"><?= $_SESSION['err']['password']; ?></span>
                            <?php unset($_SESSION['err']['password']); ?>
                        <?php endif; ?>
                    </div>

                    <div class="input-field">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="confirm" placeholder="Confirm Password" maxlength="100" required />
                        <?php if (isset($_SESSION['err']['confirm'])): ?>
                            <span class="error-message"><?= $_SESSION['err']['confirm']; ?></span>
                            <?php unset($_SESSION['err']['confirm']); ?>
                        <?php endif; ?>
                    </div>

                    <input type="submit" name="register" class="btn" value="Sign up" />

                    <!-- Social Media Follow Section -->
                    <p class="social-text">Follow Our Social Media Accounts</p>
                    <div class="social-media">
                        <a href="#" class="social-icon">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="social-icon">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="social-icon">
                            <i class="fab fa-google"></i>
                        </a>
                        <a href="#" class="social-icon">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </div>

                </form>
            </div>
        </div>

        <div class="panels-container">
            <div class="panel left-panel">
                <div class="content">
                    <h3>Welcome Back To Pet Pro Care🐈</h3>
                    <p>
                        Wait for what comes to join our members to get exclusive deals!
                    </p>
                    <button class="btn transparent" id="sign-up-btn">
                        Sign up
                    </button>
                </div>
                <img src="../img/catDoc.png" class="image" alt="" />
            </div>
            <div class="panel right-panel">
                <div class="content">
                    <h3>Join PetPro Care Today🐕</h3>
                    <p>
                        Create your account and become a part of PetPro Care. Don’t miss out on special offers and promotions for our valued members!
                    </p>
                    <button class="btn transparent" id="sign-in-btn">
                        Sign in
                    </button>
                </div>
                <img src="../img/dogDoc.jpg" class="image" alt="" />
            </div>
        </div>
    </div>

    <script src="../js/app.js"></script>
</body>

</html>