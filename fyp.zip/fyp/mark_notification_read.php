<?php
include_once '../_base.php'; // Ensure DB is connected

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $user_id = $data['user_id'] ?? null;

    if ($user_id) {
        $markAsReadQuery = "
        UPDATE notifications
        SET is_read = 1
        WHERE user_id = :user_id AND is_read = 0
        ";
        $stmt = $_db->prepare($markAsReadQuery);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Notifications marked as read.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update notifications.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid user ID.']);
    }
}
?>
