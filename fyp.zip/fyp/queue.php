<?php
include '_base.php'; // Include your database configuration

// Number of records per page
$records_per_page = 5;

// Determine the current page from the query string
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$current_page = max($current_page, 1); // Ensure the current page is at least 1

// Calculate the offset for the SQL query
$offset = ($current_page - 1) * $records_per_page;

// Count the total number of records
$count_query = "SELECT COUNT(*) AS total FROM queue";
$total_records = $_db->query($count_query)->fetch(PDO::FETCH_ASSOC)['total'];

// Calculate the total number of pages
$total_pages = ceil($total_records / $records_per_page);

// Fetch the current page records
$query = "SELECT * FROM queue ORDER BY queueID ASC LIMIT :limit OFFSET :offset";
$stmt = $_db->prepare($query);
$stmt->bindParam(':limit', $records_per_page, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle status update when the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['queueID'])) {
    $queueID = (int)$_POST['queueID'];

    // Update the queue record
    $update_query = "UPDATE queue SET queueStatus = 'In Process', estimateWaitTime = 'Anytime', urgentLevel = 'High' WHERE queueID = :queueID";
    $update_stmt = $_db->prepare($update_query);
    $update_stmt->bindParam(':queueID', $queueID, PDO::PARAM_INT);

    if ($update_stmt->execute()) {
        $message = "Queue status updated successfully!";
    } else {
        $message = "Failed to update queue status.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Queue Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tr:nth-child(odd) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .btn {
            display: inline-block;
            padding: 10px 15px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin: 0 5px;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .pagination {
            text-align: center;
            margin: 20px 0;
        }

        .pagination a {
            display: inline-block;
            padding: 8px 12px;
            margin: 0 5px;
            border: 1px solid #ddd;
            text-decoration: none;
            color: #007bff;
        }

        .pagination a:hover {
            background-color: #007bff;
            color: #fff;
        }

        .message {
            text-align: center;
            font-size: 16px;
            margin-bottom: 20px;
            color: green;
        }

        .message.error {
            color: red;
        }
    </style>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User | Queue</title>
    <link rel="icon" href="img/logo.png">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 20px auto;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .status {
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            text-align: center;
            display: inline-block;
        }

        .status.waiting {
            background-color: #ffc107;
            color: #fff;
        }

        .status.in-process {
            background-color: #17a2b8;
            color: #fff;
        }

        .status.completed {
            background-color: #28a745;
            color: #fff;
        }

        .status.high {
            background-color: #dc3545;
            color: #fff;
        }

        .queue-number {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
        }

        .btn {
            display: inline-block;
            margin: 0 10px;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: #ffffff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .btn.danger {
            background-color: #dc3545;
        }

        .btn.danger:hover {
            background-color: #c82333;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Vet Clinic Online Queue</h1>
        <table>
            <thead>
                <tr>
                    <th>Queue Number</th>
                    <th>Status</th>
                    <th>Description</th>
                    <th>Estimated Wait Time</th>
                    <th>Urgent Level</th>
                </tr>
            </thead>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td class="queue-number"><?= htmlspecialchars($row['queueNumber']) ?></td>
                    <td><span class="status <?= strtolower(str_replace(' ', '-', $row['queueStatus'])) ?>"><?= htmlspecialchars($row['queueStatus']) ?></span></td>
                    <td><?= htmlspecialchars($row['description']) ?></td>
                    <td><?= htmlspecialchars($row['estimateWaitTime']) ?></td>
                    <td><?= htmlspecialchars($row['urgentLevel']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php if ($current_page > 1): ?>
                <a href="?page=<?= $current_page - 1 ?>">Previous</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?= $i ?>" class="<?= $i === $current_page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>

            <?php if ($current_page < $total_pages): ?>
                <a href="?page=<?= $current_page + 1 ?>">Next</a>
            <?php endif; ?>
        </div>
    </div>
    <center>
        <a href="index.php" class="btn">Back</a>
        <a href="cutQueue.php" class="btn danger">Request For Cut Queue</a>
    </center>
    </div>
</body>

</html>