<?php
//stripe php
$stripedetails = array(
    "publishableKey" => "pk_test_51QD5jSP1xO4261H6HvTe7UhbzUZIu82XLHV6D3JxVGmTxf9H7whEdUN7Oe8oxblYE2WWRVeT3AqcIsC80OpzhAaN00cejx83Hz",
    "secretKey" => "sk_test_51QD5jSP1xO4261H6z9YiCnnUBW5bpQHS7ORdlnJ5xNAoGzbkZd9ltuBqNYei5iwLz13MxEa6TrhLfNxsF6QuDYAC00DeXvCjDI"
);
