<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/logo.png">
    <title>Admin | Inactivate Doctor</title>
</head>

<body>
    <?php
    include '../_base.php';

    // Ensure the user has the 'Admin' role
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
        temp('error', 'You do not have permission to perform this action.');
        redirect('adDashboard.php');
        exit();
    }

    // Enable error reporting for debugging
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    // Check if it's a POST request and the ID is provided
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
        $id = (int)$_POST['id']; // Sanitize and fetch the doctor ID

        // Fetch the doctor's information from the database
        $stm = $_db->prepare('SELECT * FROM staff WHERE staffID = ?');
        $stm->execute([$id]);
        $doctor = $stm->fetch(PDO::FETCH_OBJ);

        // Check if the doctor object is valid
        if (!$doctor) {
            echo "<p>Error: Doctor not found or doctor data is not retrieved.</p>";
            exit();
        }

        // Check if the doctor is already inactive
        if ($doctor->status === 'Inactive') {
            temp('info', 'Doctor is already inactive.');
        } else {
            // Update the status to "Inactive"
            $update_stm = $_db->prepare('UPDATE staff SET status = ? WHERE staffID = ?');
            $result = $update_stm->execute(['Inactive', $id]);

            // Check if the update query was successful
            if ($result) {
                temp('info', 'Doctor status changed to inactive successfully.🥺');
            } else {
                temp('error', 'Failed to update doctor status.');
                // Output error information for debugging
                var_dump($update_stm->errorInfo());
            }
        }

        // Redirect to the manage doctor page
        redirect('adManageDoctor.php');
    }
    ?>

    <form method="POST" action="">
        <?php if (isset($doctor) && isset($doctor->staffID)): ?>
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($doctor->staffID); ?>">
            <button type="submit" onclick="return confirm('Are you sure you want to inactivate this services?');">Inactivate</button>
        <?php else: ?>
            <p>Error: Doctor ID is not available.</p>
        <?php endif; ?>
    </form>
</body>

</html>
