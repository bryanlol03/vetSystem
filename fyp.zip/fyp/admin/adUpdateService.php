<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Update Service</title>
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    .service-image {
        border-radius: 10px;
        object-fit: cover;
        width: 150px;
        height: 150px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        transition: transform 0.3s ease;
        display: block;
        margin: 0 auto 20px;
    }

    .service-image:hover {
        transform: scale(1.1);
    }

    .media-body {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        margin-top: 15px;
    }
</style>
<?php
include '../_base.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the service ID is passed in the URL
if (!isset($_GET['id'])) {
    header("Location: adManageService.php");
    exit();
}

$service_id = (int)$_GET['id'];

// Fetch service information from the database
$stmt_service = $_db->prepare("SELECT * FROM service WHERE serviceID = :service_id");
$stmt_service->bindParam(':service_id', $service_id, PDO::PARAM_INT);
$stmt_service->execute();
$service = $stmt_service->fetch(PDO::FETCH_OBJ);

if (!$service) {
    header("Location: adDashboard.php");
    exit();
}

// Handle service updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_service'])) {
    $serviceName = trim($_POST['serviceName']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $servicePrice = trim($_POST['servicePrice']);
    $status = trim($_POST['status']);
    $servicePhoto = $service->servicePhoto; // Default to existing photo
    $errors = [];

    // Server-Side Validation
    if (empty($serviceName)) {
        $errors['serviceName'] = 'Service name is required.';
    } elseif (strlen($serviceName) < 3 || strlen($serviceName) > 100) {
        $errors['serviceName'] = 'Service name must be between 3 and 100 characters.';
    }

    if (empty($category)) {
        $errors['category'] = 'Category is required.';
    }

    if (empty($description)) {
        $errors['description'] = 'Description is required.';
    }

    if (empty($servicePrice) || !is_numeric($servicePrice) || $servicePrice <= 0) {
        $errors['servicePrice'] = 'Service price must be a positive number.';
    }

    if (!empty($_FILES['servicePhoto']['name'])) {
        $file = $_FILES['servicePhoto'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

        if (!in_array($file['type'], $allowed_types)) {
            $errors['servicePhoto'] = 'File must be an image (JPG, PNG, GIF).';
        } elseif ($file['size'] > 800 * 1024) { // Max 800 KB
            $errors['servicePhoto'] = 'Image must be smaller than 800 KB.';
        } else {
            $servicePhoto = uniqid() . '_' . basename($file['name']);
            $upload_dir = '../img/servicePhoto/';
            $upload_path = $upload_dir . $servicePhoto;

            if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
                $errors['servicePhoto'] = 'Failed to upload photo.';
            } else {
                if (!empty($service->servicePhoto) && file_exists($upload_dir . $service->servicePhoto) && $service->servicePhoto !== 'unknown.jpg') {
                    unlink($upload_dir . $service->servicePhoto);
                }
            }
        }
    }

    // Update the database if no errors
    if (empty($errors)) {
        $stmt_update = $_db->prepare("
            UPDATE service
            SET serviceName = :serviceName, category = :category, description = :description, servicePrice = :servicePrice, status = :status, servicePhoto = :servicePhoto
            WHERE serviceID = :service_id
        ");
        $stmt_update->bindParam(':serviceName', $serviceName);
        $stmt_update->bindParam(':category', $category);
        $stmt_update->bindParam(':description', $description);
        $stmt_update->bindParam(':servicePrice', $servicePrice);
        $stmt_update->bindParam(':status', $status);
        $stmt_update->bindParam(':servicePhoto', $servicePhoto);
        $stmt_update->bindParam(':service_id', $service_id, PDO::PARAM_INT);

        if ($stmt_update->execute()) {
            header("Location: adManageService.php");
            exit();
        } else {
            $errors['general'] = 'Failed to update service. Please try again.';
        }
    }

    // Store errors in session to display them on the form page
    $_SESSION['errors'] = $errors;
}
?>

<body>
    <div class="container light-style flex-grow-1 container-p-y">
        <h4 class="font-weight-bold py-3 mb-4">Update Service</h4>

        <!-- Service Update Form -->
        <form method="POST" enctype="multipart/form-data">
            <div class="card overflow-hidden">
                <div class="row no-gutters row-bordered row-border-light">
                    <div class="col-md-3 pt-0">
                        <div class="list-group list-group-flush account-settings-links">
                            <a class="list-group-item list-group-item-action active" data-toggle="list" href="#account-general">General</a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="tab-content">
                            <div class="tab-pane fade active show" id="account-general">
                                <div class="card-body media align-items-center">
                                    <img src="../img/servicePhoto/<?php echo htmlspecialchars($service->servicePhoto) ?: 'unknown.jpg'; ?>" alt="Service Photo" class="service-image">
                                    <div class="media-body">
                                        <label class="btn btn-outline-primary file-upload-label">
                                            Choose File
                                            <input type="file" class="account-settings-fileinput" name="servicePhoto" accept=".jpg,.jpeg,.png">
                                        </label>
                                        <div class="file-chosen text-muted small mt-1">No file chosen</div>
                                    </div>
                                </div>
                                <hr class="border-light m-0">
                                <div class="card-body">
                                    <!-- Editable Fields: Service Name, Category, Description, Service Price, Status -->
                                    <div class="form-group">
                                        <label class="form-label">Service Name</label>
                                        <input type="text" class="form-control" name="serviceName" value="<?php echo htmlspecialchars($service->serviceName); ?>" required minlength="3" maxlength="100">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Category</label>
                                        <input type="text" class="form-control" name="category" value="<?php echo htmlspecialchars($service->category); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Description</label>
                                        <textarea class="form-control" name="description" required><?php echo htmlspecialchars($service->description); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Service Price</label>
                                        <input type="number" class="form-control" name="servicePrice" value="<?php echo htmlspecialchars($service->servicePrice); ?>" required min="0" step="0.01">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Status</label>
                                        <select class="form-control" name="status" required>
                                            <option value="Active" <?php echo $service->status === 'Active' ? 'selected' : ''; ?>>Active</option>
                                            <option value="Inactive" <?php echo $service->status === 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-right mt-3">
                    <button type="submit" class="btn btn-primary" name="update_service">Save Changes</button>
                    <a href="adManageService.php" class="btn btn-default">Cancel</a>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.js"></script>
</body>

</html>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Display chosen file name
        document.querySelector(".account-settings-fileinput").addEventListener("change", function() {
            const fileName = this.files[0] ? this.files[0].name : 'No file chosen';
            document.querySelector(".file-chosen").textContent = fileName;
        });

        // Form validation
        document.querySelector("form").addEventListener("submit", function(event) {
            let errors = [];
            const serviceName = document.querySelector("input[name='serviceName']").value;
            const servicePrice = document.querySelector("input[name='servicePrice']").value;

            // Service name validation
            if (serviceName.length < 3 || serviceName.length > 100) {
                errors.push("Service name must be between 3 and 100 characters.");
            }

            // Service price validation
            if (isNaN(servicePrice) || servicePrice <= 0) {
                errors.push("Service price must be a positive number.");
            }

            // Check for errors
            if (errors.length > 0) {
                event.preventDefault(); // Prevent form submission
                alert(errors.join("\n")); // Display errors as an alert
            }
        });
    });
</script>
