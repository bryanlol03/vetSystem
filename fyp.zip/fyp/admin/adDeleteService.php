<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1" />
    <link rel="icon" href="../img/logo.png">
    <title>Pet Pro Care | Admin Page</title>
    <link rel="stylesheet" href="../css/swiper.css">
    <link rel="stylesheet" href="../css/jquery.scrollbar.css">
    <link rel="stylesheet" href="../css/daterangepicker.css">
    <link rel="stylesheet" href="../css/select2.css">
    <link rel="stylesheet" href="../css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="../css/dashboard.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
</head>
<?php
include '../_base.php';
auth('Admin');

// Ensure the user has the 'Admin' role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    temp('error', 'You do not have permission to perform this action.');
    redirect('adDashboard.php');
    exit();
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if it's a POST request and the ID is provided
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = (int)$_POST['id']; // Sanitize and fetch the service ID

    // Fetch the service information from the database
    $stm = $_db->prepare('SELECT * FROM service WHERE serviceID = ?');
    $stm->execute([$id]);
    $service = $stm->fetch(PDO::FETCH_OBJ);

    // Check if the service object is valid
    if (!$service) {
        echo "<p>Error: Service not found or service data is not retrieved.</p>";
        exit();
    }

    // Check if the service is already inactive
    if ($service->status === 'Inactive') {
        temp('info', 'Service is already inactive.');
    } else {
        // Update the status to "Inactive"
        $update_stm = $_db->prepare('UPDATE service SET status = ? WHERE serviceID = ?');
        $result = $update_stm->execute(['Inactive', $id]);

        if ($result) {
            temp('info', 'Service status changed to inactive successfully.');
        } else {
            temp('error', 'Failed to update service status.');
            // Output error information for debugging
            var_dump($update_stm->errorInfo());
        }
    }

    redirect('adManageService.php');
}
?>

<body>
    <div class="dashboard-wrap">
        <header class="sidebar-header">
            <h1 class="sidebar-header__logo">Pet<span>pro<strong>care</strong></span></h1>
        </header>

        <div class="section section--sidebar" id="sidebar">
            <nav class="sidebar-menu">
                <ul>
                    <li class="dashboard"><a href="../admin/adDashboard.php"><b>Dashboard</b></a></li>
                    <!-- Additional menu items here -->
                </ul>
            </nav>
        </div>

        <div class="section section--content" id="content">
            <header class="content-header">
                <!-- Header content here -->
            </header>

            <div class="content-subheader">
                <h2 class="content-subheader__title">Services List</h2>
            </div>

            <div class="content">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Service Name</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Price (USD)</th>
                            <th>Photo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($services as $service) : ?>
                            <tr>
                                <td><?= htmlspecialchars($service->serviceName); ?></td>
                                <td><?= htmlspecialchars($service->category); ?></td>
                                <td><?= htmlspecialchars($service->description); ?></td>
                                <td><?= htmlspecialchars($service->servicePrice); ?></td>
                                <td>
                                    <img src="../img/servicePhotos/<?= htmlspecialchars($service->servicePhoto); ?>" alt="Service Photo" width="100" height="100">
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/Chart.min.js"></script>
    <script src="../js/moment.min.js"></script>
    <script src="../js/swiper.min.js"></script>
    <script src="../js/select2.min.js"></script>
    <script src="../js/jquery.scrollbar.js"></script>
    <script src="../js/daterangepicker.min.js"></script>
    <script src="../js/jquery.dashboard-custom.js"></script>
</body>

</html>