<?php
ob_start();
include '../helper/adHelper.php';
include_once '../_base.php';

$recordsPerPage = 5;
$recordID = $_GET['id'] ?? null;
// Get the current page or set to 1 if not specified
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($currentPage - 1) * $recordsPerPage;

try {
    // Fetch the total number of records
    $countStmt = $_db->prepare("SELECT COUNT(*) as total FROM medicalrecord");
    $countStmt->execute();
    $totalRecords = $countStmt->fetchColumn();
    $totalPages = ceil($totalRecords / $recordsPerPage);

    // Fetch records for the current page
    $stm = $_db->prepare("
        SELECT m.recordID, m.date, m.notes, m.diagnosis, p.name AS petName, m.serviceType, m.medicineName
        FROM medicalrecord m
        INNER JOIN pet p ON m.petID = p.petID
        ORDER BY m.date DESC
        LIMIT :limit OFFSET :offset
    ");
    $stm->bindValue(':limit', $recordsPerPage, PDO::PARAM_INT);
    $stm->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stm->execute();
    $records = $stm->fetchAll(PDO::FETCH_OBJ);
} catch (Exception $e) {
    die("Error fetching records: " . $e->getMessage());
}

$filterStatus = isset($_GET['status']) ? $_GET['status'] : 'all';

try {
    // Base SQL query
    $sql = "
        SELECT b.paymentDate, b.totalAmount AS amount, b.paymentStatus AS status, 
               s.serviceName, b.paymentID
        FROM payment b
        INNER JOIN service s ON b.serviceID = s.serviceID
    ";

    // Apply filter if status is provided
    if ($filterStatus !== 'all') {
        $sql .= " WHERE b.paymentStatus = :status";
    }
    $sql .= " ORDER BY b.paymentDate DESC";

    $stm = $_db->prepare($sql);

    if ($filterStatus !== 'all') {
        $stm->bindParam(':status', $filterStatus, PDO::PARAM_STR);
    }

    $stm->execute();
    $billingRecords = $stm->fetchAll(PDO::FETCH_OBJ);
} catch (Exception $e) {
    die("Error fetching billing records: " . $e->getMessage());
}

if (isset($_GET['download']) && !empty($_GET['download'])) {
    downloadPDF($_GET['download']);
}

function downloadPDF($billingID)
{
    global $_db;

    // Fetch payment and service details from the database for the given billing ID
    $stmt = $_db->prepare("
        SELECT 
            p.paymentID,
            p.paymentDate,
            p.totalAmount,
            p.paymentStatus,
            s.serviceName
        FROM payment p
        INNER JOIN service s ON p.serviceID = s.serviceID
        WHERE p.paymentID = ?
    ");
    $stmt->execute([$billingID]);
    $record = $stmt->fetch(PDO::FETCH_OBJ);

    if (!$record) {
        die("Invalid billing ID.");
    }

    // Clean any previous output
    ob_clean();

    // PDF Header
    $header = "PetPro Care Issues\n";
    $header .= "123, Jalan Blablabla, Kuala Lumpur, Malaysia\n\n";

    // Table Header
    $tableHeader = "Date\t\tDescription\t\tAmount\t\tPayment Status\n";
    $tableHeader .= "-----------------------------------------------------------\n";

    // Table Content
    $tableContent = sprintf(
        "%s\t%s\t$%.2f\t%s\n",
        $record->paymentDate,
        $record->serviceName,
        $record->totalAmount,
        $record->paymentStatus
    );

    // Full Content
    $content = $header . $tableHeader . $tableContent;

    // Generate the PDF content
    $pdfContent = generateSimplePDF($content);

    // Output the PDF
    header("Content-Type: application/pdf");
    header("Content-Disposition: attachment; filename=billing_$billingID.pdf");
    echo $pdfContent;
    exit();
}

function generateSimplePDF($content)
{
    // Build a basic PDF structure (raw content-based)
    $pdf = "%PDF-1.4\n";
    $pdf .= "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
    $pdf .= "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
    $pdf .= "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R >>\nendobj\n";

    // Encode text into a stream for the PDF
    $encodedContent = "";
    foreach (str_split($content) as $char) {
        $encodedContent .= sprintf("\\%03o", ord($char));
    }

    // Add text content as a stream
    $pdf .= "4 0 obj\n<< /Length " . strlen($encodedContent) . " >>\nstream\n";
    $pdf .= $encodedContent . "\nendstream\nendobj\n";

    // Add xref table
    $pdf .= "xref\n0 5\n0000000000 65535 f \n";
    $pdf .= "0000000010 00000 n \n0000000053 00000 n \n0000000115 00000 n \n";
    $pdf .= "0000000178 00000 n \ntrailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n";
    $pdf .= (178 + strlen($encodedContent)) . "\n%%EOF";

    return $pdf;
}

ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing & Payments</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon/fonts/remixicon.css">
    <style>
        .container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .card h3 {
            margin-bottom: 10px;
            font-size: 20px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .billing-history table,
        .medical-records table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f0f0f0;
        }

        .action-buttons span {
            margin-right: 10px;
            cursor: pointer;
            color: #007BFF;
        }

        .action-buttons .delete-payment {
            color: #ff4d4d;
        }

        .badge {
            background-color: #28a745;
            color: white;
            padding: 3px 8px;
            border-radius: 10px;
            font-size: 12px;
            margin-left: 10px;
        }

        .btn {
            display: inline-block;
            background-color: #007BFF;
            color: white;
            padding: 10px 15px;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            margin-top: 10px;
        }

        .btn-danger {
            background-color: #ff4d4d;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .btn-danger:hover {
            background-color: #cc0000;
        }

        .pagination {
            margin-top: 10px;
            text-align: center;
            justify-content: center;
        }

        .pagination a {
            display: inline-block;
            padding: 8px 12px;
            margin: 0 4px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .pagination a:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>


    <!-- Medical Records for Payment Generation -->
    <div class="card medical-records">
        <div class="section-header">
            <h3>Medical Records</h3>
            <button class="btn">View All Records</button>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Record ID</th>
                    <th>Pet Name</th>
                    <th>Service Type</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Medicine Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($records): ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?= htmlspecialchars($record->recordID) ?></td>
                            <td><?= htmlspecialchars($record->petName) ?></td>
                            <td><?= htmlspecialchars($record->serviceType ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($record->date) ?></td>
                            <td>$<?= number_format(rand(50, 150), 2) ?></td>
                            <td><?= htmlspecialchars($record->medicineName)?></td>
                            <td>
                                <a href="editPayment.php?id=<?= htmlspecialchars($record->recordID) ?>" class="btn">Edit Details</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php if ($currentPage > 1): ?>
                <a href="?page=<?= $currentPage - 1 ?>">&laquo; Previous</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>" <?= $i === $currentPage ? 'style="font-weight: bold;"' : '' ?>><?= $i ?></a>
            <?php endfor; ?>

            <?php if ($currentPage < $totalPages): ?>
                <a href="?page=<?= $currentPage + 1 ?>">Next &raquo;</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="card billing-history">
        <div class="section-header">
            <h3>Billing History</h3>
            <form method="GET" style="display: inline;">
                <select name="filter" onchange="this.form.submit()">
                    <option value="all" <?= $filterStatus === 'all' ? 'selected' : '' ?>>All</option>
                    <option value="Paid" <?= $filterStatus === 'Paid' ? 'selected' : '' ?>>Paid</option>
                    <option value="Unpaid" <?= $filterStatus === 'Unpaid' ? 'selected' : '' ?>>Unpaid</option>
                </select>
                <input type="hidden" name="page" value="<?= $currentPage ?>">
            </form>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Payment Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($billingRecords): ?>
                    <?php foreach ($billingRecords as $record): ?>
                        <tr>
                            <td><?= htmlspecialchars($record->paymentDate) ?></td>
                            <td><?= htmlspecialchars($record->serviceName) ?></td>
                            <td>$<?= number_format($record->amount, 2) ?></td>
                            <td><?= htmlspecialchars($record->status) ?></td>
                            <td class="action-buttons">
                                <span class="view-invoice">View</span> |
                                <a href="?download=<?= htmlspecialchars($record->paymentID) ?>" class="btn">Download PDF</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php if ($currentPage > 1): ?>
                <a href="?page=<?= $currentPage - 1 ?>&filter=<?= $filter ?>">&laquo;</a>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>&filter=<?= $filter ?>" <?= $i === $currentPage ? 'style="font-weight: bold;"' : '' ?>><?= $i ?></a>
            <?php endfor; ?>
            <?php if ($currentPage < $totalPages): ?>
                <a href="?page=<?= $currentPage + 1 ?>&filter=<?= $filter ?>">&raquo;</a>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>