<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1" />
    <link rel="icon" href="../img/logo.png">
    <title>Pet Pro Care | Manage Pet Owners</title>
    <link rel="stylesheet" href="../css/swiper.css">
    <link rel="stylesheet" href="../css/jquery.scrollbar.css">
    <link rel="stylesheet" href="../css/daterangepicker.css">
    <link rel="stylesheet" href="../css/select2.css">
    <link rel="stylesheet" href="../css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="../css/dashboard.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f9f9fc;
        color: #333;
        padding: 20px;
    }

    /* Filter Form Styling */
    form {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 20px;
    }

    input[type="text"],
    input[type="date"],
    select {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
    }

    button {
        padding: 10px 20px;
        background-color: #6a5acd;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 14px;
        transition: background-color 0.3s;
    }

    button:hover {
        background-color: #5a4cb1;
    }

    /* Table Styling */
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: #fff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    th,
    td {
        padding: 12px 15px;
        text-align: left;
        font-size: 14px;
    }

    th {
        background-color: #6a5acd;
        color: #fff;
        font-weight: bold;
        text-transform: uppercase;
    }

    tr:nth-child(even) {
        background-color: #f4f4f9;
    }

    tr:hover {
        background-color: #eef0f5;
    }

    img {
        border-radius: 50%;
        width: 40px;
        height: 40px;
        object-fit: cover;
    }

    h2 {
        color: #444;
        margin-top: 20px;
        font-size: 1.6em;
    }

    /* Adjust Text and Spacing */
    td a {
        color: #6a5acd;
        text-decoration: none;
        font-weight: bold;
    }

    td a:hover {
        text-decoration: underline;
    }

    .pagination {
        display: inline-block;
        margin-top: 20px;
    }

    .pagination-link {
        color: #6a5acd;
        padding: 8px 16px;
        text-decoration: none;
        font-weight: bold;
        margin: 0 2px;
        border: 1px solid #ddd;
        border-radius: 4px;
        transition: background-color 0.3s, color 0.3s;
    }

    .pagination-link:hover {
        background-color: #6a5acd;
        color: #fff;
    }

    .pagination-link.active {
        background-color: #5a4cb1;
        color: #fff;
        border-color: #5a4cb1;
    }
</style>
<?php
include '../_base.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure the user is logged in by checking `staff_id`
if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php");
    exit();
}
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 8;
$offset = ($page - 1) * $records_per_page;

// Fetch total number of pet owners for pagination with optional search
$count_query = "SELECT COUNT(*) FROM petOwner WHERE name LIKE :search OR email LIKE :search";
$stmt_count = $_db->prepare($count_query);
$stmt_count->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
$stmt_count->execute();
$total_records = $stmt_count->fetchColumn();
$total_pages = ceil($total_records / $records_per_page);

// Fetch pet owners with pagination and optional search
$query = "SELECT * FROM petOwner WHERE name LIKE :search OR email LIKE :search LIMIT :limit OFFSET :offset";
$stmt = $_db->prepare($query);
$stmt->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
$stmt->bindValue(':limit', $records_per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$pet_owners = $stmt->fetchAll(PDO::FETCH_OBJ);
?>

<body>
<?php
    include '../helper/adHelper.php';
    ?>
    
    <form method="GET" action="adManageUser.php" style="margin-bottom: 20px;">
        <input type="text" name="search" placeholder="Search by name or email" value="<?= htmlspecialchars($search) ?>" style="padding: 8px; border-radius: 4px; border: 1px solid #ccc; margin-right: 10px;">
        <button type="submit" style="padding: 8px 16px; background-color: #6a5acd; color: #fff; border: none; border-radius: 4px; cursor: pointer;">Filter</button>
        <button type="button" onclick="window.location.href='adManageUser.php';" style="padding: 8px 16px; background-color: #f44336; color: #fff; border: none; border-radius: 4px; cursor: pointer;">Reset</button>
    </form>

    <button><a href="adAddPatient.php" style="color: white;">Add User</a></button>
    <h2>Users</h2>
    <div class="content">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Gender</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Profile Photo</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $count = $offset + 1; // Start counter based on the offset
                foreach ($pet_owners as $owner) :
                ?>
                    <tr>
                        <td><?php echo $count++; ?></td> <!-- Increment the counter -->
                        <td><?php echo htmlspecialchars($owner->username); ?></td>
                        <td><?php echo htmlspecialchars($owner->name); ?></td>
                        <td><?php echo htmlspecialchars($owner->contact); ?></td>
                        <td><?php echo htmlspecialchars($owner->gender); ?></td>
                        <td><?php echo htmlspecialchars($owner->address); ?></td>
                        <td><?php echo htmlspecialchars($owner->email); ?></td>
                        <td><img src="../img/userPhoto/<?php echo htmlspecialchars($owner->profile_photo); ?>" alt="Profile Photo" width="40" height="40"></td>
                        <td>
                            <a href="adUpdateUser.php?id=<?= $owner->petOwnerID ?>">Edit</a> |
                            <form method="POST" action="adDeleteUser.php" style="display:inline;">
                                <input type="hidden" name="id" value="<?= htmlspecialchars($owner->petOwnerID) ?>">
                                <button type="submit" class="delete-member-btn" onclick="return confirm('Are you sure you want to delete this user?');" style="color: red;">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Pagination Links -->
        <div class="pagination" style="display: inline-block; margin-top: 20px; text-align: center;">
            <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                <a href="?page=<?= $i ?>"
                    class="pagination-link <?= $i === $page ? 'active' : '' ?>"
                    style="
               color: #6a5acd; 
               padding: 8px 16px; 
               text-decoration: none; 
               font-weight: bold; 
               margin: 0 5px; 
               border: 1px solid #ddd; 
               border-radius: 4px; 
               transition: background-color 0.3s, color 0.3s;
               <?= $i === $page ? 'background-color: #5a4cb1; color: #fff; border-color: #5a4cb1;' : '' ?>
           ">
                    <?= $i ?>
                </a>
            <?php endfor; ?>
        </div>

    </div>
    </div>


    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/Chart.min.js"></script>
    <script src="../js/moment.min.js"></script>
    <script src="../js/swiper.min.js"></script>
    <script src="../js/select2.min.js"></script>
    <script src="../js/jquery.scrollbar.js"></script>
    <script src="../js/daterangepicker.min.js"></script>
    <script src="../js/jquery.dashboard-custom.js"></script>
</body>

</html>