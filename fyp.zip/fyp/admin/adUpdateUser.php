<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Update Pet Owner</title>
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    .pet-image {
        border-radius: 50%;
        object-fit: cover;
        width: 150px;
        height: 150px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        transition: transform 0.3s ease;
        display: block;
        margin: 0 auto 20px auto;
    }

    .pet-image:hover {
        transform: scale(1.1);
    }

    .dark-mode .card {
        background-color: #1c1c1c;
        box-shadow: 0 6px 18px rgba(255, 255, 255, 0.2);
    }

    .dark-mode .form-label {
        color: white;
    }

    .dark-mode .form-control {
        background-color: #333;
        border-color: #555;
        color: #fff;
    }

    .mode-toggle-btn {
        position: absolute;
        top: 20px;
        right: 20px;
        padding: 12px 15px;
        border-radius: 50px;
        font-size: 20px;
        background-color: #007bff;
        color: white;
        border: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .mode-toggle-btn i {
        margin-right: 12px;
    }

    .dark-mode .mode-toggle-btn {
        background-color: #f8f7f6;
        color: black;
    }

    .media-body {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        margin-top: 15px;
    }
</style>
<?php
include '../_base.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the pet owner ID is passed in the URL
if (!isset($_GET['id'])) {
    header("Location: adDashboard.php");
    exit();
}

$owner_id = (int)$_GET['id'];

// Fetch pet owner information from the database
$stmt_owner = $_db->prepare("SELECT * FROM petOwner WHERE petOwnerID = :owner_id");
$stmt_owner->bindParam(':owner_id', $owner_id, PDO::PARAM_INT);
$stmt_owner->execute();
$owner = $stmt_owner->fetch(PDO::FETCH_OBJ);

if (!$owner) {
    header("Location: adDashboard.php");
    exit();
}

// Handle profile updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $contact = trim($_POST['contact']);
    $address = trim($_POST['address']);
    $profile_photo = $owner->profile_photo; // Default to existing photo
    $errors = [];

    // Server-Side Validation
    if (empty($name)) {
        $errors['name'] = 'Name is required.';
    } elseif (strlen($name) < 3 || strlen($name) > 100) {
        $errors['name'] = 'Name must be between 3 and 100 characters.';
    }

    if (empty($contact)) {
        $errors['contact'] = 'Contact number is required.';
    } elseif (!preg_match('/^\d{9,11}$/', $contact)) {
        $errors['contact'] = 'Contact number must be between 9 and 11 digits.';
    }

    if (!empty($_FILES['profile_photo']['name'])) {
        $file = $_FILES['profile_photo'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

        if (!in_array($file['type'], $allowed_types)) {
            $errors['profile_photo'] = 'File must be an image (JPG, PNG, GIF).';
        } elseif ($file['size'] > 800 * 1024) { // Max 800 KB
            $errors['profile_photo'] = 'Image must be smaller than 800 KB.';
        } else {
            $profile_photo = uniqid() . '_' . basename($file['name']);
            $upload_dir = '../img/userPhoto/';
            $upload_path = $upload_dir . $profile_photo;

            if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
                $errors['profile_photo'] = 'Failed to upload photo.';
            } else {
                if (!empty($owner->profile_photo) && file_exists($upload_dir . $owner->profile_photo) && $owner->profile_photo !== 'unknown.jpg') {
                    unlink($upload_dir . $owner->profile_photo);
                }
            }
        }
    }

    // Update the database if no errors
    if (empty($errors)) {
        $stmt_update = $_db->prepare("
            UPDATE petOwner 
            SET name = :name, contact = :contact, address = :address, profile_photo = :profile_photo
            WHERE petOwnerID = :owner_id
        ");
        $stmt_update->bindParam(':name', $name);
        $stmt_update->bindParam(':contact', $contact);
        $stmt_update->bindParam(':address', $address);
        $stmt_update->bindParam(':profile_photo', $profile_photo);
        $stmt_update->bindParam(':owner_id', $owner_id, PDO::PARAM_INT);

        if ($stmt_update->execute()) {
            header("Location: adManageUser.php");
            exit();
        } else {
            $errors['general'] = 'Failed to update profile. Please try again.';
        }
    }

    $_SESSION['errors'] = $errors;
}
?>

<body>
    <div class="container light-style flex-grow-1 container-p-y">
        <h4 class="font-weight-bold py-3 mb-4">Update Pet Owner Profile</h4>

        <!-- Profile Update Form -->
        <form method="POST" enctype="multipart/form-data">
            <div class="card overflow-hidden">
                <div class="row no-gutters row-bordered row-border-light">
                    <div class="col-md-3 pt-0">
                        <div class="list-group list-group-flush account-settings-links">
                            <a class="list-group-item list-group-item-action active" data-toggle="list" href="#account-general">General</a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="tab-content">
                            <div class="tab-pane fade active show" id="account-general">
                                <div class="card-body media align-items-center">
                                    <img src="../img/userPhoto/<?php echo htmlspecialchars($owner->profile_photo) ?: 'unknown.jpg'; ?>" alt="Owner Photo" class="pet-image">
                                    <div class="media-body">
                                        <label class="btn btn-outline-primary file-upload-label">
                                            Choose File
                                            <input type="file" class="account-settings-fileinput" name="profile_photo" accept=".jpg,.jpeg,.png">
                                        </label>
                                        <div class="file-chosen text-muted small mt-1">No file chosen</div>
                                    </div>
                                </div>
                                <hr class="border-light m-0">
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="form-label">Name</label>
                                        <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($owner->name); ?>" required minlength="3" maxlength="100">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Contact</label>
                                        <input type="text" class="form-control" name="contact" value="<?php echo htmlspecialchars($owner->contact); ?>" required pattern="\d{9,11}" title="Contact number must be between 9 and 11 digits.">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Address</label>
                                        <input type="text" class="form-control" name="address" value="<?php echo htmlspecialchars($owner->address); ?>" required>
                                    </div>
                                   
                                    <div class="form-group">
                                        <label class="form-label">Email</label>
                                        <input type="email" class="form-control" value="<?php echo htmlspecialchars($owner->email); ?>" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-right mt-3">
                    <button type="submit" class="btn btn-primary" name="update_profile">Save Changes</button>
                    <a href="adDashboard.php" class="btn btn-default">Cancel</a>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.js"></script>
</body>

</html>
<script>
    document.querySelector(".account-settings-fileinput").addEventListener("change", function() {
        const fileName = this.files[0] ? this.files[0].name : 'No file chosen';
        document.querySelector(".file-chosen").textContent = fileName;
    });

    <?php if (isset($_SESSION['errors']) && !empty($_SESSION['errors'])): ?>
        Swal.fire({
            title: 'Error!',
            text: '<?php echo implode(", ", $_SESSION['errors']); ?>',
            icon: 'error',
            confirmButtonText: 'OK'
        });
        <?php unset($_SESSION['errors']); ?>
    <?php endif; ?>
</script>
