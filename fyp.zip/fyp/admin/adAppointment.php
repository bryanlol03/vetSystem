<?php
include_once '../_base.php';
include '../helper/adHelper.php';

$sql = "
    SELECT a.appointmentID, a.date, a.time, a.status, a.petName, a.staffID, a.symptom, s.serviceName, st.name as doctorName
    FROM appointment a
    JOIN service s ON a.serviceID = s.serviceID
    JOIN staff st ON a.staffID = st.staffID
    ORDER BY a.date ASC, a.time ASC
";

// Prepare and execute the query
$stmt = $_db->prepare($sql);
$stmt->execute();
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group appointments by date
$groupedAppointments = [];
foreach ($appointments as $appointment) {
    $groupedAppointments[$appointment['date']][] = $appointment;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nurse | View Appointment</title>
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="../css/swiper.css">
    <link rel="stylesheet" href="../css/jquery.scrollbar.css">
    <link rel="stylesheet" href="../css/daterangepicker.css">
    <link rel="stylesheet" href="../css/select2.css">
    <link rel="stylesheet" href="../css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="../css/dashboard.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .status-pending {
            color: #FFC107;
            /* Yellow */
        }

        .status-accepted {
            color: #28A745;
            /* Green */
        }

        .status-rejected,
        .status-cancelled {
            color: #DC3545;
            /* Red */
        }

        .status-default {
            color: #6C757D;
            /* Gray */
        }

        .timeline__header {
            background-color: #f4f4f4;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            margin-bottom: 10px;
        }

        .timeline__header-day {
            font-size: 1.5em;
            font-weight: bold;
        }

        .timeline__header-month {
            font-size: 1em;
            color: #888;
        }

        .timeline__row {
            padding: 8px;
            padding-bottom: 30px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .timeline__hour {
            font-weight: bold;
            font-size: 1.2em;
            color: #0056b3;
            margin-bottom: 5px;
        }

        .timeline__details {
            font-size: 1.1em;
            color: #333;
        }

        .timeline__symptom {
            margin-top: 10px;
            font-size: 1em;
            color: #777;
            white-space: pre-line;
            word-wrap: break-word;
        }

        .timeline__status {
            font-weight: bold;
            font-size: 1.1em;
            margin-top: 5px;
        }

        .timeline__time-group {
            margin-top: 20px;
        }

        .timeline__time-header {
            font-size: 1.4em;
            font-weight: bold;
            color: #444;
            margin-bottom: 10px;
            text-align: center;
        }

        .timeline__doctor {
            color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="content-subheader">
        <div class="content-subheader__titles">
            <h2 class="content-subheader__title">Appointments</h2>
            <nav class="content-subheader__breadcrumb-menu">
                <ul>
                    <li><a href="dashboard.html">Dashboard</a></li>
                </ul>
            </nav>
        </div>
    </div>

    <div class="timeline">
        <div class="timeline__content swiper-wrapper">
            <!-- Loop through grouped appointments by date -->
            <?php if (!empty($groupedAppointments)): ?>
                <?php foreach ($groupedAppointments as $date => $appointmentsOnDate): ?>
                    <div class="timeline__slide swiper-slide">
                        <div class="timeline__header">
                            <span class="timeline__header-day"><?php echo htmlspecialchars(date("d F Y", strtotime($date))); ?></span><br>
                            <span class="timeline__header-month"><?php echo htmlspecialchars(date("l", strtotime($date))); ?></span>
                        </div>

                        <div class="timeline__grid scrollbar-macosx">
                            <?php
                            $times = [];
                            foreach ($appointmentsOnDate as $appointment) {
                                $time = date("h:i A", strtotime($appointment['time']));
                                if (!isset($times[$time])) {
                                    $times[$time] = [];
                                }
                                $times[$time][] = $appointment;
                            }

                            foreach ($times as $time => $appointmentsAtTime): ?>
                                <div class="timeline__time-group">
                                    <div class="timeline__time-header"><?php echo $time; ?></div>

                                    <?php foreach ($appointmentsAtTime as $appointment): ?>
                                        <div class="timeline__row">
                                            <div class="timeline__details">
                                                <h3 class="timeline__user"><?php echo htmlspecialchars($appointment['petName']); ?></h3>
                                                <div class="timeline__info"><?php echo htmlspecialchars($appointment['serviceName']); ?></div>
                                                <div class="timeline__doctor">
                                                    Doctor: <?php echo htmlspecialchars($appointment['doctorName']); ?>
                                                </div>
                                                <div class="timeline__status 
                                                    <?php
                                                    switch ($appointment['status']) {
                                                        case 'Pending':
                                                            echo 'status-pending';
                                                            break;
                                                        case 'Accepted':
                                                            echo 'status-accepted';
                                                            break;
                                                        case 'Rejected':
                                                            echo 'status-rejected';
                                                            break;
                                                        case 'Cancelled':
                                                            echo 'status-cancelled';
                                                            break;
                                                        default:
                                                            echo 'status-default';
                                                            break;
                                                    }
                                                    ?>">
                                                    <?php echo htmlspecialchars($appointment['status']); ?>
                                                </div>
                                                <div class="timeline__symptom"><?php echo htmlspecialchars($appointment['symptom']); ?></div>
                                                <div class="timeline__more">
                                                    <span class="show-more show-more--ellipsis show-more--ellipsis-vertical has-dropdown"></span>
                                                    <nav class="dropdown-menu dropdown-menu--content dropdown-menu--timeline">
                                                        <ul>
                                                            <?php if ($appointment['status'] !== 'Accepted' && $appointment['status'] !== 'Completed'): ?>
                                                                <?php if ($appointment['status'] === 'Pending'): ?>
                                                                    <li>
                                                                        <form method="POST" action="nrAcceptAppointment.php" style="display:inline;" onsubmit="return validateAppointmentDate('<?php echo $appointment['date']; ?>', '<?php echo $appointment['time']; ?>')">
                                                                            <input type="hidden" name="appointmentID" value="<?= htmlspecialchars($appointment['appointmentID']) ?>">
                                                                            <button type="submit" class="accept-appointment-btn" style="color: green; background: none; border: none; cursor: pointer;">
                                                                                Accept
                                                                            </button>
                                                                        </form>
                                                                    </li>
                                                                <?php endif; ?>
                                                                <li>
                                                                    <form id="cancelForm-<?= htmlspecialchars($appointment['appointmentID']) ?>" method="POST" action="adCancel.php" style="display:inline;">
                                                                        <input type="hidden" name="appointmentID" value="<?= htmlspecialchars($appointment['appointmentID']) ?>">
                                                                        <button type="button" class="delete-member-btn" onclick="confirmCancellation(event, '<?= htmlspecialchars($appointment['appointmentID']) ?>')" style="color: red; background: none; border: none; cursor: pointer;">
                                                                            Cancel
                                                                        </button>
                                                                    </form>
                                                                </li>
                                                                <li><a href="nrReschedule.php?id=<?= htmlspecialchars($appointment['appointmentID']) ?>">Reschedule</a></li>
                                                            <?php endif; ?>
                                                            <li><a href="adContactPatient.php?id=<?= htmlspecialchars($appointment['appointmentID']) ?>">Contact patient</a></li>
                                                        </ul>
                                                    </nav>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="timeline__slide swiper-slide">
                    <div class="timeline__header">
                        <span class="timeline__header-day">No</span>
                        <span class="timeline__header-month">Appointments</span>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/moment.min.js"></script>
    <script src="js/daterangepicker.min.js"></script>
    <script src="js/jquery.scrollbar.js"></script>
    <script src="js/swiper.min.js"></script>
    <script src="js/select2.min.js"></script>
    <script src="js/ion.rangeSlider.min.js"></script>
    <script src="js/jquery.dashboard-custom.js"></script>

    <script>
        function validateAppointmentDate(appointmentDate, appointmentTime) {
            const now = new Date();
            const appointmentDateTime = new Date(`${appointmentDate}T${appointmentTime}`);
            if (appointmentDateTime <= now) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'You cannot accept an appointment for a past date or a time that has already passed.',
                });
                return false;
            }
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'Appointment is valid and ready to be accepted.',
            });
            return true;
        }

        function confirmCancellation(event, appointmentID) {
            event.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Cancel Appointment',
                text: 'Are you sure you want to cancel this appointment?',
                showCancelButton: true,
                confirmButtonText: 'Yes, cancel it!',
                cancelButtonText: 'No, keep it',
            }).then((result) => {
                if (result.isConfirmed) {
                    document.querySelector(`#cancelForm-${appointmentID}`).submit();
                }
            });
        }

        document.addEventListener("DOMContentLoaded", function() {
            const showMoreButtons = document.querySelectorAll(".show-more");
            showMoreButtons.forEach(button => {
                button.addEventListener("click", function() {
                    const dropdownMenu = this.nextElementSibling;
                    if (dropdownMenu) {
                        dropdownMenu.classList.toggle("active");
                    }
                });
            });

            document.addEventListener("click", function(event) {
                if (!event.target.closest(".show-more") && !event.target.closest(".dropdown-menu")) {
                    document.querySelectorAll(".dropdown-menu").forEach(menu => {
                        menu.classList.remove("active");
                    });
                }
            });
        });

        
    </script>
</body>

</html>