<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1" />
    <link rel="icon" href="../img/logo.png">
    <title>Pet Pro Care | Admin Page</title>
    <link rel="stylesheet" href="../css/swiper.css">
    <link rel="stylesheet" href="../css/jquery.scrollbar.css">
    <link rel="stylesheet" href="../css/daterangepicker.css">
    <link rel="stylesheet" href="../css/select2.css">
    <link rel="stylesheet" href="../css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="../css/dashboard.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f9f9fc;
        color: #333;
        padding: 20px;
    }

    /* Filter Form Styling */
    form {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 20px;
    }

    input[type="text"],
    input[type="date"],
    select {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
    }

    button {
        padding: 10px 20px;
        background-color: #6a5acd;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 14px;
        transition: background-color 0.3s;
    }

    button:hover {
        background-color: #5a4cb1;
    }

    /* Table Styling */
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: #fff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    th,
    td {
        padding: 12px 15px;
        text-align: left;
        font-size: 14px;
    }

    th {
        background-color: #6a5acd;
        color: #fff;
        font-weight: bold;
        text-transform: uppercase;
    }

    tr:nth-child(even) {
        background-color: #f4f4f9;
    }

    tr:hover {
        background-color: #eef0f5;
    }

    img {
        border-radius: 50%;
        width: 40px;
        height: 40px;
        object-fit: cover;
    }

    h2 {
        color: #444;
        margin-top: 20px;
        font-size: 1.6em;
    }

    /* Adjust Text and Spacing */
    td a {
        color: #6a5acd;
        text-decoration: none;
        font-weight: bold;
    }

    td a:hover {
        text-decoration: underline;
    }

    .pagination {
        display: inline-block;
        margin-top: 20px;
    }

    .pagination-link {
        color: #6a5acd;
        padding: 8px 16px;
        text-decoration: none;
        font-weight: bold;
        margin: 0 2px;
        border: 1px solid #ddd;
        border-radius: 4px;
        transition: background-color 0.3s, color 0.3s;
    }

    .pagination-link:hover {
        background-color: #6a5acd;
        color: #fff;
    }

    .pagination-link.active {
        background-color: #5a4cb1;
        color: #fff;
        border-color: #5a4cb1;
    }
</style>
<?php
include '../_base.php';
include '../helper/adHelper.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure the user is logged in by checking `staff_id`
if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php");
    exit();
}

$stmt_categories = $_db->prepare("SELECT DISTINCT category FROM service");
$stmt_categories->execute();
$categories = $stmt_categories->fetchAll(PDO::FETCH_OBJ);

// Handle filtering and pagination
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category_filter = isset($_GET['category']) ? trim($_GET['category']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 8;
$offset = ($page - 1) * $records_per_page;

// Handle filtering and pagination
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category_filter = isset($_GET['category']) ? trim($_GET['category']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 8;
$offset = ($page - 1) * $records_per_page;

// Build query with filtering
$query = "SELECT * FROM service WHERE 1";
$params = [];

if (!empty($search)) {
    $query .= " AND (serviceName LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($category_filter)) {
    $query .= " AND category = ?";
    $params[] = $category_filter;
}

$query .= " LIMIT $records_per_page OFFSET $offset";
$stmt_services = $_db->prepare($query);
$stmt_services->execute($params);
$services = $stmt_services->fetchAll(PDO::FETCH_OBJ);

// Get total records for pagination
$count_query = "SELECT COUNT(*) FROM service WHERE 1";
$count_params = [];

if (!empty($search)) {
    $count_query .= " AND (serviceName LIKE ? OR description LIKE ?)";
    $count_params[] = "%$search%";
    $count_params[] = "%$search%";
}

if (!empty($category_filter)) {
    $count_query .= " AND category = ?";
    $count_params[] = $category_filter;
}

$stmt_count = $_db->prepare($count_query);
$stmt_count->execute($count_params);
$total_records = $stmt_count->fetchColumn();
$total_pages = ceil($total_records / $records_per_page);
?>

<body>

    <div class="section section--content" id="content">
     
        <div class="content-subheader">
            <h2 class="content-subheader__title"><b>Services List</b></h2>
            <button><a href="adAddService.php" style="color: white;" class="btn">Add Service</a></button>
        </div>
        <form method="GET" action="">
            <input type="text" name="search" placeholder="Search by name or description" value="<?= htmlspecialchars($search) ?>">
            <select name="category">
                <option value="">All Categories</option>
                <?php foreach ($categories as $category) : ?>
                    <option value="<?= htmlspecialchars($category->category); ?>" <?= $category_filter === $category->category ? 'selected' : '' ?>>
                        <?= htmlspecialchars($category->category); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Filter</button>
            <button type="button" onclick="window.location.href='adManageService.php';">Reset</button>
        </form>
        <div class="content">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Service Name</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Price (USD)</th>
                        <th>Photo</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($services as $service) : ?>
                        <tr>
                            <td><?= htmlspecialchars($service->serviceName); ?></td>
                            <td><?= htmlspecialchars($service->category); ?></td>
                            <td><?= htmlspecialchars($service->description); ?></td>
                            <td><?= htmlspecialchars($service->servicePrice); ?></td>
                            <td><img src="../img/servicePhoto/<?= htmlspecialchars($service->servicePhoto); ?>" alt="Service Photo" width="100" height="100"></td>
                            <td><?= htmlspecialchars($service->status); ?></td>
                            <td>
                                <a href="adUpdateService.php?id=<?= $service->serviceID ?>">Edit</a> |
                                <form method="POST" action="adDeleteService.php" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= htmlspecialchars($service->serviceID) ?>">
                                    <button type="submit" class="delete-member-btn" onclick="return confirm('Are you sure you want to inactivate this service?');" style="color: red;">Inactive</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="pagination">
                <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                    <a href="?page=<?= $i ?>&search=<?= htmlspecialchars($search) ?>&category=<?= htmlspecialchars($category_filter) ?>" class="pagination-link <?= $i === $page ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
    </div>

    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/Chart.min.js"></script>
    <script src="../js/moment.min.js"></script>
    <script src="../js/swiper.min.js"></script>
    <script src="../js/select2.min.js"></script>
    <script src="../js/jquery.scrollbar.js"></script>
    <script src="../js/daterangepicker.min.js"></script>
    <script src="../js/jquery.dashboard-custom.js"></script>
</body>

</html>