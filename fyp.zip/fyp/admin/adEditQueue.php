<?php
include '../_base.php'; // Include your database configuration
auth('Admin'); // Ensure only admins can access

// Check if queueID is provided in the URL
if (isset($_GET['queueID'])) {
    $queueID = (int)$_GET['queueID'];

    // Fetch queue details from the database
    $query = "SELECT * FROM queue WHERE queueID = :queueID";
    $stmt = $_db->prepare($query);
    $stmt->execute([':queueID' => $queueID]);
    $queue = $stmt->fetch(PDO::FETCH_ASSOC);

    // Redirect to error page if queue not found
    if (!$queue) {
        header("Location: adNotFound.php");
        exit();
    }
} else {
    // Redirect if no queueID is provided
    header("Location: adNotFound.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $queueID = (int)$_POST['queueID'];
    $queueNumber = trim($_POST['queueNumber']);
    $queueStatus = trim($_POST['queueStatus']);
    $description = trim($_POST['description']);
    $estimateWaitTime = trim($_POST['estimateWaitTime']);
    $urgentLevel = trim($_POST['urgentLevel']);


    // Validate Inputs
    if (empty($queueNumber) || empty($queueStatus) || empty($description) || empty($estimateWaitTime) || empty($urgentLevel)) {
        die("Error: All fields are required.");
    }

    if ($queueStatus === 'In Process') {
        $estimateWaitTime = "Now";
    } elseif ($queueStatus === 'Waiting') {
        // Count the number of queues currently in the "Waiting" status
        $waiting_query = "SELECT COUNT(*) AS queueCount FROM queue WHERE queueStatus = 'Waiting' AND queueID != :queueID";
        $stmt = $_db->prepare($waiting_query);
        $stmt->execute([':queueID' => $queueID]);
        $queueCount = $stmt->fetch(PDO::FETCH_ASSOC)['queueCount'];

        // Set the estimated wait time dynamically (5 minutes per queue ahead)
        $estimateWaitTime = (($queueCount + 1) * 5) . " minutes";
    }

    // Update Query
    $update_query = "UPDATE queue 
                     SET queueNumber = :queueNumber, 
                         queueStatus = :queueStatus, 
                         description = :description, 
                         estimateWaitTime = :estimateWaitTime, 
                         urgentLevel = :urgentLevel
                     WHERE queueID = :queueID";
    $stmt = $_db->prepare($update_query);

    try {
        $stmt->execute([
            ':queueNumber' => $queueNumber,
            ':queueStatus' => $queueStatus,
            ':description' => $description,
            ':estimateWaitTime' => $estimateWaitTime,
            ':urgentLevel' => $urgentLevel,
            ':queueID' => $queueID
        ]);
        echo "Queue updated successfully.";
        header("Location: adOnlineQueue.php");
    } catch (Exception $e) {
        die("Error updating queue: " . $e->getMessage());
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Queue Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input,
        select,
        textarea {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        input[readonly],
        select[disabled] {
            background-color: #f1f1f1;
            cursor: not-allowed;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .actions {
            text-align: center;
            margin-top: 20px;
        }

        .btn-back {
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #6c757d;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-back:hover {
            background-color: #5a6268;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Edit Queue</h1>
        <form method="POST" action="">
            <!-- Queue ID (Hidden, Not Editable) -->
            <input type="hidden" name="queueID" value="<?= htmlspecialchars($queue['queueID']) ?>">

            <!-- Queue Number (Editable) -->
            <label for="queueNumber">Queue Number:</label>
            <input type="text" id="queueNumber" name="queueNumber" value="<?= htmlspecialchars($queue['queueNumber']) ?>" readonly>

            <!-- Queue Status (Editable Dropdown) -->
            <label for="queueStatus">Queue Status:</label>
            <select id="queueStatus" name="queueStatus" required>
                <option value="Waiting" <?= $queue['queueStatus'] === 'Waiting' ? 'selected' : '' ?>>Waiting</option>
                <option value="In Process" <?= $queue['queueStatus'] === 'In Process' ? 'selected' : '' ?>>In Process</option>
                <option value="Completed" <?= $queue['queueStatus'] === 'Completed' ? 'selected' : '' ?>>Completed</option>
            </select>

            <!-- Description (Editable Textarea) -->
            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="5" required><?= htmlspecialchars($queue['description']) ?></textarea>

            <label for="estimateWaitTime">Estimated Wait Time:</label>
            <input type="text" id="estimateWaitTime" name="estimateWaitTime" value="<?= htmlspecialchars($queue['estimateWaitTime']) ?>" readonly>

            <!-- Urgent Level (Editable Dropdown) -->
            <label for="urgentLevel">Urgent Level:</label>
            <select id="urgentLevel" name="urgentLevel" required>
                <option value="Low" <?= $queue['urgentLevel'] === 'Low' ? 'selected' : '' ?>>Low</option>
                <option value="Normal" <?= $queue['urgentLevel'] === 'Normal' ? 'selected' : '' ?>>Normal</option>
                <option value="High" <?= $queue['urgentLevel'] === 'High' ? 'selected' : '' ?>>High</option>
            </select>

            <button type="submit">Save Changes</button>
        </form>

        <div class="actions">
            <a href="adOnlineQueue.php" class="btn-back">Back to Queue List</a>
        </div>
    </div>
</body>

</html>
<script>
    function updateEstimateTime() {
        const statusDropdown = document.getElementById("queueStatus");
        const estimateTimeField = document.getElementById("estimateWaitTime");

        // Change estimated wait time to "Now" if status is "In Process"
        if (statusDropdown.value === "In Process") {
            estimateTimeField.value = "Now";
            estimateTimeField.readOnly = true; // Make the field read-only
        } else {
            estimateTimeField.value = ""; // Clear the value for other statuses
            estimateTimeField.readOnly = false; // Make it editable again
        }
    }
</script>