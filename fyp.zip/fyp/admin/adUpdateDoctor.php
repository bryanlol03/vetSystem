<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Update Doctor</title>
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    .pet-image {
        border-radius: 50%;
        object-fit: cover;
        width: 150px;
        /* Set the width for a consistent size */
        height: 150px;
        /* Set the height for a consistent size */
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        transition: transform 0.3s ease;
        display: block;
        margin: 0 auto 20px auto;
        /* Center the image */
    }

    .pet-image:hover {
        transform: scale(1.1);
    }

    .dark-mode .card {
        background-color: #1c1c1c;
        box-shadow: 0 6px 18px rgba(255, 255, 255, 0.2);
    }

    .dark-mode .form-label {
        color: white;
    }

    .dark-mode .list-group-item {
        background-color: #1c1c1c;
        color: #fff;
    }

    .dark-mode .list-group-item.active {
        background-color: #007bff;
    }

    .dark-mode .form-control {
        background-color: #333;
        border-color: #555;
        color: #fff;
    }

    .dark-mode .btn-default {
        background-color: #555;
        color: #ddd;
    }

    /* Mode Button Styling with Icons */
    .mode-toggle-btn {
        position: absolute;
        top: 20px;
        right: 20px;
        padding: 12px 15px;
        border-radius: 50px;
        font-size: 20px;
        background-color: #007bff;
        color: white;
        border: none;
        cursor: pointer;
        transition: all 0.3s ease;

        /* Use Flexbox to center content */
        display: flex;
        align-items: center;
        /* Center vertically */
        justify-content: center;
        /* Center horizontally */
    }

    .mode-toggle-btn i {
        margin-right: 12px;
        /* Space between icon and text */
    }


    .dark-mode .mode-toggle-btn {
        background-color: #f8f7f6;
        color: black;
    }

    .media-body {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        margin-top: 15px;
    }
</style>
<?php
include '../_base.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the staff ID is passed in the URL
if (!isset($_GET['id'])) {
    header("Location: docDashboard.php");
    exit();
}

$staff_id = (int)$_GET['id'];

// Fetch staff information from the database
$stmt_staff = $_db->prepare("SELECT * FROM staff WHERE staffID = :staff_id");
$stmt_staff->bindParam(':staff_id', $staff_id, PDO::PARAM_INT);
$stmt_staff->execute();
$staff = $stmt_staff->fetch(PDO::FETCH_OBJ);

if (!$staff) {
    header("Location: adDashboard.php");
    exit();
}

// Handle profile updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $contact = trim($_POST['contact']);
    $status = trim($_POST['status']);
    $role = trim($_POST['role']);
    $hire_date = trim($_POST['hire_date']);
    $profile_photo = $staff->profilePhoto; // Default to existing photo
    $errors = [];

    // Server-Side Validation
    if (empty($name)) {
        $errors['name'] = 'Name is required.';
    } elseif (strlen($name) < 3 || strlen($name) > 100) {
        $errors['name'] = 'Name must be between 3 and 100 characters.';
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        $errors['name'] = 'Name can only contain letters and spaces (no numbers or special characters).';
    }

    if (empty($username)) {
        $errors['username'] = 'Username is required.';
    } elseif (!preg_match("/^[a-zA-Z0-9]+$/", $username)) {
        $errors['username'] = 'Username can only contain letters and numbers (no special characters).';
    }

    if (empty($contact)) {
        $errors['contact'] = 'Contact number is required.';
    } elseif (!preg_match('/^\d{10}$/', $contact)) {
        $errors['contact'] = 'Contact number must be exactly 10 digits and cannot contain special characters.';
    }

    if (!empty($_FILES['profile_photo']['name'])) {
        $file = $_FILES['profile_photo'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

        if (!in_array($file['type'], $allowed_types)) {
            $errors['profile_photo'] = 'File must be an image (JPG, PNG, GIF).';
        } elseif ($file['size'] > 800 * 1024) { // Max 800 KB
            $errors['profile_photo'] = 'Image must be smaller than 800 KB.';
        } else {
            $profile_photo = uniqid() . '_' . basename($file['name']);
            $upload_dir = '../img/staffPhoto/';
            $upload_path = $upload_dir . $profile_photo;

            if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
                $errors['profile_photo'] = 'Failed to upload photo.';
            } else {
                if (!empty($staff->profilePhoto) && file_exists($upload_dir . $staff->profilePhoto) && $staff->profilePhoto !== 'unknown.jpg') {
                    unlink($upload_dir . $staff->profilePhoto);
                }
            }
        }
    }

    // Update the database if no errors
    if (empty($errors)) {
        $stmt_update = $_db->prepare("
            UPDATE staff 
            SET name = :name, username = :username, contact = :contact, status = :status, role = :role, hireDate = :hire_date, profilePhoto = :profilePhoto
            WHERE staffID = :staff_id
        ");
        $stmt_update->bindParam(':name', $name);
        $stmt_update->bindParam(':username', $username);
        $stmt_update->bindParam(':contact', $contact);
        $stmt_update->bindParam(':status', $status);
        $stmt_update->bindParam(':role', $role);
        $stmt_update->bindParam(':hire_date', $hire_date);
        $stmt_update->bindParam(':profilePhoto', $profile_photo);
        $stmt_update->bindParam(':staff_id', $staff_id, PDO::PARAM_INT);

        if ($stmt_update->execute()) {
            header("Location: adManageDoctor.php");
            exit();
        } else {
            $errors['general'] = 'Failed to update profile. Please try again.';
        }
    }

    // Store errors in session to display them on the form page
    $_SESSION['errors'] = $errors;
}
?>

<body>
    <div class="container light-style flex-grow-1 container-p-y">
        <h4 class="font-weight-bold py-3 mb-4">Update Doctor Profile</h4>

        <!-- Profile Update Form -->
        <form method="POST" enctype="multipart/form-data">
            <div class="card overflow-hidden">
                <div class="row no-gutters row-bordered row-border-light">
                    <div class="col-md-3 pt-0">
                        <div class="list-group list-group-flush account-settings-links">
                            <a class="list-group-item list-group-item-action active" data-toggle="list" href="#account-general">General</a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="tab-content">
                            <div class="tab-pane fade active show" id="account-general">
                                <div class="card-body media align-items-center">
                                    <img src="../img/staffPhoto/<?php echo htmlspecialchars($staff->profilePhoto) ?: 'unknown.jpg'; ?>" alt="Staff Photo" class="pet-image">
                                    <div class="media-body">
                                        <label class="btn btn-outline-primary file-upload-label">
                                            Choose File
                                            <input type="file" class="account-settings-fileinput" name="profile_photo" accept=".jpg,.jpeg,.png">
                                        </label>
                                        <div class="file-chosen text-muted small mt-1">No file chosen</div>
                                    </div>
                                </div>
                                <hr class="border-light m-0">
                                <div class="card-body">
                                    <!-- Editable Fields: Name, Username, Contact, Status, Role, Hire Date -->
                                    <div class="form-group">
                                        <label class="form-label">Name</label>
                                        <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($staff->name); ?>" required minlength="3" maxlength="100">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Username</label>
                                        <input type="text" class="form-control" name="username" value="<?php echo htmlspecialchars($staff->username); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Contact</label>
                                        <input type="text" class="form-control" name="contact" value="<?php echo htmlspecialchars($staff->contact); ?>" required pattern="\d{10}" title="Contact number must be exactly 10 digits.">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Status</label>
                                        <select class="form-control" name="status" required>
                                            <option value="Active" <?php echo $staff->status === 'Active' ? 'selected' : ''; ?>>Active</option>
                                            <option value="Inactive" <?php echo $staff->status === 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Role</label>
                                        <select class="form-control" name="role" required>
                                            <option value="Veterinarian" <?php echo $staff->role === 'Veterinarian' ? 'selected' : ''; ?>>Veterinarian</option>
                                            <option value="Nurse" <?php echo $staff->role === 'Nurse' ? 'selected' : ''; ?>>Nurse</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Hire Date</label>
                                        <input type="date" class="form-control" name="hire_date" value="<?php echo htmlspecialchars($staff->hireDate); ?>" readonly>
                                    </div>

                                    <!-- Non-editable Fields: Email, Password -->
                                    <div class="form-group">
                                        <label class="form-label">Email</label>
                                        <input type="email" class="form-control" value="<?php echo htmlspecialchars($staff->email); ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Password</label>
                                        <input type="password" class="form-control" value="********" readonly>
                                        <small class="form-text text-muted">Password is not editable.</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-right mt-3">
                    <button type="submit" class="btn btn-primary" name="update_profile">Save Changes</button>
                    <a href="adDashboard.php" class="btn btn-default">Cancel</a>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.js"></script>
</body>

</html>
<script>
    // Toggle between light and dark mode using button
    document.getElementById('modeToggleBtn').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        if (document.body.classList.contains('dark-mode')) {
            this.innerHTML = '<i class="fas fa-sun"></i>';
        } else {
            this.innerHTML = '<i class="fas fa-moon"></i>';
        }
    });

    document.getElementById('fileInput').addEventListener('change', function() {
        const fileName = this.files[0] ? this.files[0].name : 'No file chosen';
        document.getElementById('fileChosen').textContent = fileName;
    });

    <?php if (isset($_SESSION['errors']) && !empty($_SESSION['errors'])): ?>
        Swal.fire({
            title: 'Error!',
            text: '<?php echo implode(", ", $_SESSION['errors']); ?>',
            icon: 'error',
            confirmButtonText: 'OK'
        });
        <?php unset($_SESSION['errors']); ?>
    <?php endif; ?>
    document.addEventListener("DOMContentLoaded", function() {
        // Toggle between light and dark mode using button
        document.getElementById('modeToggleBtn').addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            this.innerHTML = document.body.classList.contains('dark-mode') ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
        });

        // Display chosen file name
        document.querySelector(".account-settings-fileinput").addEventListener("change", function() {
            const fileName = this.files[0] ? this.files[0].name : 'No file chosen';
            document.querySelector(".file-chosen").textContent = fileName;
        });

        // Form validation
        document.querySelector("form").addEventListener("submit", function(event) {
            let errors = [];
            const name = document.querySelector("input[name='name']").value;
            const username = document.querySelector("input[name='username']").value;
            const contact = document.querySelector("input[name='contact']").value;

            // Name validation
            if (name.length < 3 || name.length > 100) {
                errors.push("Name must be between 3 and 100 characters.");
            } else if (!/^[a-zA-Z\s]+$/.test(name)) {
                errors.push("Name can only contain letters and spaces.");
            }

            // Username validation
            if (!/^[a-zA-Z0-9]+$/.test(username)) {
                errors.push("Username can only contain letters and numbers.");
            }

            // Contact validation
            if (!/^\d{10}$/.test(contact)) {
                errors.push("Contact number must be exactly 10 digits.");
            }

            // Check for errors
            if (errors.length > 0) {
                event.preventDefault(); // Prevent form submission
                alert(errors.join("\n")); // Display errors as an alert
            }
        });
    });
</script>
</body>

</html>