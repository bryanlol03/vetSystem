<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Add Patient</title>
    <link rel="icon" href="../img/logo.png">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>

    <?php
    include '../_base.php'; // Ensure this is the correct path for your base connection
    include '../helper/adHelper.php';

    // Maximum number of pets allowed
    $max_pets = 3;
    $error = '';
    $success = '';
    $user_id = null;
    $require_pet_registration = false;

    // Check if form is submitted to register user
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['save_user'])) { // Check if the user form was submitted
            $username = isset($_POST['uname']) ? trim($_POST['uname']) : '';
            $name = isset($_POST['name']) ? trim($_POST['name']) : '';
            $email = isset($_POST['email']) ? trim($_POST['email']) : '';
            $gender = isset($_POST['gender']) ? trim($_POST['gender']) : '';
            $contact = isset($_POST['contact']) ? trim($_POST['contact']) : '';
            $address = isset($_POST['address']) ? trim($_POST['address']) : '';
            $password = sha1('123456');

            // Handle profile photo upload
            $profile_photo = 'unknown.jpg'; // Default photo
            if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['profile_photo'];
                $file_type = mime_content_type($file['tmp_name']);
                $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];

                if (in_array($file_type, $allowed_types) && $file['size'] <= 800 * 1024) { // 800KB size limit
                    $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $profile_photo = uniqid() . '.' . $file_extension;
                    $upload_dir = '../img/userPhoto/';
                    $upload_path = $upload_dir . $profile_photo;
                    move_uploaded_file($file['tmp_name'], $upload_path);
                } else {
                    $error = 'Invalid file type or file too large. Only JPG, JPEG, and PNG files under 800KB are allowed.';
                }
            }

            // Validate user information
            if (empty($username) || strlen($username) > 50) {
                $error = 'Username is required and must be less than 50 characters.';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = 'Invalid email format.';
            } elseif (!preg_match('/^\d{9,11}$/', $contact)) {
                $error = 'Contact number must be 9-11 digits.';
            } elseif (empty($address)) {
                $error = 'Address is required.';
            } else {
                // Check if username already exists
                $stmt = $_db->prepare("SELECT COUNT(*) FROM petOwner WHERE username = ?");
                $stmt->execute([$username]);
                if ($stmt->fetchColumn() > 0) {
                    $error = 'Username already exists.';
                } else {
                    // Insert user into database
                    $stmt_insert_user = $_db->prepare("
                        INSERT INTO petOwner (username, name, email, gender, contact, address, profile_photo, password)
                        VALUES (:username, :name, :email, :gender, :contact, :address, :profile_photo, :password)
                    ");
                    $stmt_insert_user->bindParam(':username', $username);
                    $stmt_insert_user->bindParam(':name', $name);
                    $stmt_insert_user->bindParam(':email', $email);
                    $stmt_insert_user->bindParam(':gender', $gender);
                    $stmt_insert_user->bindParam(':contact', $contact);
                    $stmt_insert_user->bindParam(':address', $address);
                    $stmt_insert_user->bindParam(':profile_photo', $profile_photo);
                    $stmt_insert_user->bindParam(':password', $password);

                    if ($stmt_insert_user->execute()) {
                        $user_id = $_db->lastInsertId();
                        $success = 'User registered successfully! Please register at least one pet.';
                        $require_pet_registration = true;
                    } else {
                        $error = 'Failed to register user.';
                    }
                }
            }
        }

        // Handle adding a new pet
        if (isset($_POST['save_pet']) && isset($_POST['user_id'])) { // Ensure user_id is passed
            $user_id = (int)$_POST['user_id']; // Retrieve the user_id from the form
            $pet_name = isset($_POST['petName']) ? trim($_POST['petName']) : '';
            $species = isset($_POST['species']) ? trim($_POST['species']) : '';
            $breed = isset($_POST['breed']) ? trim($_POST['breed']) : '';
            $age = isset($_POST['age']) ? (int)trim($_POST['age']) : 0;
            $pet_gender = isset($_POST['pet_gender']) ? trim($_POST['pet_gender']) : '';
            $profile_photo = 'unknown.jpg';

            // Validate pet information
            if (empty($pet_name) || strlen($pet_name) > 50) {
                $error = 'Pet name is required and must be less than 50 characters.';
            } elseif (empty($species) || strlen($species) > 30) {
                $error = 'Species is required and must be less than 30 characters.';
            } elseif (empty($breed) || strlen($breed) > 30) {
                $error = 'Breed is required and must be less than 30 characters.';
            } elseif ($age < 0 || $age > 30) {
                $error = 'Age must be between 0 and 30 years.';
            } else {
                // Insert pet into database
                $stmt_insert_pet = $_db->prepare("
                    INSERT INTO pet (name, species, breed, age, gender, profilePhoto, petOwnerID)
                    VALUES (:name, :species, :breed, :age, :gender, :profile_photo, :owner_id)
                ");
                $stmt_insert_pet->bindParam(':name', $pet_name);
                $stmt_insert_pet->bindParam(':species', $species);
                $stmt_insert_pet->bindParam(':breed', $breed);
                $stmt_insert_pet->bindParam(':age', $age);
                $stmt_insert_pet->bindParam(':gender', $pet_gender);
                $stmt_insert_pet->bindParam(':profile_photo', $profile_photo);
                $stmt_insert_pet->bindParam(':owner_id', $user_id, PDO::PARAM_INT);

                if ($stmt_insert_pet->execute()) {
                    $success = 'Pet registered successfully!';
                } else {
                    $error = 'Failed to register pet.';
                }
            }
        }
    }
    ?>

    <!-- SweetAlert2 Notifications -->
    <?php if ($success): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '<?php echo $success; ?>'
            });
        </script>
    <?php endif; ?>

    <?php if ($error): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '<?php echo $error; ?>'
            });
        </script>
    <?php endif; ?>

    <!-- User Information Form -->
    <div class="content-subheader"></div>
    <div class="grid grid--margin bg-white">
        <div class="grid__row">
            <div class="grid__col grid__col--padding">
                <h3 class="grid__col-title">Patient Information</h3>
            </div>
        </div>
        <form method="POST" enctype="multipart/form-data">
            <div class="grid__row grid__row--margin">
                <div class="grid__col grid__col--13 grid__col--margin">
                    <div class="card-body media align-items-center">
                        <img src="../img/userPhoto/unknown.jpg" alt="User Photo" class="pet-image" id="currentPhoto">
                        <div class="media-body">
                            <label class="btn btn-outline-primary file-upload-label">
                                Choose Profile Image
                                <input type="file" class="account-settings-fileinput" name="profile_photo" accept=".jpg,.jpeg,.png">
                            </label>
                            <div class="file-chosen text-muted small mt-1">No file chosen</div>
                            <small class="error" id="photoError"></small>
                        </div>
                    </div>
                    <label class="form__label">Username</label>
                    <input name="uname" class="form__input required" type="text" placeholder="yen03" required>
                    <label class="form__label">Name</label>
                    <input name="name" class="form__input required" type="text" placeholder="yen" required>
                    <label class="form__label">EMAIL *</label>
                    <input name="email" class="form__input required email" type="email" required>
                    <label class="form__label">GENDER</label>
                    <select name="gender" class="form__select" required>
                        <option value="">Choose a gender</option>
                        <option value="Female">Female</option>
                        <option value="Male">Male</option>
                        <option value="Other">Other</option>
                    </select>
                    <label class="form__label">Contact *</label>
                    <input name="contact" class="form__input required" type="text" required>
                    <label class="form__label">Address *</label>
                    <input name="address" class="form__input required" type="text" required>
                </div>
            </div>
            <div class="grid__row grid__row--margin">
                <div class="grid__col grid__col--margin">
                    <button type="submit" name="save_user" class="button button--submit button--blue-bg">Save User</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Pet Information Form -->
    <?php if ($require_pet_registration): ?>
        <div class="grid grid--margin bg-white">
            <div class="grid__row">
                <div class="grid__col grid__col--padding">
                    <h3 class="grid__col-title">Pet Information</h3>
                </div>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="user_id" value="<?php echo $user_id; ?>"> <!-- Hidden input to pass user_id -->
                <div class="grid__row grid__row--margin">
                    <div class="grid__col grid__col--37 grid__col--margin">
                        <label for="pet_profile_photo">Pet Profile Photo</label>
                        <input type="file" class="form-control-file" name="pet_profile_photo" accept=".jpg,.jpeg,.png">
                        <small class="form-text text-muted">Accepted formats: JPG, JPEG, PNG. Max size: 800KB.</small>
                    </div>
                    <div class="grid__col grid__col--37 grid__col--margin">
                        <label class="form__label">Pet Name</label>
                        <input type="text" name="petName" class="form__input" required>
                    </div>
                    <div class="grid__col grid__col--37 grid__col--margin">
                        <label class="form__label">Species</label>
                        <input type="text" name="species" class="form__input" required>
                    </div>
                    <div class="grid__col grid__col--37 grid__col--margin">
                        <label class="form__label">Gender</label>
                        <select name="pet_gender" class="form__select" required>
                            <option value="">Choose a gender</option>
                            <option value="Female">Female</option>
                            <option value="Male">Male</option>
                        </select>
                    </div>
                    <div class="grid__col grid__col--37 grid__col--margin">
                        <label class="form__label">Breed</label>
                        <input type="text" name="breed" class="form__input" required>
                    </div>
                    <div class="grid__col grid__col--37 grid__col--margin">
                        <label class="form__label">Age</label>
                        <input type="number" name="age" class="form__input" min="0" max="30" required>
                    </div>
                </div>
                <div class="grid__row grid__row--margin">
                    <div class="grid__col grid__col--margin">
                        <button type="submit" name="save_pet" class="button button--submit button--blue-bg">Save Pet</button>
                    </div>
                </div>
            </form>
        </div>
    <?php endif; ?>


    <script src="../js/jquery-3.3.1.min.js"></script>
    <script>
        $(document).ready(function() {
            let petCount = <?php echo json_encode($pet_count); ?>;
            const maxPets = <?php echo $max_pets; ?>;
            if (petCount >= maxPets) {
                $('button[name="add_pet"]').prop('disabled', true);
            }
        });
    </script>


    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/moment.min.js"></script>
    <script src="../js/select2.min.js"></script>
    <script src="../js/dropzone.js"></script>
    <script src="../js/daterangepicker.min.js"></script>
    <script src="../js/ion.rangeSlider.min.js"></script>
    <script src="../js/jquery.dashboard-custom.js"></script>
</body>
</body>

</html>