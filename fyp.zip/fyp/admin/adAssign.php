<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/app.css">
    <link rel="icon" href="../photos/images/favicon.png">
    <title>Assign Staff Schedule</title>
    <style>
        /* Font Import */
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap');

        body {
            font-family: 'Roboto', sans-serif;
            display: flex;
            background: linear-gradient(135deg, #3a1c71, #d76d77, #ffaf7b);
            margin: 0;
            padding: 20px;
        }

        .container {
            width: 800px;
            height: auto;
            background-color: #fff;
            display: flex;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            overflow: hidden;
        }

        .container .image {
            width: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
        }

        .container .image img {
            width: 100%;
            height: 100%;
            border-radius: 12px 0 0 12px;
        }

        .container .form-side {
            width: 50%;
            padding: 40px;
            background-color: #2b2b2b;
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .form-side h2 {
            margin: 0;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 800;
            text-align: left;
            color: #fff;
        }

        .form-side label {
            font-size: 14px;
            color: #ccc;
            margin-bottom: 6px;
            display: block;
        }

        .form-side select,
        .form-side button {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #555;
            background-color: #333;
            color: #fff;
            font-size: 14px;
        }

        .form-side select {
            appearance: none;
        }

        .form-side button[type="submit"] {
            background-color: #00C853;
            border: none;
            width: 100%;
            border-radius: 5px;
            font-size: 16px;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-side button[type="submit"]:hover {
            background-color: #00a044;
        }

        .form-side button.back-button {
            background-color: transparent;
            color: #ccc;
            border: 1px solid #555;
            margin-top: 10px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .form-side button.back-button:hover {
            background-color: #555;
            color: #fff;
        }
    </style>
</head>

<body>
    <?php
    include '../_base.php';

    // Fetch active staff members
    $staffQuery = $_db->query("
    SELECT staff.staffID, staff.name 
    FROM staff
    LEFT JOIN schedule ON staff.staffID = schedule.staffID
    WHERE staff.role = 'Veterinarian' 
      AND staff.status = 'Active'
      AND schedule.staffID IS NULL
");
    $staffMembers = $staffQuery->fetchAll(PDO::FETCH_ASSOC);

    $daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    ?>

    <div class="container">
        <div class="image">
            <img src="../photos/images/staff.jpg" alt="Staff Image">
        </div>

        <div class="form-side">
            <h2>Assign Staff Schedule</h2>

            <form method="post" novalidate>
                <label for="staff_id">Select Staff</label>
                <select id="staff_id" name="staff_id" required>
                    <?php foreach ($staffMembers as $staff): ?>
                        <option value="<?= htmlspecialchars($staff['staffID']) ?>">
                            <?= htmlspecialchars($staff['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="day_of_week">Select Working Days (Max 6)</label>
                <div id="day_of_week">
                    <?php foreach ($daysOfWeek as $day): ?>
                        <label>
                            <input type="checkbox" name="day_of_week[]" value="<?= $day ?>" onchange="validateCheckboxLimit(this)"> <?= $day ?>
                        </label>
                    <?php endforeach; ?>
                </div>
                
                <button type="submit">Assign Schedule</button>
                <button type="button" class="back-button" onclick="window.location.href='adListSchedule.php'">Back to List</button>
            </form>
        </div>
    </div>
</body>

</html>
<script>
    function validateCheckboxLimit(checkbox) {
        const checkboxes = document.querySelectorAll('input[name="day_of_week[]"]:checked');
        if (checkboxes.length > 6) {
            alert('You can select up to 6 working days only.');
            checkbox.checked = false;
        }
    }
</script>
<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['staff_id'], $_POST['day_of_week'])) {
    $staffID = (int)$_POST['staff_id'];
    $workingDays = $_POST['day_of_week']; // Selected working days (array)

    if (count($workingDays) > 6) {
        echo "You can select up to 6 working days only.";
        exit;
    }

    $allDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    $restDays = array_diff($allDays, $workingDays); // Automatically determine rest days

    try {
        $_db->beginTransaction();

        foreach ($allDays as $dayOfWeek) {
            $isRestDay = in_array($dayOfWeek, $restDays) ? 1 : 0;
            $roomID = random_int(1, 4); // Example logic for room assignment

            $insertStmt = $_db->prepare("
                INSERT INTO schedule (staffID, roomID, dayOfWeek, start_time, end_time, is_rest_day)
                VALUES (:staffID, :roomID, :dayOfWeek, :start_time, :end_time, :is_rest_day)
            ");

            $insertStmt->execute([
                ':staffID' => $staffID,
                ':roomID' => $roomID,
                ':dayOfWeek' => $dayOfWeek,
                ':start_time' => '09:00:00',
                ':end_time' => '18:00:00',
                ':is_rest_day' => $isRestDay,
            ]);
        }

        $_db->commit();
        echo "Schedule assigned successfully!";
    } catch (Exception $e) {
        $_db->rollBack();
        echo "Failed to assign schedule: " . $e->getMessage();
    }
} else {
    echo "Invalid request.";
}

?>