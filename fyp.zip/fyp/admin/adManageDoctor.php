<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | ManageDoctor</title>
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="../css/swiper.css">
    <link rel="stylesheet" href="../css/jquery.scrollbar.css">
    <link rel="stylesheet" href="../css/daterangepicker.css">
    <link rel="stylesheet" href="../css/select2.css">
    <link rel="stylesheet" href="../css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="../css/dashboard.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    <style>
        /* Filter Form Styling */
        form {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="date"],
        select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        button {
            padding: 10px 20px;
            background-color: #6a5acd;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #5a4cb1;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        th,
        td {
            padding: 12px 15px;
            text-align: left;
            font-size: 14px;
        }

        th {
            background-color: #6a5acd;
            color: #fff;
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f4f4f9;
        }

        tr:hover {
            background-color: #eef0f5;
        }

        img {
            border-radius: 50%;
            width: 40px;
            height: 40px;
            object-fit: cover;
        }

        h2 {
            color: #444;
            margin-top: 20px;
            font-size: 1.6em;
        }

        /* Adjust Text and Spacing */
        td a {
            color: #6a5acd;
            text-decoration: none;
            font-weight: bold;
        }

        td a:hover {
            text-decoration: underline;
        }

        .pagination {
            display: inline-block;
            margin-top: 20px;
        }

        .pagination-link {
            color: #6a5acd;
            padding: 8px 16px;
            text-decoration: none;
            font-weight: bold;
            margin: 0 2px;
            border: 1px solid #ddd;
            border-radius: 4px;
            transition: background-color 0.3s, color 0.3s;
        }

        .pagination-link:hover {
            background-color: #6a5acd;
            color: #fff;
        }

        .pagination-link.active {
            background-color: #5a4cb1;
            color: #fff;
            border-color: #5a4cb1;
        }
    </style>
</head>


<body>
    <?php
    include '../_base.php';
    include '../helper/adHelper.php';
    auth('Admin');

    $items_per_page = 5;

    // Pagination and search for Veterinarians
    $page_vet = isset($_GET['page_vet']) ? (int)$_GET['page_vet'] : 1;
    $offset_vet = ($page_vet - 1) * $items_per_page;
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';

    // Fetch total Veterinarians for pagination
    $total_vet_stm = $_db->prepare("SELECT COUNT(*) FROM staff WHERE role = 'Veterinarian' AND (name LIKE :search OR email LIKE :search)");
    $total_vet_stm->execute([':search' => '%' . $search . '%']);
    $total_vet_pages = ceil($total_vet_stm->fetchColumn() / $items_per_page);

    // Fetch Veterinarians data
    $vet_stm = $_db->prepare("SELECT * FROM staff WHERE role = 'Veterinarian' AND (name LIKE :search OR email LIKE :search) LIMIT :limit OFFSET :offset");
    $vet_stm->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
    $vet_stm->bindValue(':limit', $items_per_page, PDO::PARAM_INT);
    $vet_stm->bindValue(':offset', $offset_vet, PDO::PARAM_INT);
    $vet_stm->execute();
    $vets = $vet_stm->fetchAll(PDO::FETCH_OBJ);

    // Pagination and search for Nurses
    $page_nurse = isset($_GET['page_nurse']) ? (int)$_GET['page_nurse'] : 1;
    $offset_nurse = ($page_nurse - 1) * $items_per_page;

    // Fetch total Nurses for pagination
    $total_nurse_stm = $_db->prepare("SELECT COUNT(*) FROM staff WHERE role = 'Nurse' AND (name LIKE :search OR email LIKE :search)");
    $total_nurse_stm->execute([':search' => '%' . $search . '%']);
    $total_nurse_pages = ceil($total_nurse_stm->fetchColumn() / $items_per_page);

    // Fetch Nurses data
    $nurse_stm = $_db->prepare("SELECT * FROM staff WHERE role = 'Nurse' AND (name LIKE :search OR email LIKE :search) LIMIT :limit OFFSET :offset");
    $nurse_stm->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
    $nurse_stm->bindValue(':limit', $items_per_page, PDO::PARAM_INT);
    $nurse_stm->bindValue(':offset', $offset_nurse, PDO::PARAM_INT);
    $nurse_stm->execute();
    $nurses = $nurse_stm->fetchAll(PDO::FETCH_OBJ);
    ?>

    <div class="content-subheader">

        <div class="grid grid--margin">
        <div class="grid__row dashboard-intro">
            <div class="grid__col grid__col--margin grid__col--padding bg-white">
                  
            <form method="GET" action="adManageDoctor.php">
                <input type="text" name="search" placeholder="Search by name or email" value="<?= htmlspecialchars($search) ?>">
                <!-- <select name="role">
            <option value="all" <?= $role_filter === 'all' ? 'selected' : '' ?>>All Roles</option>
            <option value="Veterinarian" <?= $role_filter === 'Veterinarian' ? 'selected' : '' ?>>Veterinarian</option>
            <option value="Nurse" <?= $role_filter === 'Nurse' ? 'selected' : '' ?>>Nurse</option>
        </select> -->
                <input type="date" name="hired_date" value="<?= htmlspecialchars($hired_date_filter) ?>">
                <button type="submit">Filter</button>
                <button type="reset">Reset</button>
            </form>

            <button><a href="adAddDoctor.php" style="color: white;">Add Doctor</a></button>
            <h2>Veterinarians</h2>
            <table>
                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Hired Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($vets as $vet): ?>
                        <tr>
                            <td><img src="../img/staffPhoto/<?= htmlspecialchars($vet->profilePhoto) ?>" alt="Profile Photo"></td>
                            <td><?= htmlspecialchars($vet->name) ?></td>
                            <td><?= htmlspecialchars($vet->contact) ?></td>
                            <td><?= htmlspecialchars($vet->email) ?></td>
                            <td><?= htmlspecialchars($vet->gender) ?></td>
                            <td><?= htmlspecialchars($vet->role) ?></td>
                            <td><?= htmlspecialchars($vet->status) ?></td>
                            <td><?= htmlspecialchars($vet->hireDate ?? 'N/A') ?></td>
                            <td>
                                <a href="adUpdateDoctor.php?id=<?= $vet->staffID ?>">Edit</a> |
                                <form method="POST" action="adDeleteDoctor.php" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= htmlspecialchars($vet->staffID) ?>">
                                    <button type="submit" class="delete-member-btn" onclick="return confirm('Are you sure you want to inactivate this staff?');" style="color: red;">Inactive</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Pagination for Veterinarians -->
            <div class="pagination">
                <?php if ($page_vet > 1): ?>
                    <a href="?page_vet=<?= $page_vet - 1 ?>" class="pagination-link">Previous</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_vet_pages; $i++): ?>
                    <a href="?page_vet=<?= $i ?>" class="pagination-link <?= $i == $page_vet ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>

                <?php if ($page_vet < $total_vet_pages): ?>
                    <a href="?page_vet=<?= $page_vet + 1 ?>" class="pagination-link">Next</a>
                <?php endif; ?>
            </div>

            <h2>Nurses</h2>
            <table>
                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Hired Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($nurses as $nurse): ?>
                        <tr>
                            <td><img src="../img/staffPhoto/<?= htmlspecialchars($nurse->profilePhoto) ?>" alt="Profile Photo"></td>
                            <td><?= htmlspecialchars($nurse->name) ?></td>
                            <td><?= htmlspecialchars($nurse->contact) ?></td>
                            <td><?= htmlspecialchars($nurse->email) ?></td>
                            <td><?= htmlspecialchars($nurse->gender) ?></td>
                            <td><?= htmlspecialchars($nurse->role) ?></td>
                            <td><?= htmlspecialchars($nurse->status) ?></td>
                            <td><?= htmlspecialchars($nurse->hireDate ?? 'N/A') ?></td>
                            <td>
                                <a href="editDoctor.php?id=<?= $nurse->staffID ?>">Edit</a> |
                                <form method="POST" action="adDeleteDoctor.php" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= htmlspecialchars($nurse->staffID) ?>">
                                    <button type="submit" class="delete-member-btn" onclick="return confirm('Are you sure you want to inactivate this staff?');" style="color: red;">Inactive</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Pagination for Nurses -->
            <div class="pagination">
                <?php if ($page_nurse > 1): ?>
                    <a href="?page_nurse=<?= $page_nurse - 1 ?>" class="pagination-link">Previous</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_nurse_pages; $i++): ?>
                    <a href="?page_nurse=<?= $i ?>" class="pagination-link <?= $i == $page_nurse ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>

                <?php if ($page_nurse < $total_nurse_pages): ?>
                    <a href="?page_nurse=<?= $page_nurse + 1 ?>" class="pagination-link">Next</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
        </div>
        </div>
   
</body>

</html>
<script src="../js/jquery-3.3.1.min.js"></script>
<script src="../js/Chart.min.js"></script>
<script src="../js/chartjs-plugin-style.min.js"></script>
<script src="../js/charts-custom-dashboard.js"></script>
<script src="../js/moment.min.js"></script>
<script src="../js/calendar.js"></script>
<script src="../js/swiper.min.js"></script>
<script src="../js/select2.min.js"></script>
<script src="../js/jquery.scrollbar.js"></script>
<script src="../js/jquery.countdown.min.js"></script>
<script src="../js/daterangepicker.min.js"></script>
<script src="../js/ion.rangeSlider.min.js"></script>
<script src="../js/jquery.dashboard-custom.js"></script>