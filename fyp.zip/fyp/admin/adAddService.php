<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Add Service</title>
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="../css/daterangepicker.css">
    <link rel="stylesheet" href="../css/select2.css">
    <link rel="stylesheet" href="../css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="../css/dashboard.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
</head>

<body>
    <?php
    include_once '../_base.php'; // Use include_once to avoid multiple inclusions

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $status = 'Active'; // Auto-set to Active
        $servicePhoto = 'unknown.jpg'; // Default service photo

        // Retrieve form data
        $serviceName = trim($_POST['serviceName']);
        $category = trim($_POST['category']);
        $description = trim($_POST['description']);
        $servicePrice = trim($_POST['servicePrice']);

        // Basic validations
        $errors = [];
        if (empty($serviceName) || strlen($serviceName) > 100) {
            $errors[] = 'Service name is required and must be less than 100 characters.';
        }
        if (empty($category)) {
            $errors[] = 'Category is required.';
        }
        if (empty($description)) {
            $errors[] = 'Description is required.';
        }
        if (empty($servicePrice) || !is_numeric($servicePrice) || $servicePrice <= 0) {
            $errors[] = 'Service price must be a positive number.';
        }

        // Handle service photo upload
        if (!empty($_FILES['servicePhoto']['name'])) {
            $file = $_FILES['servicePhoto'];
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

            if (!in_array($file['type'], $allowed_types)) {
                $errors[] = 'File must be an image (JPG, PNG, GIF).';
            } elseif ($file['size'] > 800 * 1024) { // Max 800 KB
                $errors[] = 'Image must be smaller than 800 KB.';
            } else {
                $servicePhoto = uniqid() . '_' . basename($file['name']);
                $upload_dir = '../img/servicePhoto/';
                $upload_path = $upload_dir . $servicePhoto;

                if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
                    $errors[] = 'Failed to upload photo.';
                }
            }
        }

        if (empty($errors)) {
            // Insert into the database
            $stm = $_db->prepare('
                INSERT INTO service (serviceName, category, description, servicePrice, status, servicePhoto)
                VALUES (?, ?, ?, ?, ?, ?)
            ');
            $stm->execute([$serviceName, $category, $description, $servicePrice, $status, $servicePhoto]);

            echo '<p style="color: green;">Service added successfully!</p>';
        } else {
            // Display errors
            foreach ($errors as $error) {
                echo '<p style="color: red;">' . htmlspecialchars($error) . '</p>';
            }
        }
    }
    ?>
    <div class="grid grid--margin bg-white">
        <div class="grid__row">
            <div class="grid__col grid__col--padding">
                <h3 class="grid__col-title">Add Service</h3>
            </div>
        </div>
        <form method="post" enctype="multipart/form-data">
            <div class="grid__row grid__row--margin">
                <div class="grid__col grid__col--13 grid__col--margin">
                    <div class="form-upload" id="dropzone">
                        <!-- Image preview element -->
                        <img id="imagePreview" src="../img/servicePhoto/unknown.jpg" alt="Service Photo Preview" style="width: 150px; height: 150px; object-fit: cover; display: block; margin: 10px auto; border-radius: 8px;">

                        <div class="form-upload__message dz-message needsclick">
                            Drop image here or click to upload.
                            <input type="file" id="fileInput" name="servicePhoto" accept=".jpg,.jpeg,.png" style="display: none;">
                        </div>
                    </div>
                </div>
            
            <div class="grid__col grid__col--13 grid__col--margin">
                <div class="grid__row">
                    <div class="grid__col grid__col--margin">
                        <label class="form__label">Service Name *</label>
                        <input name="serviceName" id="serviceName" class="form__input required" type="text" required maxlength="100" />
                    </div>
                </div>
                <div class="grid__row">
                    <div class="grid__col grid__col--margin">
                        <label class="form__label">Category *</label>
                        <input name="category" id="category" class="form__input required" type="text" required />
                    </div>
                </div>
                <div class="grid__row">
                    <div class="grid__col grid__col--margin">
                        <label class="form__label">Description *</label>
                        <textarea name="description" id="description" class="form__input required" required></textarea>
                    </div>
                </div>
                <div class="grid__row">
                    <div class="grid__col grid__col--margin">
                        <label class="form__label">Service Price *</label>
                        <input name="servicePrice" id="servicePrice" class="form__input required" type="number" step="0.01" min="0" required />
                    </div>
                </div>
            </div>
    </div>
    <div class="grid__row grid__row--margin">
        <div class="grid__col grid__col--margin">
            <input type="submit" name="submit" class="button button--submit button--blue-bg" id="submit" value="ADD SERVICE" />
        </div>
    </div>
    </form>
    </div>
    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/moment.min.js"></script>
    <script src="../js/select2.min.js"></script>
    <script src="../js/dropzone.js"></script>
    <script src="../js/daterangepicker.min.js"></script>
    <script src="../js/ion.rangeSlider.min.js"></script>
    <script src="../js/jquery.dashboard-custom.js"></script>
    <script>
    // JavaScript to display chosen file name and image preview
    document.getElementById("fileInput").addEventListener("change", function(event) {
        const file = event.target.files[0];
        const fileChosen = document.getElementById("fileChosen");
        if (file) {
            fileChosen.textContent = file.name; // Display chosen file name
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById("imagePreview").src = e.target.result; // Update image preview
            };
            reader.readAsDataURL(file);
        } else {
            fileChosen.textContent = "No file chosen";
            document.getElementById("imagePreview").src = "../img/servicePhoto/unknown.jpg"; // Reset to default
        }
    });
</script>
</body>

</html>