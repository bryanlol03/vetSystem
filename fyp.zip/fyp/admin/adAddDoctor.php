<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1" />
	<title>Admin | Add Doctor</title>
	<link rel="icon" href="../img/logo.png">
	<link rel="stylesheet" href="../css/daterangepicker.css">
	<link rel="stylesheet" href="../css/select2.css">
	<link rel="stylesheet" href="../css/ion.rangeSlider.min.css">
	<link rel="stylesheet" href="../css/dashboard.min.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
</head>

<body>

	<?php
	include_once '../_base.php'; // Use include_once to avoid multiple inclusions

	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$password = sha1('123456'); // SHA1-hashed password
		$status = 'Active'; // Auto-set to Active
		$profilePhoto = 'unknown.jpg'; // Default profile photo
		$hiredDate = date('Y-m-d'); // Today's date

		// Retrieve form data
		$username =trim($_POST['username']);
		$name = trim($_POST['name']);
		$contact = trim($_POST['contact']);
		$email = trim($_POST['email']);
		$gender = trim($_POST['gender']) === '2' ? 'Male' : 'Female'; // Convert gender to 'Male' or 'Female'
		$role = trim($_POST['role']);

		// Basic validations
		$errors = [];
		if (empty($name) || strlen($name) > 100) {
			$errors[] = 'Name is required and must be less than 100 characters.';
		}
		if (empty($contact) || !preg_match('/^\d{10}$/', $contact)) {
			$errors[] = 'Valid contact number is required (exactly 10 digits).';
		}
		if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$errors[] = 'A valid email is required.';
		}
		if ($role !== 'Veterinarian' && $role !== 'Nurse') {
			$errors[] = 'Please select a valid role.';
		}

		// Check if username already exists
		$checkStmt = $_db->prepare('SELECT COUNT(*) FROM staff WHERE username = ?');
		$checkStmt->execute([$username]);
		$usernameExists = $checkStmt->fetchColumn();

		if ($usernameExists) {
			$errors[] = 'The username already exists. Please choose a different one.';
		}

		if (empty($errors)) {
			// Insert into the database
			$stm = $_db->prepare('
				INSERT INTO staff (username, password, name, contact, email, gender, role, status, profilePhoto, hireDate)
				VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
			');
			$stm->execute([$username, $password, $name, $contact, $email, $gender, $role, $status, $profilePhoto, $hiredDate]);

			echo '<p style="color: green;">Doctor added successfully!</p>';
		} else {
			// Display errors
			foreach ($errors as $error) {
				echo '<p style="color: red;">' . htmlspecialchars($error) . '</p>';
			}
		}
	}

	?>
	<?php
	//include '../helper/adHelper.php';
	?>
	<div class="grid grid--margin bg-white">
		<div class="grid__row">
			<div class="grid__col grid__col--padding">
				<h3 class="grid__col-title">Doctor Information</h3>

			</div>
		</div>
		<form method="post" enctype="multipart/form-data">
			<div class="grid__row grid__row--margin">

				<div class="grid__col grid__col--13 grid__col--margin">
					<div class="form-upload" id="dropzone">
						<div class="form-upload__message dz-message needsclick">
							Drop image here or click to upload.
						</div>
					</div>

				</div>

				<div class="grid__col grid__col--13 grid__col--margin">
					<div class="grid__row">
						<div class="grid__col grid__col--margin">
							<label class="form__label">NAME *</label>
							<input name="name" id="name" class="form__input required" type="text" required maxlength="100" />
						</div>
					</div>
					<div class="grid__row">
						<div class="grid__col grid__col--margin">
							<label class="form__label">Username *</label>
							<input name="username" id="username" class="form__input required email" type="text" required />
						</div>
					</div>
					<div class="grid__row">
						<div class="grid__col grid__col--margin">
							<label class="form__label">EMAIL *</label>
							<input name="email" id="email" class="form__input required email" type="text" required />
						</div>
					</div>
					<div class="grid__row">
						<div class="grid__col grid__col--margin">
							<label class="form__label">GENDER</label>
							<div class="form__select">
								<select name="gender" id="gender">
									<option>Choose a gender</option>
									<option value="1">Female</option>
									<option value="2">Male</option>
								</select>
							</div>
						</div>


					</div>
					<div class="grid__row">
						<div class="grid__col grid__col--margin">
							<label class="form__label">Contact No *</label>
							<input name="contact" id="contact" class="form__input required" type="text" required />
						</div>
					</div>
					<div class="grid__row">
						<div class="grid__col grid__col--margin">
							<label class="form__label">Hired Date</label>
							<input type="text" name="hiredDate" class="form__input" value="08/11/2024" />
						</div>
					</div>

				</div>

			</div>

			<div class="grid__col grid__col--13 grid__col--margin">
				<label class="form__label">Position</label>
				<select class="custom-select" name="role">
					<option value="Veterinarian">Veterinarian</option>
					<option value="Nurse">Nurse</option>
				</select>
			</div>

	</div>

	<div class="grid__row grid__row--margin">
		<div class="grid__col grid__col--margin">
			<input type="submit" name="submit" class="button button--submit button--blue-bg" id="submit" value="ADD DOCTOR" />
		</div>
	</div>
	</form>

	</div> <!-- End of Grid -->

	</div>


	</div>

	</div>
	</div>
	<script src="../js/jquery-3.3.1.min.js"></script>
	<script src="../js/moment.min.js"></script>
	<script src="../js/select2.min.js"></script>
	<script src="../js/dropzone.js"></script>
	<script src="../js/daterangepicker.min.js"></script>
	<script src="../js/ion.rangeSlider.min.js"></script>
	<script src="../js/jquery.dashboard-custom.js"></script>
</body>

</html>