<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/logo.png">
    <title>Admin | Cancel Appointment</title>
</head>

<body>
    <?php
    // Include required files and PHPMailer libraries
    include '../_base.php';
    require_once '../lib/PHPMailer.php';
    require_once '../lib/SMTP.php';

    // Ensure the user has the 'Admin' role
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
        temp('error', 'You do not have permission to perform this action.');
        redirect('adDashboard.php');
        exit();
    }

    // Enable error reporting for debugging
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    // Check if it's a POST request and the appointment ID is provided
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['appointmentID'])) {
        $appointmentID = (int)$_POST['appointmentID']; // Sanitize and fetch the appointment ID

        // Fetch the appointment information from the database
        $stm = $_db->prepare('SELECT * FROM appointment WHERE appointmentID = ?');
        $stm->execute([$appointmentID]);
        $appointment = $stm->fetch(PDO::FETCH_OBJ);

        // Check if the appointment object is valid
        if (!$appointment) {
            echo "<p>Error: Appointment not found or appointment data is not retrieved.</p>";
            exit();
        }

        // Use the pet name to fetch the corresponding petOwnerID
        $petStm = $_db->prepare('SELECT petOwnerID FROM pet WHERE name = ?');
        $petStm->execute([$appointment->petName]);
        $pet = $petStm->fetch(PDO::FETCH_OBJ);

        // Check if the petOwnerID is found
        if (!$pet || !isset($pet->petOwnerID)) {
            echo "<p>Error: Pet owner not found for the given pet name.</p>";
            exit();
        }

        // Fetch the user's email from the petOwner table
        $userEmailStm = $_db->prepare('SELECT email FROM petOwner WHERE petOwnerID = ?');
        $userEmailStm->execute([$pet->petOwnerID]);
        $user = $userEmailStm->fetch(PDO::FETCH_OBJ);

        // Check if the user's email is found
        if (!$user || !isset($user->email)) {
            echo "<p>Error: User email not found.</p>";
            exit();
        }

        // Check if the appointment is already cancelled
        if ($appointment->status === 'Cancelled') {
            temp('info', 'Appointment is already cancelled.');
        } else {
            // Update the status to "Cancelled"
            $update_stm = $_db->prepare('UPDATE appointment SET status = ? WHERE appointmentID = ?');
            $result = $update_stm->execute(['Cancelled', $appointmentID]);

            // Check if the update query was successful
            if ($result) {
                temp('info', 'Appointment status changed to cancelled successfully.');

                $mail = get_mail();

                
                require_once '../lib/PHPMailer.php';
                require_once '../lib/SMTP.php';
                
                $mail = get_mail();
                
                try {
                    $mail->addAddress('ynbryan0301@gmail.com'); // Replace with your email for testing
                    $mail->isHTML(true);
                    $mail->Subject = 'Appointment Cancel Notifications';
                    $mail->Body = 'This is a test email to check if PHPMailer is configured correctly.';
                    $mail->send();
                    echo 'Test email sent successfully.';
                } catch (Exception $e) {
                    echo 'Failed to send test email. Mailer Error: ' . $mail->ErrorInfo;
                }
                
            } else {
                temp('error', 'Failed to update appointment status.');
                var_dump($update_stm->errorInfo()); // Debugging information
            }
        }

        // Redirect to the appointment management page
        redirect('adAppointment.php');
    }
    ?>


    <!-- HTML Form for Cancelling the Appointment -->
    <form method="POST" action="">
        <?php if (isset($appointment) && isset($appointment->appointmentID)): ?>
            <input type="hidden" name="appointmentID" value="<?php echo htmlspecialchars($appointment->appointmentID); ?>">
            <button type="submit" onclick="return confirm('Are you sure you want to cancel this appointment?');">Cancel Appointment</button>
        <?php else: ?>
            <p>Error: Appointment ID is not available.</p>
        <?php endif; ?>
    </form>
</body>

</html>