<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/logo.png">
    <title>Admin | Delete Pet Owner</title>
</head>

<body>
    <?php
    include '../_base.php';

    // Ensure the user has the 'Admin' role
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
        temp('error', 'You do not have permission to perform this action.');
        redirect('adDashboard.php');
        exit();
    }

    // Enable error reporting for debugging
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    // Check if it's a POST request and the ID is provided
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
        $id = (int)$_POST['id']; // Sanitize and fetch the pet owner ID

        // Fetch the pet owner's information from the database
        $stm = $_db->prepare('SELECT * FROM petOwner WHERE petOwnerID = ?');
        $stm->execute([$id]);
        $owner = $stm->fetch(PDO::FETCH_OBJ);

        // Check if the owner object is valid
        if (!$owner) {
            echo "<p>Error: Pet owner not found or data is not retrieved.</p>";
            exit();
        }

        // Start a transaction to ensure both deletions happen together
        $_db->beginTransaction();

        try {
            // Delete associated pets first
            $delete_pets_stm = $_db->prepare('DELETE FROM pet WHERE petOwnerID = ?');
            $delete_pets_stm->execute([$id]);

            // Delete the pet owner
            $delete_owner_stm = $_db->prepare('DELETE FROM petOwner WHERE petOwnerID = ?');
            $result = $delete_owner_stm->execute([$id]);

            // Check if the deletion was successful
            if ($result) {
                $_db->commit(); // Commit the transaction
                temp('info', 'Pet owner and their pets have been deleted successfully.');
            } else {
                $_db->rollBack(); // Roll back the transaction on failure
                temp('error', 'Failed to delete pet owner.');
                // Output error information for debugging
                var_dump($delete_owner_stm->errorInfo());
            }
        } catch (Exception $e) {
            $_db->rollBack(); // Roll back the transaction on exception
            temp('error', 'An error occurred: ' . $e->getMessage());
        }

        // Redirect to the manage pet owner page
        redirect('adManageUser.php');
    }
    ?>

    <form method="POST" action="">
        <?php if (isset($owner) && isset($owner->petOwnerID)): ?>
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($owner->petOwnerID); ?>">
            <button type="submit" onclick="return confirm('Are you sure you want to delete this pet owner and their pets?');">Delete</button>
        <?php else: ?>
            <p>Error: Pet Owner ID is not available.</p>
        <?php endif; ?>
    </form>
</body>

</html>
