<?php
// Include base connection
include_once '../_base.php';

// Fetch Pet Owners, Services, Staff Members, and Pets
$petOwnerQuery = $_db->query("SELECT petOwnerID, email FROM petOwner");
$petOwners = $petOwnerQuery->fetchAll(PDO::FETCH_ASSOC);

$serviceQuery = $_db->query("SELECT serviceID, serviceName FROM service");
$services = $serviceQuery->fetchAll(PDO::FETCH_ASSOC);

$staffQuery = $_db->query("SELECT staffID, name FROM staff WHERE status = 'Active' AND role = 'Veterinarian'");
$staffMembers = $staffQuery->fetchAll(PDO::FETCH_ASSOC);

$petQuery = $_db->query("SELECT petID, name, petOwnerID, breed, gender, age FROM pet");
$pets = $petQuery->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_appointment'])) {
    $_err = []; // Initialize the error array
    $petIDs = $_POST['pet_ids'] ?? [];
    $serviceID = $_POST['serviceID'] ?? null;
    $doctorID = $_POST['staffID'] ?? null;
    $appointmentDate = $_POST['date'] ?? null;
    $appointmentTime = $_POST['time'] ?? null;
    $symptoms = trim($_POST['symptom']) ?: '-'; // Default to '-' if no symptoms are provided

    // Validate: at least one pet is selected
    if (empty($petIDs)) {
        $_err['pet_ids'] = 'Please select at least one pet for the appointment.';
    }

    // Validate: service ID
    if (!$serviceID) {
        $_err['service'] = 'Service type is required';
    }

    // Validate: doctor ID
    if (!$doctorID) {
        $_err['doctor'] = 'Preferred doctor is required';
    }

    // Validate: appointment date
    if (!$appointmentDate) {
        $_err['date'] = 'Appointment date is required';
    }

    // Validate: appointment time
    if (!$appointmentTime) {
        $_err['time'] = 'Appointment time is required';
    }

    // If no errors, proceed with booking
    if (!$_err) {
        try {
            // Check for available rooms based on the service type
            $roomQuery = $_db->prepare("
                SELECT r.roomID FROM room r
                JOIN room_service rs ON r.roomID = rs.roomID
                WHERE rs.serviceID = ? AND r.roomStatus = 'Available'
                LIMIT 1
            ");
            $roomQuery->execute([$serviceID]);
            $availableRoom = $roomQuery->fetch(PDO::FETCH_ASSOC);

            if (!$availableRoom) {
                $_err['room'] = 'No available rooms for the selected service type.';
            } else {
                $roomID = $availableRoom['roomID'];

                // Begin a transaction
                $_db->beginTransaction();

                foreach ($petIDs as $petID) {
                    // Fetch pet name using the pet ID
                    $petQuery = $_db->prepare('SELECT name FROM pet WHERE petID = :petID');
                    $petQuery->bindParam(':petID', $petID, PDO::PARAM_INT);
                    $petQuery->execute();
                    $pet = $petQuery->fetch(PDO::FETCH_ASSOC);

                    if ($pet) {
                        $petName = $pet['name'];

                        // Insert the appointment
                        $stm = $_db->prepare("
                            INSERT INTO appointment (serviceID, staffID, date, time, status, petName, roomID, symptom)
                            VALUES (?, ?, ?, ?, 'Pending', ?, ?, ?)
                        ");
                        $stm->execute([$serviceID, $doctorID, $appointmentDate, $appointmentTime, $petName, $roomID, $symptoms]);
                    }
                }

                // Update room status
                $updateRoomStatus = $_db->prepare("
                    UPDATE room SET roomStatus = 'Occupied' WHERE roomID = ?
                ");
                $updateRoomStatus->execute([$roomID]);

                // Commit the transaction
                $_db->commit();

                // Success message
                echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Appointment(s) booked successfully!'
                    }).then(() => {
                        window.location.href = '../index.php';
                    });
                </script>";
                exit;
            }
        } catch (Exception $e) {
            // Rollback transaction on error
            $_db->rollBack();
            $_err['general'] = "An error occurred: " . $e->getMessage();
        }
    }

    // Store errors in session to display them
    $_SESSION['errors'] = $_err;
    header("Location: adAppointment.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Add Appointment</title>
    <link rel="icon" href="../img/logo.png">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            color: #333;
            padding: 20px;
        }

        .form-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: auto;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input,
        select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .pet-details {
            border: 1px solid #ccc;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            display: none;
            /* Initially hidden */
        }
    </style>
    <script>
        // JavaScript function to control the number of pet details sections shown
        function showPetDetails() {
            const numberOfPets = parseInt(document.getElementById('numberOfPets').value);
            const petDetailsContainers = document.querySelectorAll('.pet-details');

            // Show or hide pet details sections based on the selected number of pets
            petDetailsContainers.forEach((container, index) => {
                if (index < numberOfPets) {
                    container.style.display = 'block';
                } else {
                    container.style.display = 'none';
                }
            });
        }

        // Function to filter pets based on the selected pet owner
        function filterPetsByOwner() {
            const petOwnerID = document.getElementById('petOwnerID').value;
            const pets = <?= json_encode($pets) ?>; // Load all pets as a JavaScript array
            let petIndex = 0; // To track the number of pets shown

            pets.forEach(pet => {
                if (pet.petOwnerID == petOwnerID && petIndex < 3) {
                    const container = document.querySelector(`.pet-details[data-index="${petIndex + 1}"]`);
                    container.querySelector('.petName').textContent = pet.name;
                    container.querySelector('.breed').value = pet.breed;
                    container.querySelector('.gender').value = pet.gender;
                    container.querySelector('.age').value = pet.age;
                    petIndex++;
                }
            });
        }
    </script>
</head>

<body>
    <div class="form-container">
        <h2>Add Appointment</h2>
        <form method="POST" enctype="multipart/form-data">
            <!-- Select Pet Owner -->
            <div class="form-group">
                <label for="petOwnerID">Select Pet Owner (Email)</label>
                <select id="petOwnerID" name="petOwnerID" required onchange="filterPetsByOwner()">
                    <option value="">-- Select --</option>
                    <?php foreach ($petOwners as $owner): ?>
                        <option value="<?= $owner['petOwnerID'] ?>"><?= htmlspecialchars($owner['email']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Select Number of Pets -->
            <div class="form-group">
                <label for="numberOfPets">Number of Pets to Visit</label>
                <select id="numberOfPets" name="numberOfPets" onchange="showPetDetails()" required>
                    <option value="">-- Select --</option>
                    <option value="1">Pet 1</option>
                    <option value="2">Pets 2</option>
                    <option value="3">Pets 3</option>
                </select>
            </div>

            <!-- Pet Details (Up to 3 Pets) -->
            <div class="pet-details" data-index="1">
                <h4>Pet 1</h4>
                <p><strong>Name:</strong> <span class="petName"></span></p>
                <div class="form-group">
                    <label for="breed1">Breed</label>
                    <input type="text" class="breed" id="breed1" name="breed1" readonly required>
                </div>
                <div class="form-group">
                    <label for="gender1">Gender</label>
                    <input type="text" class="gender" id="gender1" name="gender1" readonly required>
                </div>
                <div class="form-group">
                    <label for="age1">Age</label>
                    <input type="number" class="age" id="age1" name="age1" readonly required>
                </div>
            </div>

            <div class="pet-details" data-index="2">
                <h4>Pet 2</h4>
                <p><strong>Name:</strong> <span class="petName"></span></p>
                <div class="form-group">
                    <label for="breed2">Breed</label>
                    <input type="text" class="breed" id="breed2" name="breed2" readonly>
                </div>
                <div class="form-group">
                    <label for="gender2">Gender</label>
                    <input type="text" class="gender" id="gender2" name="gender2" readonly>
                </div>
                <div class="form-group">
                    <label for="age2">Age</label>
                    <input type="number" class="age" id="age2" name="age2" readonly>
                </div>
            </div>

            <div class="pet-details" data-index="3">
                <h4>Pet 3</h4>
                <p><strong>Name:</strong> <span class="petName"></span></p>
                <div class="form-group">
                    <label for="breed3">Breed</label>
                    <input type="text" class="breed" id="breed3" name="breed3" readonly>
                </div>
                <div class="form-group">
                    <label for="gender3">Gender</label>
                    <input type="text" class="gender" id="gender3" name="gender3" readonly>
                </div>
                <div class="form-group">
                    <label for="age3">Age</label>
                    <input type="number" class="age" id="age3" name="age3" readonly>
                </div>
            </div>

            <!-- Select Service -->
            <div class="form-group">
                <label for="serviceID">Select Service</label>
                <select id="serviceID" name="serviceID" required>
                    <option value="">-- Select --</option>
                    <?php foreach ($services as $service): ?>
                        <option value="<?= $service['serviceID'] ?>"><?= htmlspecialchars($service['serviceName']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Select Date and Time -->
            <div class="form-group">
                <label for="date">Date</label>
                <input type="date" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="time">Time</label>
                <input type="time" id="time" name="time" required>
            </div>

            <div class="form-group">
                <label for="symptom"><i class="fas fa-notes-medical"></i>Symptoms <small>(Optional)</small></label>
                <textarea id="symptom" name="symptom" rows="4" placeholder="Describe the symptoms to help the doctor diagnose quickly"></textarea>
            </div>

            <!-- Select Staff -->
            <div class="form-group">
                <label for="staffID">Select Staff</label>
                <select id="staffID" name="staffID" required>
                    <option value="">-- Select --</option>
                    <?php foreach ($staffMembers as $staff): ?>
                        <option value="<?= $staff['staffID'] ?>"><?= htmlspecialchars($staff['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit">Create Appointment</button>
        </form>
    </div>
</body>

</html>