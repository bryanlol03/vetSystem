<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/logo.png">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 30px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 16px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        table th {
            background-color: #007bff;
            color: white;
            text-align: center;
        }

        table tbody tr:nth-child(odd) {
            background-color: #f2f2f2;
        }

        .action-links {
            text-align: center;
            margin: 10px 0;
        }

        .filter-dropdown {
            display: block;
            margin: 20px auto;
            text-align: center;
        }

        .filter-dropdown select {
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        p {
            text-align: center;
            color: #555;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Staff Schedule</h2>

        <div class="action-links">
            <a href="adDashboard.php">Back</a> | 
            <a href="adAssign.php">Assign New Schedule</a>
        </div>

        <!-- Day Filter Dropdown -->
        <div class="filter-dropdown">
            <form method="GET">
                <select name="dayOfWeek" onchange="this.form.submit()">
                    <option value="">Select Day</option>
                    <option value="Monday">Monday</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                    <option value="Saturday">Saturday</option>
                    <option value="Sunday">Sunday</option>
                </select>
            </form>
        </div>

        <?php
        include '../_base.php';

        try {
            // Determine the selected day or default to showing all days
            $selectedDay = isset($_GET['dayOfWeek']) && !empty($_GET['dayOfWeek']) ? $_GET['dayOfWeek'] : null;

            $query = "
                SELECT 
                    st.staffID,
                    st.name AS staffName, 
                    st.role,
                    s.dayOfWeek, 
                    s.start_time, 
                    s.end_time,
                    r.roomNo AS roomNumber
                FROM schedule s
                JOIN staff st ON s.staffID = st.staffID
                JOIN room r ON s.roomID = r.roomID
                WHERE s.is_rest_day = 0
            ";

            // Add day filter only if a specific day is selected
            if (!empty($selectedDay)) {
                $query .= " AND s.dayOfWeek = :dayOfWeek";
            }

            $query .= " AND st.role IN ('Veterinarian', 'Nurse') ORDER BY FIELD(s.dayOfWeek, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), st.staffID";

            $scheduleQuery = $_db->prepare($query);

            if (!empty($selectedDay)) {
                $scheduleQuery->bindParam(':dayOfWeek', $selectedDay, PDO::PARAM_STR);
            }

            $scheduleQuery->execute();
            $schedules = $scheduleQuery->fetchAll(PDO::FETCH_ASSOC);

            if (count($schedules) > 0) {
                // Display the schedules in an HTML table
                echo '<table>';
                echo '<thead>';
                echo '<tr>';
                echo '<th>Staff ID</th>';
                echo '<th>Staff Name</th>';
                echo '<th>Role</th>';
                echo '<th>Day of Week</th>';
                echo '<th>Start Time</th>';
                echo '<th>End Time</th>';
                echo '<th>Room Number</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';

                foreach ($schedules as $schedule) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($schedule['staffID']) . '</td>';
                    echo '<td>' . htmlspecialchars($schedule['staffName']) . '</td>';
                    echo '<td>' . htmlspecialchars($schedule['role']) . '</td>';
                    echo '<td>' . htmlspecialchars($schedule['dayOfWeek']) . '</td>';
                    echo '<td>' . htmlspecialchars($schedule['start_time']) . '</td>';
                    echo '<td>' . htmlspecialchars($schedule['end_time']) . '</td>';
                    echo '<td>' . htmlspecialchars($schedule['roomNumber']) . '</td>';
                    echo '</tr>';
                }

                echo '</tbody>';
                echo '</table>';
            } else {
                echo '<p>No working schedules found.</p>';
            }
        } catch (Exception $e) {
            echo '<p>Error: ' . $e->getMessage() . '</p>';
        }
        ?>
    </div>
</body>

</html>
