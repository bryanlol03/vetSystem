<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Manage Room</title>
    <link rel="icon" href="../img/logo.png">
</head>

<body>
    <?php
    include '../helper/adHelper.php';
    ?>
</body>

</html>