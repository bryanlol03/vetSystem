<?php
include '../_base.php';
auth('Admin');

$petOwnerStmt = $_db->query("SELECT petOwnerID, email FROM petowner");
$petOwners = $petOwnerStmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $query = "SELECT MAX(queueNumber) AS maxQueueNumber FROM queue";
    $result = $_db->query($query)->fetch(PDO::FETCH_ASSOC);

    // Generate the next queue number
    $queueNumber = isset($result['maxQueueNumber']) ? $result['maxQueueNumber'] + 1 : 1; // Start
    $description = trim($_POST['description']);
    $urgentLevel = trim($_POST['urgentLevel']);
    $petOwnerID = isset($_POST['petOwnerID']) ? (int)$_POST['petOwnerID'] : null;

    // Validate petOwnerID
    if (!$petOwnerID) {
        $error = "Pet Owner Email is required.";
    }

    // Validate description
    if (empty($description)) {
        $error = "Description is required.";
    } elseif (!preg_match("/^[a-zA-Z0-9\s]+$/", $description)) {
        $error = "Description cannot contain special characters.";
    } elseif (str_word_count($description) < 5) {
        $error = "Description must be at least 5 words.";
    }

    // Validate urgent level
    if (empty($urgentLevel)) {
        $error = "Urgent Level is required.";
    }

    if (!isset($error)) {
        // Fetch the email for the selected petOwnerID
        $query = "SELECT email FROM petowner WHERE petOwnerID = :petOwnerID";
        $stmt = $_db->prepare($query);
        $stmt->execute([':petOwnerID' => $petOwnerID]);
        $petOwner = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$petOwner) {
            die("Error: Pet Owner not found.");
        }

        $petOwnerEmail = $petOwner['email'];

        // Estimate the wait time dynamically
        $query = "SELECT COUNT(*) AS queueCount FROM queue WHERE queueStatus = 'Waiting'";
        $queueCount = $_db->query($query)->fetch(PDO::FETCH_ASSOC)['queueCount'];
        $estimateWaitTime = ($queueCount * 10) . " minutes";

        // Auto-assign the staffID (based on least workload or availability)
        $staff_query = "
            SELECT staffID 
            FROM staff 
            WHERE status = 'Active' 
            ORDER BY 
                (SELECT COUNT(*) FROM queue WHERE staffID = staff.staffID AND queueStatus IN ('Waiting', 'In Process')) ASC 
            LIMIT 1";
        $staff_result = $_db->query($staff_query)->fetch(PDO::FETCH_ASSOC);

        if (!$staff_result) {
            die("Error: No available staff found.");
        }

        $staffID = $staff_result['staffID'];

        // Insert the new queue into the database
        $insert_query = "INSERT INTO queue (queueNumber, queueStatus, description, estimateWaitTime, urgentLevel, petOwnerID, staffID)
                         VALUES (:queueNumber, 'Waiting', :description, :estimateWaitTime, :urgentLevel, :petOwnerID, :staffID)";
        $stmt = $_db->prepare($insert_query);
        $stmt->execute([
            ':queueNumber' => $queueNumber,
            ':description' => $description,
            ':estimateWaitTime' => $estimateWaitTime,
            ':urgentLevel' => $urgentLevel,
            ':petOwnerID' => $petOwnerID,
            ':staffID' => $staffID
        ]);

        $success = "Queue successfully added.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Add Queue</title>
    <link rel="icon" href="../img/logo.png">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input,
        select,
        textarea,
        button {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            font-size: 16px;
            margin-top: 20px;
        }

        .message.error {
            color: red;
        }

        .message.success {
            color: green;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Add Queue</h1>
        <?php if (isset($error)): ?>
            <div class="message error"><?= htmlspecialchars($error) ?></div>
        <?php elseif (isset($success)): ?>
            <div class="message success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="POST" onsubmit="return validateForm()">
            <label for="petOwnerID">Pet Owner Email:</label>
            <select id="petOwnerID" name="petOwnerID" required>
                <option value="">-- Select Pet Owner Email --</option>
                <?php foreach ($petOwners as $owner): ?>
                    <option value="<?= htmlspecialchars($owner['petOwnerID']) ?>">
                        <?= htmlspecialchars($owner['email']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="5" required></textarea>

            <label for="urgentLevel">Urgent Level:</label>
            <select id="urgentLevel" name="urgentLevel" required>
                <option value="">Please Choose Your Level</option>
                <option value="Low">Low</option>
                <option value="Normal">Normal</option>
                <option value="High">High</option>
            </select>

            <button type="submit">Add Queue</button>
        </form>
        <a href="adOnlineQueue.php">Back</a>
    </div>
</body>

</html>
<script>
    function validateForm() {
        const description = document.getElementById('description').value.trim();
        const wordCount = description.split(/\s+/).length;

        // Check for empty or special characters
        if (!description) {
            alert("Description is required.");
            return false;
        } else if (!/^[a-zA-Z0-9\s]+$/.test(description)) {
            alert("Description cannot contain special characters.");
            return false;
        } else if (wordCount < 5) {
            alert("Description must be at least 5 words.");
            return false;
        }

        return true;
    }
</script>