<?php
include '../_base.php';
include '../helper/adHelper.php';
auth('Admin'); // Ensure only admins can access

// Number of records per page
$records_per_page = 6;

// Determine the current page from the query string
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$current_page = max($current_page, 1); // Ensure the current page is at least 1

// Calculate the offset for the SQL query
$offset = ($current_page - 1) * $records_per_page;

// Handle actions (Accept or Reject "Cut Queue" requests)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $queueID = (int)$_POST['queueID'];

    if ($action === 'accept') {
        $update_query = "UPDATE queue SET queueStatus = 'In Process', estimateWaitTime = 'Anytime', urgentLevel = 'High' WHERE queueID = :queueID";
        $stmt = $_db->prepare($update_query);
        $stmt->execute([':queueID' => $queueID]);
    } elseif ($action === 'reject') {
        $update_query = "UPDATE queue SET queueStatus = 'Waiting', urgentLevel = 'Normal' WHERE queueID = :queueID";
        $stmt = $_db->prepare($update_query);
        $stmt->execute([':queueID' => $queueID]);
    }
}

// Count the total number of records excluding completed status
$count_query = "SELECT COUNT(*) AS total FROM queue WHERE queueStatus != 'Completed'";
$total_records = $_db->query($count_query)->fetch(PDO::FETCH_ASSOC)['total'];

// Calculate the total number of pages
$total_pages = ceil($total_records / $records_per_page);

// Fetch the current page records
$query = "SELECT * FROM queue WHERE queueStatus != 'Completed' ORDER BY queueID ASC LIMIT :limit OFFSET :offset";
$stmt = $_db->prepare($query);
$stmt->bindParam(':limit', $records_per_page, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $queueID = (int)$_POST['queueID'];

    if ($action === 'delete') {
        // Prepare the SQL query to delete the queue
        $delete_query = "DELETE FROM queue WHERE queueID = :queueID";
        $stmt = $_db->prepare($delete_query);

        // Execute the query
        try {
            if ($stmt->execute([':queueID' => $queueID])) {
                echo "
                <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
                <script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Queue ID $queueID has been successfully deleted.'
                    }).then(() => {
                        window.location.href = 'adOnlineQueue.php'; // Redirect to queue list page
                    });
                </script>";
            } else {
                echo "
                <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
                <script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Queue ID $queueID not found!'
                    }).then(() => {
                        window.location.href = 'adNotFound.php'; // Redirect to not found page
                    });
                </script>";
            }
        } catch (Exception $e) {
            echo "
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred while deleting the queue. Please try again later.'
                }).then(() => {
                    window.location.href = 'adNotFound.php'; // Redirect to not found page
                });
            </script>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Queue Dashboard</title>
    <style>
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-accept {
            background-color: #28a745;
            color: white;
        }

        .btn-accept:hover {
            background-color: #218838;
        }

        .btn-reject {
            background-color: #dc3545;
            color: white;
        }

        .btn-reject:hover {
            background-color: #c82333;
        }

        .pagination {
            text-align: center;
            margin-top: 20px;
        }

        .pagination a {
            display: inline-block;
            margin: 0 5px;
            padding: 10px 15px;
            text-decoration: none;
            border: 1px solid #007bff;
            border-radius: 5px;
            color: #007bff;
        }

        .pagination a.active {
            background-color: #007bff;
            color: white;
        }

        .pagination a:hover {
            background-color: #0056b3;
            color: white;
        }

        .btn-edit {
            background-color: #ffc107;
            color: white;
        }

        .btn-edit:hover {
            background-color: #e0a800;
        }

        .btn-delete {
            background-color: #dc3545;
            color: white;
        }

        .btn-delete:hover {
            background-color: #c82333;
        }
    </style>
</head>

<body>

    <div class="container">
        <a href="adAddQueue.php">Add Queue</a>
        <table>
            <thead>
                <tr>
                    <th>Queue Number</th>
                    <th>Status</th>
                    <th>Description</th>
                    <th>Estimated Wait Time</th>
                    <th>Urgent Level</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($rows)): ?>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['queueNumber']) ?></td>
                            <td><?= htmlspecialchars($row['queueStatus']) ?></td>
                            <td><?= htmlspecialchars($row['description']) ?></td>
                            <td><?= htmlspecialchars($row['estimateWaitTime']) ?></td>
                            <td><?= htmlspecialchars($row['urgentLevel']) ?></td>
                            <td>
                                <?php if ($row['queueStatus'] === 'Pending'): ?>
                                    <form action="" method="POST" style="display: inline;">
                                        <input type="hidden" name="queueID" value="<?= htmlspecialchars($row['queueID']) ?>">
                                        <button type="submit" name="action" value="accept" class="btn btn-accept">Accept</button>
                                    </form>
                                    <form action="" method="POST" style="display: inline;">
                                        <input type="hidden" name="queueID" value="<?= htmlspecialchars($row['queueID']) ?>">
                                        <button type="submit" name="action" value="reject" class="btn btn-reject">Reject</button>
                                    </form>
                                <?php endif; ?>
                                <form action="adEditQueue.php" method="GET" style="display: inline;">
                                    <input type="hidden" name="queueID" value="<?= htmlspecialchars($row['queueID']) ?>">
                                    <button type="submit" class="btn btn-edit">Edit</button>
                                </form>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="queueID" value="<?= htmlspecialchars($row['queueID']) ?>">
                                    <button type="submit" name="action" value="delete" class="btn btn-delete">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No records found.</td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>

        <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?= $i ?>" class="<?= $i === $current_page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
    </div>
</body>

</html>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>