<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/logo.png">
    <link rel="stylesheet" href="css/home.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.min.css" rel="stylesheet">
    <title>Home page</title>
</head>
<style>
    .notification_icon {
        position: relative;
        margin-left: 20px;
        display: inline-block;
    }

    .notification_icon i {
        font-size: 24px;
        color: #007BFF;
        cursor: pointer;
    }

    .notification_icon .badge {
        position: absolute;
        top: -5px;
        right: -10px;
        background-color: red;
        color: white;
        font-size: 12px;
        padding: 3px 6px;
        border-radius: 50%;
        display: none;
        /* Hidden by default */
    }

    .notification_dropdown {
        display: none;
        /* Hidden by default */
        position: absolute;
        top: 30px;
        right: 0;
        background-color: white;
        border: 1px solid #ddd;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        width: 300px;
        z-index: 1000;
    }


    .notification_container {
        padding: 20px;
        margin: 20px auto;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        max-width: 800px;
    }

    .notification_item {
        border-bottom: 1px solid #ddd;
        padding: 10px 0;
    }

    .notification_item:last-child {
        border-bottom: none;
    }

    .notification_item p {
        margin: 0;
        font-size: 16px;
    }

    .notification_item a {
        color: #007BFF;
        text-decoration: none;
    }

    .notification_item a:hover {
        text-decoration: underline;
    }
</style>

<body>


    <!-- Navigation -->
    <nav>
        <?php include 'helper/header.php'; ?>
    </nav>

    <!-- Header Section -->
    <header>
        <div class="section_container header_container">
            <div class="header_image">
                <img src="img/doctor1.png" alt="Header Image 1">
                <img src="img/doctor1.png" alt="Header Image 2">
            </div>
            <div class="header_content">
                <div>
                    <p class="sub_header">Book Now</p>
                    <h1>Todo🐱🐶</h1>
                    <p class="section_subtitle">
                        Make your hajimi more happy, we are the most taiguan pet care clinic!
                        We provide treatment services to meet your requirements!
                    </p>
                    <div class="action_btns">
                        <a href="user/appointment.php">
                            <button class="btn">Make an Appointment</button>
                        </a>
                        <div class="story">
                            <div class="video_image">
                                <img src="img/appBack.jpg" alt="Story Image">
                                <span><i class="ri-play-fill"></i></span>
                            </div>
                            <span>Learn more about our story~</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Back to Top Button -->
    <button onclick="scrollToTop()" id="backToTopBtn" title="Go to top">↑</button>

    <section class="section_container destination_container">
        <div class="section_header">
            <h2 class="section_title">Discover Our Services</h2>
            <p class="section_subtitle">Explore your suitable doctor or locations around Todo</p>
        </div>

        <!-- Services Grid -->
        <div class="destination_grid" id="destinationPage1">
            <?php
            // Database connection
            $conn = new mysqli('localhost', 'root', '', 'petfyp');

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetching data from service table
            $sql = "SELECT serviceName, description, servicePhoto FROM service WHERE status = 'Active' LIMIT 0, 4";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="destination_card">';
                    echo '    <img src="img/servicePhoto/' . htmlspecialchars($row['servicePhoto']) . '" alt="' . htmlspecialchars($row['serviceName']) . '">';
                    echo '    <div class="destination_details">';
                    echo '        <p class="destination_title">' . htmlspecialchars($row['serviceName']) . '</p>';
                    echo '        <p class="destination_subtitle">' . htmlspecialchars($row['description']) . '</p>';
                    echo '    </div>';
                    echo '</div>';
                }
            } else {
                echo "<p>No services available at the moment.</p>";
            }

            // Close connection
            $conn->close();
            ?>
        </div>

        <!-- Page 2: Next 4 services -->
        <div class="destination_grid" id="destinationPage2" style="display: none;">
            <?php
            // Database connection
            $conn = new mysqli('localhost', 'root', '', 'petfyp');

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetching next 4 services from service table
            $sql = "SELECT serviceName, description, servicePhoto FROM service WHERE status = 'Active' LIMIT 4, 4";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="destination_card">';
                    echo '    <img src="img/' . htmlspecialchars($row['servicePhoto']) . '" alt="' . htmlspecialchars($row['serviceName']) . '">';
                    echo '    <div class="destination_details">';
                    echo '        <p class="destination_title">' . htmlspecialchars($row['serviceName']) . '</p>';
                    echo '        <p class="destination_subtitle">' . htmlspecialchars($row['description']) . '</p>';
                    echo '    </div>';
                    echo '</div>';
                }
            } else {
                echo "<p>No services available at the moment.</p>";
            }

            // Close connection
            $conn->close();
            ?>
        </div>

        <!-- Page 3: Next 3 services -->
        <div class="destination_grid" id="destinationPage3" style="display: none;">
            <?php
            // Database connection
            $conn = new mysqli('localhost', 'root', '', 'petfyp');

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetching next 3 services from service table
            $sql = "SELECT serviceName, description, servicePhoto FROM service WHERE status = 'Active' LIMIT 8, 3";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="destination_card">';
                    echo '    <img src="img/' . htmlspecialchars($row['servicePhoto']) . '" alt="' . htmlspecialchars($row['serviceName']) . '">';
                    echo '    <div class="destination_details">';
                    echo '        <p class="destination_title">' . htmlspecialchars($row['serviceName']) . '</p>';
                    echo '        <p class="destination_subtitle">' . htmlspecialchars($row['description']) . '</p>';
                    echo '    </div>';
                    echo '</div>';
                }
            } else {
                echo "<p>No services available at the moment.</p>";
            }

            // Close connection
            $conn->close();
            ?>
        </div>

        <!-- Pagination Controls for Destination Section -->
        <div class="pagination_controls">
            <button class="pagination_btn" id="destPrevBtn" onclick="showDestinationPage('prev')" disabled>Previous</button>
            <button class="pagination_btn" id="destNextBtn" onclick="showDestinationPage('next')">Next</button>
        </div>
    </section>

    <section class="trip">
        <div class="section_container trip_container">
            <h2 class="section_title">Meet Our Doctors</h2>
            <p class="section_subtitle">Our expert doctors are ready to help</p>

            <!-- Veterinarians Pages -->
            <?php
            // Database connection
            $conn = new mysqli('localhost', 'root', '', 'petfyp');

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch total count of veterinarians
            $count_sql = "SELECT COUNT(*) as total FROM staff WHERE role = 'Veterinarian'";
            $count_result = $conn->query($count_sql);
            $total_vets = $count_result->fetch_assoc()['total'];
            $vets_per_page = 3;
            $total_pages = ceil($total_vets / $vets_per_page);

            for ($page = 0; $page < $total_pages; $page++) {
                $offset = $page * $vets_per_page;
                echo '<div class="trip_grid" id="tripPage' . ($page + 1) . '"' . ($page > 0 ? ' style="display: none;"' : '') . '>';

                // Fetching veterinarians for each page
                $sql = "SELECT name, role, profilePhoto FROM staff WHERE role = 'Veterinarian' LIMIT $offset, $vets_per_page";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="trip_card">';
                        echo '    <img src="img/staffPhoto/' . htmlspecialchars($row['profilePhoto']) . '" alt="' . htmlspecialchars($row['name']) . '">';
                        echo '    <div class="trip_details">';
                        echo '        <p>' . htmlspecialchars($row['name']) . '</p>';
                        echo '        <p>' . htmlspecialchars($row['role']) . '</p>';
                        echo '        <div class="rating">';
                        echo '            <i class="ri-star-fill"></i> 4.5';
                        echo '        </div>';
                        echo '        <div class="booking_price">';
                        echo '            <div class="price"><span>Experience: </span>5 Years</div>';
                        echo '            <button class="book_now">Book Appointment</button>';
                        echo '        </div>';
                        echo '    </div>';
                        echo '</div>';
                    }
                } else {
                    echo "<p>No veterinarians available at the moment.</p>";
                }

                echo '</div>';
            }

            // Close connection
            $conn->close();
            ?>

            <!-- Pagination Controls for Trip Section -->
            <div class="pagination_controls">
                <button class="pagination_btn" id="tripPrevBtn" onclick="showTripPage('prev')" disabled>Previous</button>
                <button class="pagination_btn" id="tripNextBtn" onclick="showTripPage('next')">Next</button>
            </div>
        </div>

        <?php
        include_once '_base.php';
      

        // Ensure the user is logged in and session variable is set
        if (!isset($_SESSION['user_id'])) {
            header("Location: login.php"); // Redirect to login
            exit();
        }

        $user_id = $_SESSION['user_id'];

        // Fetch notifications
        $notificationsQuery = "
    SELECT message, is_read, created_at 
    FROM notifications 
    WHERE petOwnerID = :user_id -- Adjust 'user_id' to match your actual column
    ORDER BY created_at DESC
";
        $stmt = $_db->prepare($notificationsQuery);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Mark all notifications as read after fetching
        $markAsReadQuery = "
    UPDATE notifications 
    SET is_read = 1 
    WHERE petOwnerID = :user_id AND is_read = 0 -- Adjust 'user_id' to match your actual column
";
        $stmtRead = $_db->prepare($markAsReadQuery);
        $stmtRead->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmtRead->execute();
        ?>

       
    </section>

    <!-- Gallery Section -->
    <section class="gallery_hero">
        <div class="section_container hero_container">
            <div class="hero_image">
                <img src="img/checkCat.jpg" alt="Clinic Image">
            </div>
            <div class="hero_content">
                <h3>WHY PETPRO CARE</h3>
                <h1>We turn our medical center into a lively & comfy spot for your furry friend to kick back & have a blast!</h1>
                <p>In 20 awesome years, we've amped up the human-animal bond, and the adventure continues! From top-notch wellness to medical magic and more, we’re your one-stop pet hub.</p>
                <img src="img/friendly.jpg" alt="Cat Friendly Clinic" class="hero_logo">
            </div>
        </div>
    </section>

    <!-- Adding the Video Section Inside the Gallery -->
    <div class="video_container">
        <h2 class="section_title">Clinic Virtual Tour</h2>
        <p class="section_subtitle">Take a look inside our clinic</p>
        <div class="video_wrapper">
            <iframe width="853" height="480"
                src="https://www.youtube.com/embed/omj7BI7f71Y"
                title="Virtual Clinic Tour (with Dr Chow) - Atlas Vet Singapore"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerpolicy="strict-origin-when-cross-origin"
                allowfullscreen>
            </iframe>
        </div>
    </div>
    </div>
    </section>

    <!-- Subscribe Section -->
    <section class="subscribe">
        <div class="section_container subscribe_container">
            <div class="subscribe_content">
                <h2 class="section_title">Subscribe to Get Special Deals</h2>
                <p class="section_subtitle">Explore more for the threatments</p>
            </div>
            <div class="subscribe_form">
                <form action="">
                    <input type="email" placeholder="Your email here">
                    <button class="btn" type="submit">Send</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="footer">
        <?php include 'helper/footer.php'; ?>
    </footer>

</body>

</html>

<script>
    function toggleNotificationDropdown(event) {
        event.stopPropagation(); // Prevent click from propagating to document-level handler
        const dropdown = document.getElementById('notificationDropdown');
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    }

    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
        const dropdown = document.getElementById('notificationDropdown');
        if (!dropdown.contains(event.target) && event.target !== document.querySelector('.notification_icon i')) {
            dropdown.style.display = 'none';
        }
    });


    let destinationPage = 1;
    const totalDestinationPages = 3;

    function showDestinationPage(direction) {
        const destPages = [
            document.getElementById('destinationPage1'),
            document.getElementById('destinationPage2'),
            document.getElementById('destinationPage3')
        ];
        const destPrevBtn = document.getElementById('destPrevBtn');
        const destNextBtn = document.getElementById('destNextBtn');

        if (direction === 'next' && destinationPage < totalDestinationPages) {
            destinationPage++;
        } else if (direction === 'prev' && destinationPage > 1) {
            destinationPage--;
        }

        // Update the visibility of pages
        destPages.forEach((page, index) => {
            if (index + 1 === destinationPage) {
                page.style.display = 'grid';
            } else {
                page.style.display = 'none';
            }
        });

        destPrevBtn.disabled = destinationPage === 1;
        destNextBtn.disabled = destinationPage === totalDestinationPages;
    }

    let tripPage = 1;
    const totalTripPages = <?php echo $total_pages; ?>;

    function showTripPage(direction) {
        const tripPages = [];
        for (let i = 1; i <= totalTripPages; i++) {
            tripPages.push(document.getElementById('tripPage' + i));
        }
        const tripPrevBtn = document.getElementById('tripPrevBtn');
        const tripNextBtn = document.getElementById('tripNextBtn');

        if (direction === 'next' && tripPage < totalTripPages) {
            tripPage++;
        } else if (direction === 'prev' && tripPage > 1) {
            tripPage--;
        }

        // Update the visibility of pages
        tripPages.forEach((page, index) => {
            if (index + 1 === tripPage) {
                page.style.display = 'grid';
            } else {
                page.style.display = 'none';
            }
        });

        tripPrevBtn.disabled = tripPage === 1;
        tripNextBtn.disabled = tripPage === totalTripPages;
    }

    let backToTopBtn = document.getElementById("backToTopBtn");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            backToTopBtn.style.display = "block";
        } else {
            backToTopBtn.style.display = "none";
        }
    }

    // When the user clicks on the button, scroll to the top of the document
    function scrollToTop() {
        document.body.scrollTop = 0; // For Safari
        document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE, and Opera
    }


    document.addEventListener("DOMContentLoaded", function() {
        fetch('user/getNotificationCount.php')
            .then(response => response.json())
            .then(data => {
                const badge = document.getElementById('notificationCount');
                const notificationList = document.getElementById('notificationList');

                if (data.notifications.length > 0) {
                    badge.textContent = data.unreadCount;
                    badge.style.display = 'inline-block';

                    data.notifications.forEach(notification => {
                        const notificationItem = document.createElement('div');
                        notificationItem.classList.add('notification_item');

                        const message = document.createElement('p');
                        message.textContent = notification.message;

                        if (notification.link) {
                            const link = document.createElement('a');
                            link.href = notification.link;
                            link.textContent = 'View Details';
                            message.appendChild(document.createElement('br'));
                            message.appendChild(link);
                        }

                        notificationItem.appendChild(message);
                        notificationList.appendChild(notificationItem);
                    });
                } else {
                    const noNotification = document.createElement('p');
                    noNotification.textContent = 'No notifications available.';
                    notificationList.appendChild(noNotification);
                }
            });
    });


    function toggleNotificationDropdown() {
        const dropdown = document.getElementById('notificationDropdown');
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    }

    document.addEventListener("click", function(event) {
        const dropdown = document.getElementById('notificationDropdown');
        const icon = document.querySelector('.notification_icon i');
        if (!dropdown.contains(event.target) && event.target !== icon) {
            dropdown.style.display = 'none';
        }
    });
</script>