<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <link rel="icon" href="../fyp/img/logo.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.js"></script>
    <style>
        .container {
            display: none; /* Hide container, as SweetAlert will be used */
        }
    </style>
</head>
<body>
    <div class="container logout-popup">
        Logout successful
    </div>

    <?php
    include '_base.php';
    logout(); // Perform logout

    // Trigger success message with SweetAlert and redirect
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                title: 'Logged Out!',
                text: 'Logout successful',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'login.php'; // Redirect to login page
                }
            });
        });
    </script>";
    ?>

    <noscript>
        <p>You are now logged out. Please enable JavaScript to view the logout confirmation.</p>
        <meta http-equiv="refresh" content="2;url=login.php">
    </noscript>
</body>
</html>
