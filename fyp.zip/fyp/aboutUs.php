<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/logo.png">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/petCareSystem.css">
    <title>Pet Care Management System</title>
</head>

<body>
    <?php
    include 'helper/header.php';
    ?>

    <!-- About Us Section Start -->
    <section class="about-us-section py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <img class="img-fluid mb-4 mb-lg-0" src="img/aboutUs/vetClinic.jpg" alt="Veterinary Clinic">
                </div>
                <div class="col-lg-6">
                    <h2 class="font-weight-bold mb-3">Our Mission</h2>
                    <p>We are dedicated to offering personalized care for every pet that walks through our doors. Our team strives to deliver a wide range of services, from preventive wellness care to advanced medical diagnostics and emergency services. Your pet’s well-being is our number one priority, and we go above and beyond to make sure they receive the best possible care.</p>
                    <div class="row">
                        <div class="col-sm-6 mb-5">
                            &nbsp;
                            <i class="fas fa-paw text-primary" style="font-size: 70px;"></i>
                            &nbsp;
                            <h4 class="mt-2 font-weight-bold">Pet Wellness</h4>
                            <p>We focus on preventive care to keep your furry friends healthy and happy.</p>
                        </div>
                        <div class="col-sm-6 mb-5">
                            <i class="fas fa-heartbeat text-primary" style="font-size: 70px;"></i>
                            &nbsp;
                            <h4 class="mt-2 font-weight-bold">Emergency Care</h4>
                            <p>Our team is always ready to handle any pet emergency with expertise and care.</p>
                        </div>

                    </div>
                    <!-- <a href="services.html" class="btn btn-success">Learn More</a> -->
                </div>
            </div>
        </div>
    </section>
    <!-- About Us Section End -->

    <!-- Features Section Start -->
    <section class="features-section bg-light py-5">
        <div class="container">
            <h3 class="font-weight-bold mb-3 w-100 text-center">Why Choose Us? </h3>
            &nbsp;<div class="row text-center">
                <div class="col-lg-4 mb-4">
                    <i class="fas fa-stethoscope text-primary" style="font-size: 60px;"></i>
                    <h4 class="mt-3">Advanced Diagnostics</h4>
                    <p>Our clinic uses cutting-edge technology for accurate diagnoses and treatment plans.</p>
                </div>
                <div class="col-lg-4 mb-4">
                    <i class="fas fa-clinic-medical text-primary" style="font-size: 60px;"></i>
                    <h4 class="mt-3">Modern Facilities</h4>
                    <p>We have state-of-the-art equipment to cater to all your pet's medical needs.</p>
                </div>
                <div class="col-lg-4 mb-4">
                    <i class="fas fa-user-md text-primary" style="font-size: 60px;"></i>
                    <h4 class="mt-3">Experienced Staff</h4>
                    <p>Our team consists of highly trained veterinarians and support staff who love animals.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- Features Section End -->

    <!-- Team Section Start -->
    <section class="team-section py-5">
        <div class="container text-center">
            <h2 class="font-weight-bold mb-4">Meet Our Management Team</h2>
            <p>Our management team works tirelessly behind the scenes to ensure the smooth operation of our clinic, allowing our veterinarians and staff to focus on providing the best care for your pets.</p>
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card">
                        <img class="card-img-top" src="img/team/ceo.jpg" alt="Mr. James Smith">
                        <div class="card-body">
                            <h5 class="card-title">Mr. James Smith</h5>
                            <p class="card-text">Chief Executive Officer</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card">
                        <img class="card-img-top" src="img/team/coo.jpg" alt="Mrs. Linda Johnson">
                        <div class="card-body">
                            <h5 class="card-title">Mrs. Linda Johnson</h5>
                            <p class="card-text">Chief Operating Officer</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card">
                        <img class="card-img-top" src="img/team/cfo.jpg" alt="Mr. Robert Brown">
                        <div class="card-body">
                            <h5 class="card-title">Mr. Robert Brown</h5>
                            <p class="card-text">Chief Financial Officer</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card">
                        <img class="card-img-top" src="img/team/hr.jpg" alt="Ms. Emily Davis">
                        <div class="card-body">
                            <h5 class="card-title">Ms. Emily Davis</h5>
                            <p class="card-text">Human Resources Manager</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Team Section End -->

    <?php
    include 'helper/footer.php';
    ?>

    <!-- Back to Top Button -->
    <a href="#" class="btn btn-success back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>

    <!-- Custom JavaScript -->
    <script>
        $(document).ready(function() {
            // Back to top button
            $(window).scroll(function() {
                if ($(this).scrollTop() > 100) {
                    $('.back-to-top').fadeIn();
                } else {
                    $('.back-to-top').fadeOut();
                }
            });
            $('.back-to-top').click(function() {
                $('html, body').animate({
                    scrollTop: 0
                }, 1000);
                return false;
            });
        });
    </script>
</body>

</html>