<?php

// ============================================================================
// PHP Setups
// ============================================================================
date_default_timezone_set('Asia/Kuala_Lumpur');
session_start();

// ============================================================================
// General Page Functions
// ============================================================================

// Is GET request?
function is_get()
{
    return $_SERVER['REQUEST_METHOD'] == 'GET';
}

// Is POST request?
function is_post()
{
    return $_SERVER['REQUEST_METHOD'] == 'POST';
}

// Obtain GET parameter
function get($key, $value = null)
{
    $value = $_GET[$key] ?? $value;
    return is_array($value) ? array_map('trim', $value) : trim($value);
}

// Obtain POST parameter
function post($key, $value = null)
{
    $value = $_POST[$key] ?? $value;
    return is_array($value) ? array_map('trim', $value) : trim($value);
}

// Obtain REQUEST (GET and POST) parameter
function req($key, $value = null)
{
    $value = $_REQUEST[$key] ?? $value;
    return is_array($value) ? array_map('trim', $value) : trim($value);
}

// Redirect to URL
function redirect($url = null)
{
    $url ??= $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit();
}

// Set or get temporary session variable
function temp($key, $value = null)
{
    if ($value !== null) {
        $_SESSION["temp_$key"] = $value;
    } else {
        $value = $_SESSION["temp_$key"] ?? null;
        unset($_SESSION["temp_$key"]);
        return $value;
    }
}

// Obtain uploaded file --> cast to object
function get_file($key)
{
    $f = $_FILES[$key] ?? null;

    if ($f && $f['error'] == 0) {
        return (object)$f;
    }

    return null;
}

function save_photo($input, $folder, $width = 200, $height = 200, $isBase64 = false)
{
    $photo = uniqid() . '.jpg';

    require_once 'lib/SimpleImage.php';
    $img = new SimpleImage();

    // Check if the input is base64 data or an uploaded file
    if ($isBase64) {
        // Handle base64 image data (from webcam)
        $img->fromString($input) // $input will be the base64 decoded string
            ->thumbnail($width, $height)
            ->toFile("$folder/$photo", 'image/jpeg');
    } else {
        // Handle regular file upload
        $img->fromFile($input->tmp_name)
            ->thumbnail($width, $height)
            ->toFile("$folder/$photo", 'image/jpeg');
    }

    return $photo;
}

// Is money?
function is_money($value)
{
    return preg_match('/^\-?\d+(\.\d{1,2})?$/', $value);
}

// Is email?
function is_email($value)
{
    return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
}

// Is phone number?
function is_phoneNumber($value)
{
    // Allow numbers, spaces, dashes, and parentheses
    return preg_match('/^01\d{8,9}$/', $value);
}

// Return local root path
function root($path = '')
{
    return "$_SERVER[DOCUMENT_ROOT]/$path";
}

// Return base url (host + port)
function base($path = '')
{
    return "http://$_SERVER[SERVER_NAME]:$_SERVER[SERVER_PORT]/$path";
}

// ============================================================================
// HTML Helpers
// ============================================================================

// Placeholder for TODO
function TODO()
{
    echo '<span>TODO</span>';
}

// Encode HTML special characters
//function encode($value) {
//  return htmlentities($value);
//}
function encode($value)
{
    if (is_array($value)) {
        return array_map('htmlentities', $value);
    }
    return htmlentities($value);
}

// Generate <input type='text'>
function html_text($key, $attr = '')
{
    $value = encode($GLOBALS[$key] ?? '');
    echo "<input type='text' id='$key' name='$key' value='$value' $attr>";
}

// Generate <input type='password'>
function html_password($key, $attr = '')
{
    $value = encode($GLOBALS[$key] ?? '');
    echo "<input type='password' id='$key' name='$key' value='$value' $attr>";
}

function html_date($name, $attributes = '')
{
    return '<input type="date" name="' . htmlspecialchars($name) . '" ' . $attributes . '>';
}

// Generate <input type='number'>
function html_number($key, $min = '', $max = '', $step = '', $attr = '')
{
    $value = encode($GLOBALS[$key] ?? '');
    echo "<input type='number' id='$key' name='$key' value='$value'
                 min='$min' max='$max' step='$step' $attr>";
}

// Generate <input type='search'>
function html_search($key, $attr = '')
{
    $value = encode($GLOBALS[$key] ?? '');
    echo "<input type='search' id='$key' name='$key' value='$value' $attr>";
}

// Generate <textarea>
function html_textarea($key, $attr = '')
{
    $value = encode($GLOBALS[$key] ?? '');
    echo "<textarea id='$key' name='$key' $attr>$value</textarea>";
}

// Generate SINGLE <input type='checkbox'>
function html_checkbox($key, $label = '', $attr = '')
{
    $value = encode($GLOBALS[$key] ?? '');
    $status = $value == 1 ? 'checked' : '';
    echo "<label><input type='checkbox' id='$key' name='$key' value='1' $status $attr>$label</label>";
}

// Generate <input type='radio'> list
function html_radios($key, $items, $br = false)
{
    $value = encode($GLOBALS[$key] ?? '');
    echo '<div>';
    foreach ($items as $id => $text) {
        $state = $id == $value ? 'checked' : '';
        echo "<label><input type='radio' id='{$key}_$id' name='$key' value='$id' $state>$text</label>";
        if ($br) {
            echo '<br>';
        }
    }
    echo '</div>';
}

// Generate <select>
function html_select($key, $items, $default = '- Select One -', $attr = '')
{
    $value = encode($GLOBALS[$key] ?? '');
    echo "<select id='$key' name='$key' $attr>";
    if ($default !== null) {
        echo "<option value=''>$default</option>";
    }
    foreach ($items as $id => $text) {
        $state = $id == $value ? 'selected' : '';
        echo "<option value='$id' $state>$text</option>";
    }
    echo '</select>';
}

// Generate <input type='file'>
function html_file($key, $accept = '', $attr = '')
{
    echo "<input type='file' id='$key' name='$key' accept='$accept' $attr>";
}

// Generate table headers <th>
function table_headers($fields, $sort, $dir, $href = '')
{
    foreach ($fields as $k => $v) {
        $d = 'asc'; // Default direction
        $c = '';    // Default class

        if ($k == $sort) {
            $d = $dir == 'asc' ? 'desc' : 'asc';
            $c = $dir;
        }

        echo "<th><a href='?sort=$k&dir=$d&$href' class='$c'>$v</a></th>";
    }
}

// ============================================================================
// Error Handlings
// ============================================================================

// Global error array
$_err = [];

// Generate <span class='err'>
function err($key)
{
    global $_err;
    if ($_err[$key] ?? false) {
        echo "<span class='err'>$_err[$key]</span>";
    } else {
        echo '<span></span>';
    }
}

// ============================================================================
// Security
// ============================================================================

// Global user object
$_user = $_SESSION['user'] ?? null;

// Login user
function login($user, $url = '/')
{
    $_SESSION['user'] = $user;
    redirect($url);
}


// Logout user
// function logout($url = '/')
// {
//     unset($_SESSION['user']);
//     // Clear the "Remember Me" cookies on logout
//     setcookie('email', '', time() - 3600, "/");
//     setcookie('password', '', time() - 3600, "/");
//     redirect($url);
// }

function logout()
{
    // Start the session if it hasn't been started yet
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Clear session data
    session_unset();
    session_destroy();

    // Optionally, clear session cookies
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
}


// Authorization
function auth(...$roles) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Check if the user is logged in and has a role set
    if (isset($_SESSION['role'])) {
        // Check if roles are specified
        if (!empty($roles)) {
            // Allow access if the user's role matches one of the specified roles
            if (in_array($_SESSION['role'], $roles)) {
                return; // Access granted
            }
        } else {
            return; // No roles specified, access granted
        }
    }

    // If no valid session or role, redirect to login
    redirect('/login.php');
    exit;
}

// ============================================================================
// Email Functions
// ============================================================================

// Demo Accounts:
// --------------
// shun.tester@gmail.com        lhyg swqo fclv upui

// Initialize and return mail object
function get_mail()
{
    require_once 'lib/PHPMailer.php';
    require_once 'lib/SMTP.php';

    $m = new PHPMailer(true);
    $m->isSMTP();
    $m->SMTPAuth = true;
    $m->Host = 'smtp.gmail.com';
    $m->Port = 587;
    $m->Username = 'khongsy-wm21@student.tarc.edu.my';
    $m->Password = 'cgqb rbyp npeo wqkw';
    $m->CharSet = 'utf-8';
    $m->setFrom($m->Username, 'Pet Pro Care');

    return $m;
}

//get next id
function get_next_id()
{
    global $_db;

    // Query to get the maximum current ID
    $result = $_db->query("SELECT MAX(id) as max_id FROM product")->fetch();
    if ($result && $result['max_id']) {
        // Extract the numeric part and increment
        $max_id = (int)substr($result['max_id'], 1);
    } else {
        // Default to 0 if no IDs exist
        $max_id = 0;
    }

    // Generate the next ID with proper formatting
    return 'P' . str_pad($max_id + 1, 3, '0', STR_PAD_LEFT);
}

// ============================================================================
// Database Setups and Functions
// ============================================================================

// Global PDO object
$_db = new PDO('mysql:dbname=petfyp', 'root', '', [
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
]);

// Is unique?
function is_unique($value, $table, $field)
{
    global $_db;
    $stm = $_db->prepare("SELECT COUNT(*) FROM $table WHERE $field = ?");
    $stm->execute([$value]);
    return $stm->fetchColumn() == 0;
}

// Is exists?
function is_exists($value, $table, $field)
{
    global $_db;
    $query = "SELECT COUNT(*) FROM $table WHERE $field = ?";
    $stm = $_db->prepare($query);
    $stm->execute([$value]);
    return $stm->fetchColumn() > 0;
}

// ============================================================================
// Global Constants and Variables
// ============================================================================

$gender = ['Male', 'Female'];
$default_password = "123456";
// ============================================================================
// Shopping Cart
// ============================================================================

// Get shopping cart
function get_cart()
{
    return $_SESSION['cart'] ?? [];
}

// Set shopping cart
function set_cart($cart = [])
{
    $_SESSION['cart'] = $cart;
}

// Update shopping cart
function update_cart($id, $unit, $size)
{
    $cart = get_cart();

    // Create a unique key for each product-size combination
    $key = $id . '_' . $size;

    // Validate the input and ensure unit is within allowed range
    if ($unit >= 1 && $unit <= 10 && is_exists($id, 'product', 'prodID')) {
        // If product-size combination exists, update the quantity
        if (isset($cart[$key])) {
            $cart[$key]['unit'] = $unit;
        } else {
            // If not in the cart, add the product-size combination
            $cart[$key] = [
                'unit' => $unit,
                'size' => $size // Store the size with the product
            ];
        }

        ksort($cart); // Optional: Sort the cart items by product ID and size
    } else {
        // If invalid, remove the item from the cart
        unset($cart[$key]);
    }

    set_cart($cart); // Save the updated cart to the session
}
function update_cartunit($id, $unit)
{
    $cart = get_cart();

    // Check if the product exists and the unit is valid
    if ($unit >= 1 && $unit <= 10 && is_exists($id, 'product', 'prodID')) {
        // Preserve the size and update only the unit
        if (isset($cart[$id])) {
            $size = $cart[$id]['size']; // Get the current size
        } else {
            // If the product is not in the cart, get the size from some source or default
            $size = ''; // You should determine how to handle the size for new items
        }

        // Update the cart with product ID, size, and new quantity
        $cart[$id] = [
            'unit' => $unit,
            'size' => $size
        ];

        ksort($cart); // Optional: Sort the cart items by product ID
    } else {
        // Remove product from cart if invalid
        unset($cart[$id]);
    }

    set_cart($cart); // Update the session cart
}


// Generate <input type='hidden'>
function html_hidden($key, $attr = '')
{
    $value = $GLOBALS[$key] ?? '';

    // If the value is an array, serialize it
    if (is_array($value)) {
        $value = json_encode($value);  // Convert array to JSON string
    }

    echo "<input type='hidden' id='$key' name='$key' value='" . encode($value) . "' $attr>";
}

// Generate <select>
function html_searchselect($key, $items, $default = '- Select One -', $attr = '')
{
    $value = encode($GLOBALS[$key] ?? '');  // Properly encode the selected value

    if (is_array($attr)) {  // Convert attributes to a string if necessary
        $attr = implode(' ', array_map(fn($k, $v) => "$k='$v'", array_keys($attr), $attr));
    }

    echo "<select id='$key' name='$key' $attr>";

    // Default option if specified
    if ($default !== null) {
        $selected = $value === '' ? 'selected' : '';
        echo "<option value='' $selected>$default</option>";
    }

    // Loop through items and create options
    foreach ($items as $id => $text) {
        $selected = ($id == $value) ? 'selected' : '';
        echo "<option value='$id' $selected>$text</option>";
    }

    echo '</select>';
}
function html_cartselect($key, $items, $default = '- Select One -', $attr = '')
{
    // Encode the selected value and handle attributes
    $value = encode($GLOBALS[$key] ?? '');

    // If $attr is an array, convert it to a string
    if (is_array($attr)) {
        $attr = implode(' ', array_map(fn($k, $v) => "$k='$v'", array_keys($attr), $attr));
    }

    echo "<select id='$key' name='$key' $attr>";

    // Output the default option if specified
    if ($default !== null) {
        $selected = $value === '' ? 'selected' : '';
        echo "<option value='' $selected>$default</option>";
    }

    // Output each item as an option
    foreach ($items as $id => $text) {
        $selected = ($id == $value) ? 'selected' : '';
        echo "<option value='$id' $selected>$text</option>";
    }

    echo '</select>';
}

$_units = array_combine(range(1, 10), range(1, 10));

function time_ago($datetime, $full = false)
{
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = [
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    ];
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

function is_blocked($u)
{
    global $_db;
    $stm = $_db->prepare('SELECT attempts FROM login_attempts WHERE user_id = ?');
    $stm->execute([$u->id]);
    $attempt = $stm->fetch();

    if ($attempt && $attempt->attempts >= 3) {
        return true;
    }
    return false;
}

function resetLoginAttempts($u)
{
    global $_db;
    $stm = $_db->prepare('UPDATE login_attempts SET attempts = 0 WHERE user_id = ?');
    $stm->execute([$u->id]);
}


/**
 * Check if a token is expired.
 *
 * @param int $tokenId The ID of the token to check.
 * @return bool True if the token is expired, false otherwise.
 */
function token_is_expired($tokenId)
{
    global $_db; // Assuming you have a global database connection

    // Prepare the SQL statement to get the expiration time for the token
    $stm = $_db->prepare('SELECT expire FROM token WHERE id = ?');
    $stm->execute([$tokenId]);

    // Fetch the expiration time
    $tokenData = $stm->fetch(PDO::FETCH_ASSOC);

    // Check if token exists and if it is expired
    if ($tokenData) {
        $expirationTime = strtotime($tokenData['expire']);
        return $expirationTime < time(); // Returns true if expired
    }

    return true; // Token doesn't exist, treat it as expired
}


function someDatabaseFunction()
{
    global $_db;
}

//admin
