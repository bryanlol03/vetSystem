<?php
include('../_base.php');

session_start();
$userID = $_SESSION['user_id'] ?? 0;

$query = "SELECT message, link FROM notifications WHERE userID = :userID ORDER BY created_at DESC";
$stmt = $_db->prepare($query);
$stmt->bindParam(':userID', $userID);
$stmt->execute();
$notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

$unreadQuery = "SELECT COUNT(*) AS unreadCount FROM notifications WHERE userID = :userID AND status = 'Unread'";
$unreadStmt = $_db->prepare($unreadQuery);
$unreadStmt->bindParam(':userID', $userID);
$unreadStmt->execute();
$unreadCount = $unreadStmt->fetchColumn();

echo json_encode([
    'unreadCount' => $unreadCount,
    'notifications' => $notifications
]);
?>
