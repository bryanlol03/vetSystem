<?php
include '_base.php'; // Include your database configuration

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $queueNumber = isset($_POST['queueNumber']) ? (int)$_POST['queueNumber'] : null;
    $description = isset($_POST['description']) ? trim($_POST['description']) : null;

    // Input validation
    if (!$queueNumber || empty($description)) {
        $error = "Both Queue Number and Reason are required.";
    } else {
        // Check if the queue number exists
        $check_query = "SELECT * FROM queue WHERE queueNumber = :queueNumber";
        $stmt = $_db->prepare($check_query);
        $stmt->bindParam(':queueNumber', $queueNumber, PDO::PARAM_INT);
        $stmt->execute();
        $queue = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($queue) {
            // Update the queue status to "Pending" with the user's reason
            $update_query = "UPDATE queue 
            SET queueStatus = 'Pending', 
                description = :description, 
                urgentLevel = 'High', 
                estimateWaitTime = 'Anytime' 
            WHERE queueNumber = :queueNumber";
            $update_stmt = $_db->prepare($update_query);
            $update_stmt->bindParam(':queueNumber', $queueNumber, PDO::PARAM_INT);
            $update_stmt->bindParam(':description', $description, PDO::PARAM_STR);

            if ($update_stmt->execute()) {
                $success = "Your request to cut the queue has been submitted successfully.";
            } else {
                $error = "Failed to submit your request. Please try again later.";
            }
        } else {
            $error = "Invalid Queue Number. Please check and try again.";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/logo.png">
    <title>Cut Queue Request</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input,
        textarea,
        button {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
        }

        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            font-size: 16px;
            margin-top: 20px;
        }

        .message.error {
            color: red;
        }

        .message.success {
            color: green;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Cut Queue Request</h1>
        <?php if (isset($error)): ?>
            <div class="message error"><?= htmlspecialchars($error) ?></div>
        <?php elseif (isset($success)): ?>
            <div class="message success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <form action="" method="POST">
            <label for="queueNumber">Queue Number:</label>
            <input type="number" id="queueNumber" name="queueNumber" required>

            <label for="description">Reason for Cutting Queue:</label>
            <textarea id="description" name="description" rows="5" required></textarea>

            <button type="submit">Submit Request</button>
        </form>
        <div style="text-align: center; margin-top: 20px;">
            <a href="index.php">Back</a>
        </div>
    </div>
</body>

</html>