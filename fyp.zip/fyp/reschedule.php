<?php
include '_base.php';

if (!isset($_SESSION['user_id'])) {
    die('Unauthorized access.');
}

$user_id = $_SESSION['user_id'];

$query = "
    SELECT 
        a.appointmentID, 
        a.date, 
        a.time, 
        a.status, 
        a.symptom, 
        a.petName, 
        p.species, 
        p.breed, 
        a.staffID, 
        st.name AS vetName,
        po.name AS ownerName
    FROM appointment a
    JOIN pet p ON a.petName = p.name
    JOIN petowner po ON p.petOwnerID = po.petOwnerID
    JOIN staff st ON a.staffID = st.staffID
    WHERE po.petOwnerID = :user_id
    AND a.status = 'Pending Reschedule'
    ORDER BY a.date ASC
";

$stmt = $_db->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$appointment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$appointment) {
    echo "No appointment found with status 'Pending Reschedule'.";
    exit;
}

$availableSlots = [];
$selectedDate = $_POST['appointmentDate'] ?? (new DateTime('tomorrow'))->format('Y-m-d');

if ($selectedDate) {
    // Fetch the doctor's working hours for the selected date
    $scheduleQuery = "
        SELECT start_time, end_time 
        FROM schedule 
        WHERE staffID = :staffID 
        AND dayOfWeek = DAYNAME(:selectedDate) 
        AND is_rest_day = 0
    ";
    $scheduleStmt = $_db->prepare($scheduleQuery);
    $scheduleStmt->execute([
        ':staffID' => $appointment['staffID'],
        ':selectedDate' => $selectedDate,
    ]);
    $schedule = $scheduleStmt->fetch(PDO::FETCH_ASSOC);

    if ($schedule) {
        $start_time = $schedule['start_time'];
        $end_time = $schedule['end_time'];

        // Generate 1-hour slots
        $currentSlot = new DateTime($start_time);
        $endSlot = new DateTime($end_time);
        $slots = [];

        while ($currentSlot < $endSlot) {
            $slots[] = $currentSlot->format('H:i:s');
            $currentSlot->modify('+1 hour'); // 1-hour slots
        }

        // Fetch booked slots
        $bookedQuery = "
            SELECT time 
            FROM appointment 
            WHERE staffID = :staffID 
            AND date = :selectedDate 
            AND status IN ('Pending', 'Accepted')
        ";
        $bookedStmt = $_db->prepare($bookedQuery);
        $bookedStmt->execute([
            ':staffID' => $appointment['staffID'],
            ':selectedDate' => $selectedDate,
        ]);
        $bookedSlots = $bookedStmt->fetchAll(PDO::FETCH_COLUMN);

        // Exclude booked slots
        $availableSlots = array_diff($slots, $bookedSlots);
    } else {
        echo "No working schedule found for the selected date.";
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['appointmentDate']) && isset($_POST['appointmentTime'])) {
    $selectedDate = $_POST['appointmentDate'];
    $selectedTime = $_POST['appointmentTime'];
    $staffID = $appointment['staffID']; // Assuming staffID is retrieved from the current appointment

    // Query to check if the same date and time already exist for the same staff
    $conflictCheckQuery = "
        SELECT * 
        FROM appointment 
        WHERE date = :selectedDate 
        AND time = :selectedTime 
        AND staffID = :staffID
    ";
    $conflictCheckStmt = $_db->prepare($conflictCheckQuery);
    $conflictCheckStmt->execute([
        ':selectedDate' => $selectedDate,
        ':selectedTime' => $selectedTime,
        ':staffID' => $staffID,
    ]);

    $conflict = $conflictCheckStmt->fetch(PDO::FETCH_ASSOC);

    if ($conflict) {
        // Conflict found
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Time Slot Unavailable',
                    text: 'The selected time slot is already booked. Please choose another time.',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.history.back(); // Redirect user back to the form
                });
            });
        </script>";
    } else {
        // Proceed with booking/rescheduling logic
        $updateQuery = "
            UPDATE appointment 
            SET date = :newDate, time = :newTime, status = 'Pending' 
            WHERE appointmentID = :appointmentID
        ";
        $updateStmt = $_db->prepare($updateQuery);
        $updateStmt->execute([
            ':newDate' => $selectedDate,
            ':newTime' => $selectedTime,
            ':appointmentID' => $appointment['appointmentID'],
        ]);

        if ($updateStmt->rowCount() > 0) {
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'success',
                        title: 'Appointment Rescheduled',
                        text: 'Your appointment has been successfully updated.',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.href = 'index.php'; // Redirect to index after success
                    });
                });
            </script>";
        } else {
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Update Failed',
                        text: 'Failed to update the appointment. Please try again.',
                        confirmButtonText: 'OK'
                    });
                });
            </script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reschedule Appointment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="icon" href="../img/logo.png">
    <style>
        /* Add your CSS styling here */
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(115deg, #56d8e4 10%, #9f01ea 90%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .container {
            max-width: 800px;
            background: #fff;
            width: 800px;
            padding: 25px 40px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            text-align: center;
            color: #333;
        }

        .form-row {
            margin-bottom: 20px;
        }

        label {
            font-weight: 600;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        textarea[readonly] {
            background-color: #f8f8f8;
        }

        button {
            background: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button.cancel {
            background: #d9534f;
        }

        button:hover {
            opacity: 0.9;
        }

        .btn-group {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Reschedule Appointment</h2>
        <form method="POST">
            <div class="form-row">
                <label for="petName">Pet Name</label>
                <input type="text" id="petName" value="<?= htmlspecialchars($appointment['petName']) ?>" readonly>
            </div>

            <div class="form-row">
                <label for="vetName">Veterinarian</label>
                <input type="text" id="vetName" value="<?= htmlspecialchars($appointment['vetName']) ?>" readonly>
            </div>

            <div class="form-row">
                <label for="appointmentDate">Appointment Date</label>
                <input
                    type="date"
                    id="appointmentDate"
                    name="appointmentDate"
                    value="<?= htmlspecialchars($selectedDate) ?>"
                    min="<?= (new DateTime('tomorrow'))->format('Y-m-d') ?>"
                    required>
            </div>

            <div class="form-row">
                <label for="appointmentTime">Appointment Time</label>
                <select id="appointmentTime" name="appointmentTime" required>
                    <?php if (!empty($availableSlots)): ?>
                        <?php foreach ($availableSlots as $slot): ?>
                            <option value="<?= htmlspecialchars($slot) ?>"><?= htmlspecialchars($slot) ?></option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <option disabled>No available slots</option>
                    <?php endif; ?>
                </select>
            </div>

            <div class="form-row">
                <label for="symptoms">Symptoms</label>
                <textarea id="symptoms" readonly><?= htmlspecialchars($appointment['symptom']) ?></textarea>
            </div>

            <div class="btn-group">
                <button type="submit">Update Appointment</button>
                <button type="button" class="cancel" onclick="window.location.href='index.php';">Cancel</button>
            </div>
        </form>
    </div>
</body>

</html>