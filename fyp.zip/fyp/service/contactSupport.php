<?php
require '../_base.php'; // Include base configuration if applicable
include("../config.php");
require __DIR__ . "/../vendor/autoload.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
    } else {
        die('User is not logged in.');
    }

    $userEmail = $_POST['user_email'];
    $issueDescription = $_POST['issue_description'];
    $attachment = $_FILES['attachment'];

    // Validate user input
    if (empty($userEmail) || empty($issueDescription)) {
        die('Please fill in all required fields.');
    }

    // Check if the uploaded file is valid
    if ($attachment['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true); // Create directory if it doesn't exist
        }

        $uploadedFilePath = $uploadDir . basename($attachment['name']);
        move_uploaded_file($attachment['tmp_name'], $uploadedFilePath);

        // Fetch user details
        $stm = $_db->prepare('SELECT * FROM petOwner WHERE petOwnerID = ?');
        $stm->execute([$user_id]);
        $user = $stm->fetch();

        if (!$user) {
            die('User not found.');
        }

        // Generate email content
        $email_content = '
        <div style="margin: 40px auto; max-width: 600px; padding: 20px; border: 1px solid #ddd; border-radius: 10px; background-color: #f9f9f9; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
            <h1>Support Request</h1>
            <p><strong>User Email:</strong> ' . htmlspecialchars($userEmail) . '</p>
            <p><strong>Issue Description:</strong></p>
            <p>' . nl2br(htmlspecialchars($issueDescription)) . '</p>
        </div>';

        // Send the email using PHPMailer
        $m = get_mail(); // Ensure this function is correctly defined
        $m->setFrom($userEmail, $user->name); // Sender's email and name
        $m->addAddress('petprocare123@gmail.com', 'Admin'); // Admin's email
        $m->isHTML(true);
        $m->Subject = 'Support Request';
        $m->Body = $email_content;

        // Attach the uploaded file
        $m->addAttachment($uploadedFilePath);

        if ($m->send()) {
            $message = ['type' => 'success', 'text' => 'Your request has been sent successfully.'];
        } else {
            $message = ['type' => 'error', 'text' => 'Failed to send your request. Please try again later.'];
        }

        // Remove the uploaded file after sending
        unlink($uploadedFilePath);
    } else {
        $message = ['type' => 'error', 'text' => 'Failed to upload the file.'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Support</title>
    <link rel="icon" href="../img/logo.png">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #83a4d4, #b6fbff);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            padding: 20px 30px;
            width: 100%;
        }

        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin: 10px 0 5px;
        }

        input,
        textarea,
        button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 18px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }

        .success {
            color: green;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Contact Support</h1>

        <?php if (isset($message)) : ?>
            <div class="<?= $message['type'] ?>"><?= $message['text'] ?></div>
        <?php endif; ?>

        <form  method="POST" enctype="multipart/form-data">
            <label for="user_email">Your Email:</label>
            <input type="email" id="user_email" name="user_email" required placeholder="Enter your email">

            <label for="issue_description">Issue Description:</label>
            <textarea id="issue_description" name="issue_description" rows="5" required placeholder="Describe the issue..."></textarea>

            <label for="attachment">Attach Failure Document:</label>
            <input type="file" id="attachment" name="attachment" accept=".pdf,.jpg,.png,.doc,.docx" required>

            <button type="submit" name="submit">Submit</button>
            <a href="../index.php">Back</a>
        </form>
    </div>
</body>

</html>