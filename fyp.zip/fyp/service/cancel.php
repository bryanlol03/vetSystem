<?php
require '../_base.php';
include("../config.php");
require __DIR__ . "/../vendor/autoload.php";

if (!isset($_SESSION['user'])) {
    header('Location: /login.php');
    exit;
}

// Set a temporary message that the payment was not completed
temp('info', "Your payment was not completed. Please try again.");

unset($_SESSION['checkout_session_id']);
$_title = 'Payment Incomplete';
// Include the header to display the page (if you have a common header file)
include '../_head.php';

?>

<style>
    body {
        font-family: 'Arial', sans-serif;
        background: linear-gradient(135deg, #ff9a9e, #fad0c4);
        height: 100vh;
        margin: 0;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        max-width: 500px;
        padding: 30px;
        background: #fff;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        text-align: center;
    }

    .container h1 {
        color: #f55f44;
        font-size: 2.5rem;
        margin-bottom: 10px;
    }

    .container p {
        font-size: 1rem;
        color: #666;
        margin-bottom: 20px;
    }

    .container .btn {
        display: inline-block;
        background: #007bff;
        color: #fff;
        text-decoration: none;
        padding: 12px 20px;
        font-size: 1rem;
        border-radius: 5px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: background 0.3s, transform 0.2s;
    }

    .container .btn:hover {
        background: #0056b3;
        transform: translateY(-3px);
    }

    .container .btn-secondary {
        background: #f55f44;
        margin-left: 10px;
    }

    .container .btn-secondary:hover {
        background: #cc3b2d;
    }

    .icon {
        margin-bottom: 20px;
    }

    .icon img {
        width: 80px;
    }
</style>

<div class="container">
    <div class="icon">
        <img src="https://cdn-icons-png.flaticon.com/512/190/190406.png" alt="Payment Incomplete Icon">
    </div>
    <h1>Payment Incomplete</h1>
    <p>It seems like your payment couldn't be processed. Please try again or contact support if the issue persists.</p>
    <div>
        <a href="payment.php" class="btn">Try Again</a>
        <a href="contactSupport.php" class="btn btn-secondary">Contact Support</a>
    </div>
</div>
