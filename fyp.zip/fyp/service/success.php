<?php
require '../_base.php';
include("../config.php");
require __DIR__ . "/../vendor/autoload.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Assuming $_SESSION['user_id'] stores the user ID directly
$user_id = $_SESSION['user_id'];

// Retrieve the appointment ID from GET parameters
$appointment_id = isset($_GET['appointmentID']) ? $_GET['appointmentID'] : null;

if ($appointment_id === null) {
    echo "No appointment found.";
    exit;
}

// Set Stripe API key
\Stripe\Stripe::setApiKey($stripedetails['secretKey']);
$sessionId = $_SESSION['checkout_session_id'];

try {
    // Retrieve Stripe session to check payment status
    $session = \Stripe\Checkout\Session::retrieve($sessionId);

    if ($session->payment_status === 'paid') {
        // Update payment status in the database
        $update_payment_sql = "UPDATE payment SET paymentStatus = 'Paid' WHERE appointmentID = ?";
        $stm_update = $_db->prepare($update_payment_sql);
        $stm_update->execute([$appointment_id]);

        // Fetch payment details
        $payment_sql = "
            SELECT 
                p.totalAmount, 
                s.serviceName, 
                s.servicePrice, 
                m.medicineName, 
                m.medicinePrice 
            FROM payment p
            LEFT JOIN service s ON p.serviceID = s.serviceID
            LEFT JOIN medicine m ON p.medicineID = m.medicineID
            WHERE p.appointmentID = ?
        ";
        $stm_payment = $_db->prepare($payment_sql);
        $stm_payment->execute([$appointment_id]);
        $payment_details = $stm_payment->fetch(PDO::FETCH_ASSOC);

        if (!$payment_details) {
            echo "Payment details not found.";
            exit;
        }

        // Fetch user details
        $stm_user = $_db->prepare("SELECT * FROM petOwner WHERE petOwnerID = ?");
        $stm_user->execute([$user_id]);
        $user = $stm_user->fetch(PDO::FETCH_ASSOC);

        // Generate email content
        $email_content = '
        <div style="margin: 40px auto; max-width: 600px; padding: 20px; border: 1px solid #ddd; border-radius: 10px; background-color: #f9f9f9; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="margin: 0; font-size: 24px; font-weight: bold;">Payment Receipt</h1>
                <p>Thank you for your payment!</p>
            </div>

            <div style="margin-bottom: 30px;">
                <p><strong>Appointment ID:</strong> ' . htmlspecialchars($appointment_id) . '</p>
                <p><strong>Payment Status:</strong> Paid Successfully</p>
                <p><strong>Total Amount:</strong> RM ' . number_format($payment_details['totalAmount'], 2) . '</p>
            </div>

            <div>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th style="border: 1px solid #ddd; padding: 10px; background-color: #f0f0f0; font-weight: bold;">Service Name</th>
                            <th style="border: 1px solid #ddd; padding: 10px; background-color: #f0f0f0; font-weight: bold;">Service Price</th>
                            <th style="border: 1px solid #ddd; padding: 10px; background-color: #f0f0f0; font-weight: bold;">Medicine Name</th>
                            <th style="border: 1px solid #ddd; padding: 10px; background-color: #f0f0f0; font-weight: bold;">Medicine Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #ddd; padding: 10px; text-align: center;">' . htmlspecialchars($payment_details['serviceName']) . '</td>
                            <td style="border: 1px solid #ddd; padding: 10px; text-align: center;">RM ' . number_format($payment_details['servicePrice'], 2) . '</td>
                            <td style="border: 1px solid #ddd; padding: 10px; text-align: center;">' . htmlspecialchars($payment_details['medicineName']) . '</td>
                            <td style="border: 1px solid #ddd; padding: 10px; text-align: center;">RM ' . number_format($payment_details['medicinePrice'], 2) . '</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div style="text-align: right; margin-top: 20px; font-weight: bold;">
                <p>Total: RM ' . number_format($payment_details['totalAmount'], 2) . '</p>
            </div>

            <div style="text-align: center; margin-top: 30px; font-size: 16px; color: #555;">
                <p>We appreciate your business and look forward to serving you again!</p>
            </div>
        </div>';

        // Send the email receipt to the user
        $m = get_mail();
        $m->addAddress($user->email, $user->name);
        $m->isHTML(true);
        $m->Subject = 'Payment Receipt';
        $m->Body = $email_content;

        if ($m->send()) {
            temp('info', 'Receipt sent to email.');
        } else {
            temp('error', 'Failed to send the email.');
        }

        echo "Payment marked as paid successfully.";
    } else {
        echo 'Payment is not completed yet.';
    }
} catch (Exception $e) {
    echo "Error processing payment: " . $e->getMessage();
}
?>

<style>
    .receipt-container {
        margin: 40px auto;
        max-width: 600px;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 10px;
        background-color: #f9f9f9;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .receipt-header {
        text-align: center;
        margin-bottom: 30px;
    }

    .receipt-header h1 {
        margin: 0;
        font-size: 24px;
        font-weight: bold;
    }

    .order-details {
        margin-bottom: 30px;
    }

    .order-details p {
        margin: 5px 0;
    }

    .receipt-items table {
        width: 100%;
        border-collapse: collapse;
    }

    .receipt-items th,
    .receipt-items td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: center;
    }

    .receipt-items th {
        background-color: #f0f0f0;
        font-weight: bold;
    }

    .receipt-summary {
        text-align: right;
        margin-top: 20px;
        font-weight: bold;
    }

    .receipt-footer {
        text-align: center;
        margin-top: 30px;
        font-size: 16px;
        color: #555;
    }

    .btn {
        display: inline-block;
        margin-top: 20px;
        padding: 10px 20px;
        background-color: #007bff;
        color: #fff;
        border-radius: 5px;
        text-decoration: none;
    }

    .btn:hover {
        background-color: #0056b3;
    }
</style>

<div class="receipt-container">
    <div class="receipt-header">
        <h1>Order Receipt</h1>
        <p>Thank you for your purchase!</p>
    </div>

    <div class="order-details">
        <p><strong>Order ID:</strong> <?= htmlspecialchars($order['orderID']) ?></p>
        <p><strong>Total Amount:</strong> RM <?= number_format($order['total_amount'], 2) ?></p>
        <p><strong>Order Date:</strong> <?= date('F j, Y, g:i a', strtotime($order['order_date'])) ?></p>
    </div>

    <div class="receipt-items">
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Size</th>
                    <th>Quantity</th>
                    <th>Price (RM)</th>
                    <th>Subtotal (RM)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total = 0;
                foreach ($items as $item):
                    $subtotal = $item['item_price'] * $item['quantity'];
                    $total += $subtotal;
                ?>
                    <tr>
                        <td><?= htmlspecialchars($item['prodName']) ?></td>
                        <td><?= htmlspecialchars($item['size']) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td><?= number_format($item['item_price'], 2) ?></td>
                        <td><?= number_format($subtotal, 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="receipt-summary">
        <p>Total: RM <?= number_format($total, 2) ?></p>
    </div>

    <div class="receipt-footer">
        <p>We hope to see you again soon!</p>
        <a href="../index.php" class="btn">Return to Home</a>
    </div>
</div>