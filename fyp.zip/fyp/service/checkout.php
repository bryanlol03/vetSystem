<?php

include("../config.php");
include('../_base.php');
require __DIR__ . "/../vendor/autoload.php";

auth(); // Ensure user is authenticated

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Validate if 'id' is passed from the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid appointment ID.");
}

$appointmentID = htmlspecialchars($_GET['id']); // Prevent XSS attacks
$totalAmount = 0;

// Prepare database query to fetch payment details
$stm_payment = $_db->prepare('
    SELECT p.*, s.serviceName, s.servicePrice, m.medicineName, m.medicinePrice
    FROM payment p
    LEFT JOIN service s ON p.serviceID = s.serviceID
    LEFT JOIN medicine m ON p.medicineID = m.medicineID
    WHERE p.appointmentID = ?
');

// Execute query
$stm_payment->execute([$appointmentID]);
$payment = $stm_payment->fetch(PDO::FETCH_ASSOC);

if (!$payment) {
    die("No payment record found for the given appointment.");
}

// Stripe line items array
$line_items = [];

// Add line item for the service
if (!empty($payment['serviceName']) && $payment['servicePrice'] > 0) {
    $line_items[] = [
        "quantity" => 1, // Assuming quantity is 1 for appointment services
        "price_data" => [
            "currency" => "myr",
            "unit_amount" => intval($payment['servicePrice'] * 100), // Convert to cents
            "product_data" => [
                "name" => $payment['serviceName'],
                "description" => "Service for Appointment ID: $appointmentID"
            ]
        ]
    ];
    $totalAmount += $payment['servicePrice'];
}

// Add line item for the medicine (if applicable)
if (!empty($payment['medicineName']) && $payment['medicinePrice'] > 0) {
    $line_items[] = [
        "quantity" => 1, // Assuming quantity is 1 for medicine
        "price_data" => [
            "currency" => "myr",
            "unit_amount" => intval($payment['medicinePrice'] * 100), // Convert to cents
            "product_data" => [
                "name" => $payment['medicineName'],
                "description" => "Medicine for Appointment ID: $appointmentID"
            ]
        ]
    ];
    $totalAmount += $payment['medicinePrice'];
}

if (empty($line_items)) {
    die("No valid items found for payment.");
}

// Insert appointment record and mark payment as unpaid
try {
    $_db->beginTransaction();

    $appointment_sql = "INSERT INTO appointment_record (appointmentID, serviceID, medicineID, totalAmount) VALUES (?, ?, ?, ?)";
    $appointment_stm = $_db->prepare($appointment_sql);
    $appointment_stm->execute([
        $appointmentID,
        $payment['serviceID'],
        $payment['medicineID'] ?? null,
        $totalAmount
    ]);

    $_db->commit();
} catch (Exception $e) {
    $_db->rollBack();
    die("Error saving appointment record: " . $e->getMessage());
}

// Create a Stripe Checkout Session
\Stripe\Stripe::setApiKey($stripedetails['secretKey']);

$success_url = "http://localhost:8000/service/success.php?session_id={CHECKOUT_SESSION_ID}&sid=" . session_id();
$cancel_url = "http://localhost:8000/service/cancel.php";

$checkout_session = \Stripe\Checkout\Session::create([
    "mode" => "payment",
    "success_url" => $success_url . "?session_id={CHECKOUT_SESSION_ID}",
    "cancel_url" => $cancel_url,
    "line_items" => $line_items
]);

$_SESSION['checkout_session_id'] = $checkout_session->id;

// Redirect to Stripe Checkout
http_response_code(303);
header("Location: " . $checkout_session->url);
exit();

?>
