<?php
include '../_base.php';
auth();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$user_id = $_SESSION['user_id'];
$selectedDate = $_GET['date'] ?? date('Y-m-d');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php"); // Redirect to login page if not logged in
    exit();
}

// Handle event submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $type = $_POST['type'];
    $date = $_POST['event_date'];
    $start_time = $_POST['start_time'];
    $title = $_POST['title'];
    $end_time = !empty($_POST['end_time']) ? $_POST['end_time'] : null;
    $frequency = !empty($_POST['frequency']) ? $_POST['frequency'] : null; // Optional
    $petOwnerID = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    $completed = !empty($_POST['completed']) ? $_POST['completed'] : 'No'; // Default to 'No'

    try {
        // Insert into the database
        $query = "INSERT INTO petCalendar (Type, date, start_time, title, end_time, frequency, petOwnerID, completed) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $_db->prepare($query);

        // Ensure 'NULL' values are handled properly for frequency and completed
        $frequency = !empty($_POST['frequency']) ? $_POST['frequency'] : null; // Optional
        $completed = !empty($_POST['completed']) ? $_POST['completed'] : 'No'; // Default to 'No'

        // Execute the prepared statement with the correct number of values
        $stmt->execute([$type, $date, $start_time, $title, $end_time, $frequency, $petOwnerID, $completed]);
        error_log("Type: $type, Date: $date, Start Time: $start_time, Title: $title");
        echo "<script>alert('Event added successfully!');</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    }
}

if (isset($_GET['date'])) {
    $selectedDate = $_GET['date'];

    $query = "SELECT * FROM petCalendar WHERE date = ?";
    $stmt = $_db->prepare($query);
    $stmt->execute([$selectedDate]);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($appointments);
    exit;
}

// Fetch all appointments from the database
$appointments = [];
$query = "SELECT * FROM appointment";
$result = $_db->query($query);
// if ($result->num_rows > 0) {
//     while ($row = $result->fetchColumn()) {
//         $appointments[] = $row;
//     }
//}

//$mysqli->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
        name="description"
        content="Stay organized with our user-friendly Calendar featuring events, reminders, and a customizable interface. Built with HTML, CSS, and JavaScript. Start scheduling today!" />
    <meta
        name="keywords"
        content="calendar, events, reminders, javascript, html, css, open source coding" />
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
        integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
        crossorigin="anonymous"
        referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/cal.css" />
    <link rel="icon" href="../img/logo.png">
    <title>User Calender</title>
    <style>
        .add-event-input {
            margin-bottom: 15px;
        }

        .add-event-input input[type="time"] {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            width: 100%;
            color: #333;
        }

        .add-event-input label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
            color: #333;
        }

        /* Add hover or focus styles if needed */
        .add-event-input input[type="time"]:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
            outline: none;
        }


        .add-event-header .title {
            font-size: 18px;
            font-weight: bold;
        }

        .add-event-header .close {
            cursor: pointer;
            color: red;
            font-size: 20px;
        }

        .add-event-body {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }

        .form-group input,
        .form-group select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            width: 100%;
        }

        .form-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .add-event-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .add-event-btn:hover {
            background-color: #0056b3;
        }

        .cancel-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .cancel-btn:hover {
            background-color: #a71d2a;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="home-button">
            <button onclick="window.location.href='../index.php';">Home</button>
        </div>
        <div class="left">
            <div class="calendar">
                <div class="month">
                    <i class="fas fa-angle-left prev"></i>
                    <div class="date">december 2015</div>
                    <i class="fas fa-angle-right next"></i>
                </div>
                <div class="weekdays">
                    <div>Sun</div>
                    <div>Mon</div>
                    <div>Tue</div>
                    <div>Wed</div>
                    <div>Thu</div>
                    <div>Fri</div>
                    <div>Sat</div>
                </div>
                <div class="days">
                    <?php for ($i = 1; $i <= 31; $i++): ?>
                        <?php $currentDate = date('Y-m-d', strtotime("2024-12-$i")); ?>
                        <div class="day" data-date="<?php echo $currentDate; ?>">
                            <?php echo $i; ?>
                        </div>
                    <?php endfor; ?>

                </div>
                <div class="goto-today">
                    <div class="goto">
                        <input type="text" placeholder="mm/yyyy" class="date-input" />
                        <button class="goto-btn">Go</button>
                    </div>
                    <button class="today-btn">Today</button>
                </div>
            </div>
        </div>
        <div class="right">
            <div class="today-date">
                <div class="event-day"></div>
                <div class="event-date">
                    <?= isset($selectedDate) ? htmlspecialchars($selectedDate, ENT_QUOTES, 'UTF-8') : 'No date selected'; ?>
                </div>
            </div>
            <div class="events">
                <?php foreach ($appointments as $appointment): ?>
                    <div class="events">
                        <?php foreach ($appointments as $appointment): ?>
                            <div class="event">
                                <h4><?= htmlspecialchars($appointment['title']) ?> (<?= htmlspecialchars($appointment['Type']) ?>)</h4>
                                <p>Date: <?= htmlspecialchars($appointment['date']) ?></p>
                                <p>Start Time: <?= htmlspecialchars($appointment['start_time']) ?></p>
                                <?php if (!empty($appointment['end_time'])): ?>
                                    <p>End Time: <?= htmlspecialchars($appointment['end_time']) ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="add-event-wrapper">
                <form method="POST" action="">

                    <div class="add-event-header">
                        <div class="title">Add Event</div>
                        <i class="fas fa-times close"></i>
                    </div>
                    <div class="add-event-body">

                        <div class="add-event-input">
                            <label for="type"></label>
                            <select id="type" name="type" class="event-type" onchange="toggleFields()">
                                <option value="task">Task</option>
                                <option value="event">Event</option>
                                <option value="reminder">Reminder</option>
                            </select>
                        </div>
                        <div class="add-event-input">
                            <label for="title" style="color: black;">Title:</label>
                            <input type="text" id="title" name="title" placeholder="Enter Title" required />
                        </div>
                        <div class="add-event-input">
                            <label for="event-date" style="color: black;">Date:</label>
                            <input
                                type="text"
                                id="event-date"
                                name="event_date"
                                readonly
                                value="<?php echo isset($selectedDate) ? htmlspecialchars($selectedDate, ENT_QUOTES, 'UTF-8') : ''; ?>">
                        </div>
                        <div class="add-event-input">
                            <label for="start-time" style="color: black;">Start Time:</label>
                            <input type="time" id="start-time" name="start_time" required />
                        </div>
                        <div class="add-event-input" id="end-time-input" style="display: none;">
                            <label for="end-time" style="color: black;">End Time:</label>
                            <input type="time" id="end-time" name="end_time" />
                        </div>

                        <div class="add-event-footer">
                            <button type="submit" class="add-event-btn">Add</button>
                        </div>
                    </div>
                </form>
            </div>
            <button class="add-event">
                <i class="fas fa-plus"></i>
            </button>
        </div>

        <script src="../js/cal.js"></script>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const days = document.querySelectorAll(".day"); // Select all day elements

                days.forEach(day => {
                    day.addEventListener("click", function() {
                        const selectedDate = this.getAttribute("data-date"); // Get the date from the clicked day
                        if (selectedDate) {
                            // Redirect with the selected date in the URL
                            window.location.href = `?date=${selectedDate}`;
                        }
                    });
                });
            });

            document.addEventListener("DOMContentLoaded", function() {
                const days = document.querySelectorAll(".day"); // Select all day elements
                const eventDateInput = document.getElementById("event-date"); // Hidden input field
                const todayDateDisplay = document.querySelector(".today-date .event-date");

                days.forEach(day => {
                    day.addEventListener("click", function() {
                        const selectedDate = this.getAttribute("data-date"); // Get the date from the clicked day
                        if (selectedDate) {
                            todayDateDisplay.textContent = selectedDate; // Update display
                            eventDateInput.value = selectedDate; // Update the hidden input
                            console.log("Selected date:", selectedDate); // Debugging log
                        }
                    });
                });
            });


            document.querySelector(".add-event-btn").addEventListener("click", function(e) {
                e.preventDefault(); // Prevent form submission
                const type = document.getElementById("type").value;

                // Display success message dynamically
                alert(type + " successfully added!");

                // Submit the form
                document.querySelector("form").submit();
            });

            $(document).ready(function() {
                const eventsSection = $('#event-details');
                const addEventWrapper = $('#add-event-wrapper');
                const closeAddEvent = $('#close-add-event');
                const cancelAddEvent = $('#cancel-add-event');

                // Handle date click
                $('.days div').click(function() {
                    const selectedDate = $(this).data('date');
                    const appointments = <?php echo json_encode($appointments); ?>;

                    // Filter appointments for the selected date
                    const filteredAppointments = appointments.filter(app => app.date === selectedDate);

                    // Update events section
                    if (filteredAppointments.length > 0) {
                        let details = `<h3>Appointments for ${selectedDate}</h3><ul>`;
                        filteredAppointments.forEach(app => {
                            details += `
                            <li>
                                <strong>Pet Name:</strong> ${app.petName}<br>
                                <strong>Service ID:</strong> ${app.serviceID}<br>
                                <strong>Time:</strong> ${app.time}<br>
                                <strong>Room ID:</strong> ${app.roomID}<br>
                                <strong>Symptoms:</strong> ${app.symptom}<br>
                                <strong>Status:</strong> ${app.status}
                            </li><hr>`;
                        });
                        details += '</ul>';
                        eventsSection.html(details);
                    } else {
                        eventsSection.html(`<p>No Events</p>`);
                    }
                });

                // Show Add Event Wrapper
                $('#add-event').click(function() {
                    addEventWrapper.fadeIn();
                });

                // Close Add Event Wrapper
                closeAddEvent.click(function() {
                    addEventWrapper.fadeOut();
                });

                cancelAddEvent.click(function() {
                    addEventWrapper.fadeOut();
                });
            });

            function toggleFields() {
                const type = document.getElementById("type").value;
                const endTimeInput = document.getElementById("end-time-input");

                // Reset field visibility
                endTimeInput.style.display = "none";

                // Show relevant fields based on the selected type
                if (type === "event") {
                    endTimeInput.style.display = "block"; // Show end time for events
                }
            }

            $(document).ready(function() {
                const eventsSection = $('.events');

                // Add dynamic events
                $('.add-event-btn').click(function(e) {
                    e.preventDefault();

                    const type = $('#type').val();
                    const title = $('#title').val();
                    const date = $('#date').val();
                    const startTime = $('#start-time').val();
                    const endTime = $('#end-time').val();
                    const frequency = $('#frequency').val();

                    // Add event to the UI
                    const eventHTML = `
            <div class="event">
                <h4>${title} (${type})</h4>
                <p>Date: ${date}</p>
                <p>Start Time: ${startTime}</p>
                ${endTime ? `<p>End Time: ${endTime}</p>` : ''}
                ${frequency ? `<p>Frequency: ${frequency}</p>` : ''}
            </div>
        `;
                    eventsSection.append(eventHTML);

                    // Submit the form to save the event in the database
                    $('form').submit();
                });
            });

            // Reminder notifications script
            // Function to check upcoming events and show notification
            function checkUpcomingEvents() {
                const today = new Date();
                const currentDateString = today.toISOString().split("T")[0]; // Get current date in yyyy-mm-dd format
                const currentTime = `${today.getHours()}:${today.getMinutes()}`;

                events.forEach(event => {
                    if (event.date === currentDateString) {
                        const eventStart = event.startTime.split(":").map(Number);
                        const eventTime = new Date();
                        eventTime.setHours(eventStart[0], eventStart[1]);

                        // Notify 15 minutes before the event
                        const timeBeforeEvent = new Date(eventTime.getTime() - 15 * 60000); // 15 minutes before the event start time
                        if (today >= timeBeforeEvent && today <= eventTime) {
                            showNotification(event.name, event.startTime, event.endTime);
                        }
                    }
                });
            }

            // Function to show a notification with bell icon
            function showNotification(eventName, startTime, endTime) {
                const notification = document.createElement('div');
                notification.classList.add('notification');
                notification.innerHTML = `
    <i class="fas fa-bell"></i> <strong>Reminder:</strong> ${eventName} <br>
    <strong>Start:</strong> ${startTime} <br>
    <strong>End:</strong> ${endTime}
  `;

                // Append notification to the body
                document.body.appendChild(notification);

                // Remove the notification after 10 seconds
                setTimeout(() => {
                    notification.remove();
                }, 10000);
            }

            // Run the event checker every minute
            setInterval(checkUpcomingEvents, 60000);
        </script>
</body>

</html>