<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pet Profile</title>
    <?php
    include '../_base.php';
    auth();
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Check if the user is logged in
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../login.php");
        exit();
    }

    // Initialize variables
    $pet = null;
    $_err = [];  // Array to store error messages
    $user_id = $_SESSION['user_id'];
    $name = $species = $breed = $age = $gender = $photo = '';

    // GET Request: Fetch the pet details based on the ID
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
        $id = (int)$_GET['id'];  // Sanitize the pet ID

        // Query to fetch pet details
        $stmt_pet = $_db->prepare("SELECT * FROM pet WHERE petID = :pet_id AND petOwnerID = :user_id");
        $stmt_pet->bindParam(':pet_id', $id, PDO::PARAM_INT);
        $stmt_pet->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_pet->execute();
        $pet = $stmt_pet->fetch(PDO::FETCH_OBJ);

        if (!$pet) {
            echo "Pet not found or you do not have permission to edit this pet.";
            exit();
        }

        // Extract pet details to variables for the form
        $name = $pet->name;
        $species = $pet->species;
        $breed = $pet->breed;
        $age = $pet->age;
        $gender = $pet->gender;
        $photo = $pet->profilePhoto;
    }

    // POST Request: Handle form submission to update the pet profile
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = (int)$_POST['selected_pet_id'];  // Pet ID
        $name = req('pet_name');
        $species = req('species');
        $breed = req('breed');
        $age = req('age');
        $gender = req('gender');
        $f = get_file('pet_profile_photo');  // Get uploaded file
        $photo = $photo ?? '';  // Default to current photo

        // Validate fields
        if (empty($name)) {
            $_err['name'] = 'Name is required.';
        } elseif (strlen($name) > 100) {
            $_err['name'] = 'Name must not exceed 100 characters.';
        }

        if (empty($species)) {
            $_err['species'] = 'Species is required.';
        } elseif (strlen($species) > 50) {
            $_err['species'] = 'Species must not exceed 50 characters.';
        }

        if (empty($breed)) {
            $_err['breed'] = 'Breed is required.';
        } elseif (strlen($breed) > 50) {
            $_err['breed'] = 'Breed must not exceed 50 characters.';
        }

        if (!is_numeric($age) || $age < 0 || $age > 100) {
            $_err['age'] = 'Age must be a valid number between 0 and 100.';
        }

        if (!in_array($gender, ['Male', 'Female'])) {
            $_err['gender'] = 'Gender must be either Male or Female.';
        }

        // Handle photo upload if a new file is provided
        if ($f) {
            if (!str_starts_with($f->type, 'image/')) {
                $_err['profile_photo'] = 'File must be an image.';
            } elseif ($f->size > 1 * 1024 * 1024) {  // Max 1MB
                $_err['profile_photo'] = 'Image must not exceed 1MB.';
            } else {
                // Delete the old photo if it exists
                if (!empty($photo) && file_exists("../photos/profile_photo/$photo")) {
                    unlink("../photos/profile_photo/$photo");
                }

                // Save the new photo
                $photo = save_photo($f, '../photos/profile_photo/');
            }
        }

        // Update the pet profile if there are no errors
        if (empty($_err)) {
            $stmt_update_pet = $_db->prepare("
                UPDATE pet
                SET name = :name, species = :species, breed = :breed, age = :age, gender = :gender, profilePhoto = :profilePhoto
                WHERE petID = :pet_id AND petOwnerID = :user_id
            ");
            $stmt_update_pet->bindParam(':name', $name);
            $stmt_update_pet->bindParam(':species', $species);
            $stmt_update_pet->bindParam(':breed', $breed);
            $stmt_update_pet->bindParam(':age', $age);
            $stmt_update_pet->bindParam(':gender', $gender);
            $stmt_update_pet->bindParam(':profile_photo', $photo);
            $stmt_update_pet->bindParam(':pet_id', $id, PDO::PARAM_INT);
            $stmt_update_pet->bindParam(':user_id', $user_id, PDO::PARAM_INT);

            if ($stmt_update_pet->execute()) {
                echo "Pet profile updated successfully!";
            } else {
                echo "Failed to update pet profile.";
            }
        }
    }
    ?>
</head>

<body>
    <h1>Edit Pet Profile</h1>
    <form action="updatePet.php" method="post" enctype="multipart/form-data">
        <!-- Hidden input to store the pet ID -->
        <input type="hidden" name="selected_pet_id" value="<?php echo htmlspecialchars($id); ?>">

        <label for="pet_name">Pet Name:</label>
        <input type="text" name="pet_name" id="pet_name" value="<?php echo htmlspecialchars($name); ?>" required><br>

        <label for="species">Species:</label>
        <input type="text" name="species" id="species" value="<?php echo htmlspecialchars($species); ?>" required><br>

        <label for="breed">Breed:</label>
        <input type="text" name="breed" id="breed" value="<?php echo htmlspecialchars($breed); ?>" required><br>

        <label for="age">Age:</label>
        <input type="number" name="age" id="age" min="0" max="100" value="<?php echo htmlspecialchars($age); ?>" required><br>

        <label for="gender">Gender:</label>
        <select name="gender" id="gender" required>
            <option value="Male" <?php echo ($gender === 'Male') ? 'selected' : ''; ?>>Male</option>
            <option value="Female" <?php echo ($gender === 'Female') ? 'selected' : ''; ?>>Female</option>
        </select><br>

        <label for="pet_profile_photo">Profile Photo:</label>
        <input type="file" name="pet_profile_photo" id="pet_profile_photo"><br>

        <button type="submit" name="update_pet" class="btn btn-success">Update Pet</button>
        <button type="button" onclick="history.back()" class="btn btn-secondary">Cancel</button>
    </form>
</body>

</html>
