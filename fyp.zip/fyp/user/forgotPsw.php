<?php
include '../_base.php';

if (is_post()) {
    $email = req('email');
    $_err = [];

    // Validate email
    if (empty($email)) {
        $_err['email'] = 'Required';
    } elseif (!is_email($email)) {
        $_err['email'] = 'Invalid email';
    } elseif (!is_exists($email, 'petOwner', 'email')) {
        $_err['email'] = 'Email does not exist';
    }

    // Process if there are no errors
    if (empty($_err)) {
        // (1) Retrieve user info by email
        $stm = $_db->prepare('SELECT * FROM petOwner WHERE email = ?');
        $stm->execute([$email]);
        $user = $stm->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // (2) Generate a unique token
            $tokenID = sha1(uniqid() . rand());

            // (3) Remove old token and insert new token with a 5-minute expiration
            $stm = $_db->prepare('
                DELETE FROM token WHERE petOwnerID = ?;
                INSERT INTO token (id, expire, petOwnerID)
                VALUES (?, ADDTIME(NOW(), "00:05"), ?);
            ');
            $stm->execute([$user['petOwnerID'], $tokenID, $user['petOwnerID']]);

            // (4) Generate the token URL
            $resetUrl = base("user/token.php?id=$tokenID");

            // (5) Prepare and send email with embedded profile photo
            $mail = get_mail();
            $mail->addAddress($user['email'], $user['name']);
            $profilePhoto = !empty($user['profile_photo']) && file_exists("../img/userPhoto/{$user['profile_photo']}")
                ? $user['profile_photo']
                : 'unknown.jpg';
            $profilePhotoPath = "../img/userPhoto/$profilePhoto";

            if (file_exists($profilePhotoPath)) {
                $mail->addEmbeddedImage($profilePhotoPath, 'photo');
            } else {
                temp('info', 'No profile photo found. Email sent without photo.');
            }

            $mail->isHTML(true);
            $mail->Subject = 'Reset Password';
            $mail->Body = "
                <img src='cid:photo' style='width: 200px; height: 200px; border: 1px solid #333'>
                <p>Dear {$user['name']},</p>
                <h1 style='color: red'>Reset Password</h1>
                <p>Please click <a href='$resetUrl'>here</a> to reset your password.</p>
                <p>From, 😺 Admin</p>
            ";
            $mail->send();

            temp('info', 'Email sent');
            redirect('/');
        } else {
            temp('info', 'User not found');
        }
    }
}
?>
<style>
    /* General body styling */
body {
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    background: linear-gradient(135deg, #ff9a9e, #fad0c4);
}

/* Form container */
.form {
    background: white;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    width: 300px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.form:hover {
    transform: scale(1.02);
    box-shadow: 0 6px 10px rgba(0, 0, 0, 0.2);
}

/* Label styling */
label {
    font-size: 14px;
    color: #333;
    margin-bottom: 5px;
    display: block;
}

/* Input field styling */
input {
    width: 100%;
    padding: 8px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input:focus {
    border-color: #ff9a9e;
    outline: none;
    box-shadow: 0 0 5px rgba(255, 154, 158, 0.5);
}

/* Section for buttons */
section {
    display: flex;
    justify-content: space-between;
}

button {
    padding: 10px 20px;
    font-size: 14px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.3s ease;
}

button[type="submit"] {
    background: #ff9a9e;
    color: white;
}

button[type="submit"]:hover {
    background: #e87c7e;
    transform: scale(1.05);
}

button[type="reset"] {
    background: #ccc;
    color: white;
}

button[type="reset"]:hover {
    background: #bbb;
    transform: scale(1.05);
}
</style>
<link rel="icon" href="../img/logo.png">
<title>User | Reset Password</title>

<!-- HTML Form -->
<form method="post"  class="form">
    <label for="email">Email</label>
    <?= html_text('email', 'maxlength="100"') ?>
    <?= err('email') ?>

    <section>
        <button type="submit">Submit</button>
        <button type="reset">Reset</button>
    </section>
</form>