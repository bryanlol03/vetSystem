<!DOCTYPE html>
<html lang="en">
<?php
include '../_base.php';
auth();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$currentDate = date('Y-m-d');
$isPastDate = $selectedDate < $currentDate;

// Fetch staff data
$sql_staff = "SELECT * FROM staff WHERE role IN ('Veterinarian', 'Surgeon')";
$stmt_staff = $_db->prepare($sql_staff);
$stmt_staff->execute();
$staff = $stmt_staff->fetchAll(PDO::FETCH_OBJ);

// Function to get doctor appointments by date
function getDoctorAppointments($doctorID, $selectedDate)
{
    global $_db;
    $stmt = $_db->prepare("
        SELECT time, status
        FROM appointment
        WHERE staffID = :staffID AND date = :date
    ");
    $stmt->bindParam(':staffID', $doctorID, PDO::PARAM_INT);
    $stmt->bindParam(':date', $selectedDate, PDO::PARAM_STR);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Prepare appointment data for each doctor
$appointmentsByDoctor = [];
foreach ($staff as $doctor) {
    $appointments = getDoctorAppointments($doctor->staffID, $selectedDate);
    $appointmentsByDoctor[$doctor->staffID] = array_column($appointments, 'status', 'time');
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Doctor Available Slot</title>
    <style>
        /* General Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .container {
            max-width: 1200px;
            margin: 20px;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        header {
            background-color: #007BFF;
            color: white;
            text-align: center;
            padding: 15px;
            width: 100%;
            position: relative;
        }

        header h1 {
            margin: 0;
        }

        .back-btn {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            background-color: #f9f9f9;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .back-btn:hover {
            background-color: #003f8c;
        }

        .filter-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .schedule-grid {
            display: grid;
            grid-template-columns: repeat(8, 1fr);
            gap: 10px;
        }

        .time-slot {
            padding: 10px;
            text-align: center;
            color: white;
            border-radius: 5px;
        }

        .available {
            background-color: green;
        }

        .not-available {
            background-color: red;
        }

        .pending {
            background-color: yellow;
            color: black;
        }

        .doctor-title {
            font-size: 18px;
            color: #007BFF;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <header>
        <div class="back-btn">
            <a href="appointment.php">Back</a>
        </div>
        <h1>Doctor Available Time Slots</h1>
    </header>
    <div class="container">
        <div class="filter-container">
            <label for="doctor">Select Doctor:</label>
            <select id="doctor" onchange="fetchSlots()">
                <option value="">All Doctors</option>
                <?php foreach ($staff as $doctor): ?>
                    <option value="<?php echo htmlspecialchars($doctor->staffID); ?>"
                        <?php echo (isset($_GET['doctor']) && $_GET['doctor'] == $doctor->staffID) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($doctor->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="date">Select Date:</label>
            <input type="date" id="date" value="<?php echo htmlspecialchars($selectedDate); ?>" onchange="fetchSlots()">
        </div>

        <?php foreach ($staff as $doctor): ?>
            <?php if (!isset($_GET['doctor']) || $_GET['doctor'] == $doctor->staffID || $_GET['doctor'] === ''): ?>
                <div>
                    <p class="doctor-title">Doctor: <?php echo htmlspecialchars($doctor->name); ?></p>
                    <div class="schedule-grid">
                        <?php
                        $timeSlots = ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"];
                        foreach ($timeSlots as $time):
                            $status = $appointmentsByDoctor[$doctor->staffID][$time] ?? 'Available';
                            $class = ($status === 'Available') ? 'available' : (($status === 'Pending') ? 'pending' : 'not-available');
                        ?>
                            <div class="time-slot <?php echo $class; ?>">
                                <?php echo $time . " - " . ucfirst($status); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>

    <script>
        function fetchSlots() {
            const doctorID = document.getElementById("doctor").value;
            const date = document.getElementById("date").value;
            window.location.href = `?doctor=${doctorID}&date=${date}`;
        }

        if (isset($_GET['doctor']) && $_GET['doctor']) {
            const doctorID = document.getElementById("doctor").value;
            const date = document.getElementById("date").value;

            if (doctorID && date) {
                window.location.href = `?doctor=${doctorID}&date=${date}`;
            }
            // Dynamically update based on filters
            window.location.href = `?doctor=${doctorID}&date=${date}`;
        }

        function selectSlot(time, day) {
        function selectSlot(time) {
            const doctorID = document.getElementById("doctor").value;
            const date = document.getElementById("date").value;

            if (doctorID && date) {
                // Redirect to appointment.php with pre-filled parameters
                window.location.href = `appointment.php?doctor=${doctorID}&date=${date}&time=${time}`;
            } else {
                alert("Please select a doctor and date.");
            }
        }}
    </script>
</body>

</html>