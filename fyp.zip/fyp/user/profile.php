<!DOCTYPE html>
<html lang="en">
<link rel="icon" href="../img/logo.png">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.css">
<?php
include '../_base.php';
auth();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php"); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user information from the petOwner table
$stmt_user = $_db->prepare("SELECT * FROM petOwner WHERE petOwnerID = :user_id");
$stmt_user->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt_user->execute();
$user = $stmt_user->fetch(PDO::FETCH_OBJ);

if (!$user) {
    header("Location: login.php"); // Redirect to login page if user not found
    exit();
}

// Fetch user's pets from the pet table
$stmt_pets = $_db->prepare("SELECT * FROM pet WHERE petOwnerID = :user_id");
$stmt_pets->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt_pets->execute();
$pets = $stmt_pets->fetchAll(PDO::FETCH_OBJ);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = req('name');
    $contact = req('contact');
    $address = req('address');
    $gender = req('gender');
    $profile_photo = $user->profile_photo; // Initialize with current photo
    $errors = [];

    // Validate required fields
    if (empty($name)) {
        $errors['name'] = 'Name is required.';
    } elseif (strlen($name) < 3) {
        $errors['name'] = 'Name must be at least 3 characters.';
    } elseif (strlen($name) > 100) {
        $errors['name'] = 'Name cannot exceed 100 characters.';
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        $errors['name'] = 'Name can only contain letters and spaces.';
    }

    if (empty($contact)) {
        $errors['contact'] = 'Contact number is required.';
    } elseif (!preg_match("/^[0-9]{10}$/", $contact)) {
        $errors['contact'] = 'Contact number must be exactly 10 digits and contain only numbers.';
    }

    if (empty($address)) {
        $errors['address'] = 'Address is required.';
    } elseif (str_word_count($address) > 7) {
        $errors['address'] = 'Address must be at least 7 words.';
    } elseif (!preg_match("/^[a-zA-Z0-9\s,]+$/", $address)) {
        $errors['address'] = 'Address can only contain letters, numbers, spaces, and commas.';
    }

    // Validate profile photo upload
    if (!empty($_FILES['profile_photo']['name'])) {
        $file = $_FILES['profile_photo'];
        if (!str_starts_with($file['type'], 'image/')) {
            $errors['profile_photo'] = 'File must be an image.';
        } elseif ($file['size'] > 800 * 1024) { // Max 800 KB
            $errors['profile_photo'] = 'Image must be smaller than 800 KB.';
        } else {
            // Process photo upload
            $profile_photo = uniqid() . '_' . basename($file['name']);
            $upload_dir = '../img/userPhoto/';
            $upload_path = $upload_dir . $profile_photo;

            if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
                $errors['profile_photo'] = 'Failed to upload photo.';
            } else {
                // Delete old photo if a new one is successfully uploaded
                if ($user->profile_photo && file_exists($upload_dir . $user->profile_photo)) {
                    unlink($upload_dir . $user->profile_photo);
                }
            }
        }
    }

    // Update database if no errors
    if (empty($errors)) {
        try {
            $stmt_update = $_db->prepare("
                UPDATE petOwner 
                SET name = :name, contact = :contact, address = :address, gender = :gender, profile_photo = :profile_photo 
                WHERE petOwnerID = :user_id
            ");
            $stmt_update->bindParam(':name', $name);
            $stmt_update->bindParam(':contact', $contact);
            $stmt_update->bindParam(':address', $address);
            $stmt_update->bindParam(':gender', $gender);
            $stmt_update->bindParam(':profile_photo', $profile_photo);
            $stmt_update->bindParam(':user_id', $user_id, PDO::PARAM_INT);

            if ($stmt_update->execute()) {
                temp('info', 'Profile update success');
                header("Location: profile.php"); // Redirect to profile page
                exit();
            } else {
                $errors['general'] = 'Failed to update profile. Please try again.';
            }
        } catch (PDOException $e) {
            $errors['general'] = 'Database error: ' . $e->getMessage();
        }
    }

    // Store errors in session to display them on the form page
    $_SESSION['errors'] = $errors;
}

// Maximum number of pets allowed
$max_pets = 3;
$pet_count = count($pets);

// Process pet registration if under the maximum limit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_pet']) && $pet_count < $max_pets) {
    $errors = []; // Array to hold validation errors

    // Retrieve form data
    $pet_name = req('pet_name');
    $species = req('species');
    $breed = req('breed');
    $age = req('age');
    $gender = req('gender');
    $profile_photo = 'unknown.jpg'; // Default profile photo

    // Validate Pet Name
    if (empty($pet_name)) {
        $errors['pet_name'] = 'Pet name is required.';
    } elseif (strlen($pet_name) < 3 || strlen($pet_name) > 50) {
        $errors['pet_name'] = 'Pet name must be between 3 and 50 characters.';
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $pet_name)) {
        $errors['pet_name'] = 'Pet name can only contain letters and spaces.';
    }

    // Validate Species
    if (empty($species)) {
        $errors['species'] = 'Species is required.';
    } elseif (strlen($species) < 3 || strlen($species) > 50) {
        $errors['species'] = 'Species must be between 3 and 50 characters.';
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $species)) {
        $errors['species'] = 'Species can only contain letters and spaces.';
    }

    // Validate Breed
    if (empty($breed)) {
        $errors['breed'] = 'Breed is required.';
    } elseif (strlen($breed) < 3 || strlen($breed) > 50) {
        $errors['breed'] = 'Breed must be between 3 and 50 characters.';
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $breed)) {
        $errors['breed'] = 'Breed can only contain letters and spaces.';
    }

    // Validate Age
    if (empty($age)) {
        $errors['age'] = 'Age is required.';
    } elseif (!is_numeric($age) || $age < 0 || $age > 100) {
        $errors['age'] = 'Age must be a valid number between 0 and 100.';
    }

    // Validate Gender
    if (empty($gender)) {
        $errors['gender'] = 'Gender is required.';
    } elseif (!in_array($gender, ['Male', 'Female'])) {
        $errors['gender'] = 'Gender must be either Male or Female.';
    }

    // Validate Pet Profile Photo
    if (!empty($_FILES['pet_profile_photo']['name'])) {
        $file = $_FILES['pet_profile_photo'];
        if (!str_starts_with($file['type'], 'image/')) {
            $errors['profile_photo'] = 'File must be an image.';
        } elseif ($file['size'] > 800 * 1024) { // Max 800 KB
            $errors['profile_photo'] = 'Image must be smaller than 800 KB.';
        } else {
            // Generate a unique name for the file and save it
            $profile_photo = uniqid() . '_' . basename($file['name']);
            $upload_dir = '../img/petPhoto/';
            $upload_path = $upload_dir . $profile_photo;

            if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
                $errors['profile_photo'] = 'Failed to upload photo.';
            }
        }
    }

    // If there are no validation errors, proceed to insert the pet data into the database
    if (empty($errors)) {
        $stmt_add_pet = $_db->prepare("INSERT INTO pet (name, species, breed, age, gender, petOwnerID, profilePhoto) VALUES (:name, :species, :breed, :age, :gender, :owner_id, :profile_photo)");
        $stmt_add_pet->bindParam(':name', $pet_name);
        $stmt_add_pet->bindParam(':species', $species);
        $stmt_add_pet->bindParam(':breed', $breed);
        $stmt_add_pet->bindParam(':age', $age);
        $stmt_add_pet->bindParam(':gender', $gender);
        $stmt_add_pet->bindParam(':owner_id', $user_id, PDO::PARAM_INT);
        $stmt_add_pet->bindParam(':profile_photo', $profile_photo);

        if ($stmt_add_pet->execute()) {
            // Redirect to show the updated pet list
            header("Location: profile.php?success=pet");
            exit();
        } else {
            $errors['general'] = "Failed to register pet. Please try again.";
        }
    }

    // Store errors in session to display them on the form page
    $_SESSION['errors'] = $errors;
}

$stmt_pets = $_db->prepare("SELECT * FROM pet WHERE petOwnerID = :user_id");
$stmt_pets->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt_pets->execute();
$pets = $stmt_pets->fetchAll(PDO::FETCH_OBJ);

// Maximum number of pets allowed
$max_pets = 3;
$pet_count = count($pets);

// Check if the form is submitted for adding a new pet or updating an existing pet
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_pet']) && $pet_count < $max_pets) {
    } elseif (isset($_POST['update_pet'])) {
        // Update existing pet logic
        $pet_id = $_POST['selected_pet_id'];
        $pet_name = req('pet_name');
        $species = req('species');
        $breed = req('breed');
        $age = req('age');
        $gender = req('gender');
        $profile_photo = $_POST['current_pet_photo']; // Default to current photo

        // Check if a new profile photo is uploaded
        if (!empty($_FILES['pet_profile_photo']['name'])) {
            $file = $_FILES['pet_profile_photo'];

            // Ensure the file is an image and within the size limit
            if (str_starts_with($file['type'], 'image/') && $file['size'] <= 800 * 1024) { // Max 800KB
                // Generate a unique filename and save
                $profile_photo = uniqid() . '_' . basename($file['name']);
                $upload_dir = '../img/petPhoto/';
                $upload_path = $upload_dir . $profile_photo;

                if (move_uploaded_file($file['tmp_name'], $upload_path)) {
                    // Delete old photo if new upload succeeds
                    if (!empty($_POST['current_pet_photo']) && file_exists($upload_dir . $_POST['current_pet_photo'])) {
                        unlink($upload_dir . $_POST['current_pet_photo']);
                    }
                } else {
                    $profile_photo = $_POST['current_pet_photo']; // Keep old photo if upload fails
                }
            }
        }

        $stmt_update_pet = $_db->prepare("
            UPDATE pet
            SET name = :name, species = :species, breed = :breed, age = :age, gender = :gender, profilePhoto = :profile_photo
            WHERE petID = :pet_id AND petOwnerID = :owner_id
        ");
        $stmt_update_pet->bindParam(':name', $pet_name);
        $stmt_update_pet->bindParam(':species', $species);
        $stmt_update_pet->bindParam(':breed', $breed);
        $stmt_update_pet->bindParam(':age', $age);
        $stmt_update_pet->bindParam(':gender', $gender);
        $stmt_update_pet->bindParam(':profile_photo', $profile_photo);
        $stmt_update_pet->bindParam(':pet_id', $pet_id, PDO::PARAM_INT);
        $stmt_update_pet->bindParam(':owner_id', $user_id, PDO::PARAM_INT);

        if ($stmt_update_pet->execute()) {
            $_SESSION['message'] = 'Pet profile updated successfully!';
            header("Location: profile.php");
            exit();
        } else {
            $error = "Failed to update pet profile. Please try again.";
        }
    }
}

?>


<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User | Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    /* Light mode styles (Default) */
    body {
        background-color: #fff;
        min-height: 100vh;
        margin: 0;
        font-family: 'Arial', sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #000;
    }

    .container {
        max-width: 1000px;
        margin: auto;
    }

    /* Card styling with light mode */
    .card {
        background-color: #fff;
        border-radius: 15px;
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        border: none;
    }

    .list-group-item.active {
        background-color: #007bff;
        color: white !important;
    }

    .list-group-item {
        color: #000;
        background-color: #fff;
        border-color: #007bff;
        transition: all 0.3s ease-in-out;
    }

    .list-group-item:hover {
        background-color: #f0f0f0;
        color: #000;
    }

    .card-body {
        padding: 20px;
    }

    .form-label {
        color: #000;
        font-weight: bold;
    }

    .form-control {
        background-color: #f9f9f9;
        border: 2px solid #ccc;
        color: #000;
        border-radius: 8px;
        padding: 10px;
        transition: all 0.3s ease;
    }

    .form-control:focus {
        outline: none;
        box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.25);
        border-color: #007bff;
    }

    hr {
        border: 0.5px solid #ddd;
    }

    /* Buttons */
    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        padding: 10px 20px;
        border-radius: 50px;
        transition: all 0.3s ease;
    }

    .btn-primary:hover {
        background-color: #c1f5ff;
        border-color: #000000;
    }

    .btn-default {
        background-color: #f1f1f1;
        color: #000;
        padding: 10px 20px;
        border-radius: 50px;
        transition: all 0.3s ease;
    }

    .btn-default:hover {
        background-color: #8a8888;
        color: rgb(17, 13, 13);
        border-color: black;
    }

    /* Pet Image */
    .pet-image {
        border-radius: 50%;
        object-fit: cover;
        width: 150px;
        /* Set the width for a consistent size */
        height: 150px;
        /* Set the height for a consistent size */
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        transition: transform 0.3s ease;
        display: block;
        margin: 0 auto 20px auto;
        /* Center the image */
    }


    .pet-image:hover {
        transform: scale(1.1);
    }

    /* Dark mode */
    .dark-mode {
        background-color: #000;
        color: #fff;
    }

    .dark-mode .card {
        background-color: #1c1c1c;
        box-shadow: 0 6px 18px rgba(255, 255, 255, 0.2);
    }

    .dark-mode .form-label {
        color: white;
    }

    .dark-mode .list-group-item {
        background-color: #1c1c1c;
        color: #fff;
    }

    .dark-mode .list-group-item.active {
        background-color: #007bff;
    }

    .dark-mode .form-control {
        background-color: #333;
        border-color: #555;
        color: #fff;
    }

    .dark-mode .btn-default {
        background-color: #555;
        color: #ddd;
    }

    /* Mode Button Styling with Icons */
    .mode-toggle-btn {
        position: absolute;
        top: 20px;
        right: 20px;
        padding: 12px 15px;
        border-radius: 50px;
        font-size: 20px;
        background-color: #007bff;
        color: white;
        border: none;
        cursor: pointer;
        transition: all 0.3s ease;

        /* Use Flexbox to center content */
        display: flex;
        align-items: center;
        /* Center vertically */
        justify-content: center;
        /* Center horizontally */
    }

    .mode-toggle-btn i {
        margin-right: 12px;
        /* Space between icon and text */
    }


    .dark-mode .mode-toggle-btn {
        background-color: #f8f7f6;
        color: black;
    }

    .media-body {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        margin-top: 15px;
    }

    .file-upload-label {
        position: relative;
        display: inline-block;
        padding: 10px 20px;
        background-color: transparent;
        color: #007bff;
        border: 2px solid #007bff;
        border-radius: 50px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.3s ease, color 0.3s ease;
    }

    .file-upload-label:hover {
        background-color: #007bff;
        color: white;
    }

    .file-upload-label input {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        cursor: pointer;
    }

    .md-btn-flat {
        padding: 10px 20px;
        border-radius: 50px;
        background-color: #f1f1f1;
        color: #000;
        border: 1px solid #ccc;
        transition: all 0.3s ease;
    }

    .md-btn-flat:hover {
        background-color: #ccc;
        color: #000;
    }

    .file-chosen {
        margin-top: 5px;
        font-size: 0.9rem;
        color: #6c757d;
    }

    .file-info {
        margin-top: 5px;
        font-size: 0.9rem;
        color: #6c757d;
    }

    /* Alignment adjustments */
    .d-flex {
        display: flex;
        align-items: center;
    }

    .error {
        color: red;
        font-size: 0.875rem;
    }

    h5 {
        font-size: 1.2rem;
        font-weight: bold;
        margin-right: 10px;
    }
</style>

<body>
    <!-- Button for Light/Dark Mode with Icons -->
    <button id="modeToggleBtn" class="btn mode-toggle-btn">
        <i class="fas fa-moon"></i>
    </button>
    <div class="container light-style flex-grow-1 container-p-y">
        <h4 class="font-weight-bold py-3 mb-4">Account Settings</h4>

        <!-- General Profile Update Form -->
        <form method="POST" enctype="multipart/form-data">
            <div class="card overflow-hidden">
                <div class="row no-gutters row-bordered row-border-light">
                    <div class="col-md-3 pt-0">
                        <div class="list-group list-group-flush account-settings-links">
                            <a class="list-group-item list-group-item-action active" data-toggle="list" href="#account-general">General</a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="tab-content">
                            <div class="tab-pane fade active show" id="account-general">
                                <div class="card-body media align-items-center">
                                    <img src="../img/userPhoto/<?php echo htmlspecialchars($user->profile_photo); ?>" alt="User Photo" class="pet-image">
                                    <div class="media-body">
                                        <label class="btn btn-outline-primary file-upload-label">
                                            Choose File
                                            <input type="file" class="account-settings-fileinput" id="fileInput" name="profile_photo" accept=".jpg,.jpeg,.png">
                                        </label>
                                        <div class="file-chosen text-muted small mt-1" id="fileChosen">No file chosen</div>
                                        <small class="error" id="photoError"></small>
                                    </div>
                                </div>
                                <hr class="border-light m-0">
                                <div class="card-body">
                                    <!-- Username and Email Fields (Read-Only) -->
                                    <div class="form-group">
                                        <label class="form-label" for="username">
                                            <i class="fas fa-user"></i> Username
                                        </label>
                                        <input type="text" id="username" class="form-control mb-1" name="username" value="<?php echo htmlspecialchars($user->username); ?>" readonly>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="email">
                                            <i class="fas fa-envelope"></i> E-mail
                                        </label>
                                        <input type="email" id="email" class="form-control mb-1" name="email" value="<?php echo htmlspecialchars($user->email); ?>" readonly>
                                    </div>

                                    <!-- Editable Fields: Name, Contact, Address, Gender -->
                                    <div class="form-group">
                                        <label class="form-label" for="name">
                                            <i class="fas fa-id-card"></i> Name
                                        </label>
                                        <input type="text" id="name" class="form-control" name="name" value="<?php echo htmlspecialchars($user->name); ?>">
                                        <small class="error"><?php echo $_SESSION['errors']['name'] ?? ''; ?></small>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="contact">
                                            <i class="fas fa-phone"></i> Contact Number
                                        </label>
                                        <input type="text" id="contact" class="form-control" name="contact" value="<?php echo htmlspecialchars($user->contact); ?>">
                                        <small class="error"><?php echo $_SESSION['errors']['contact'] ?? ''; ?></small>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="address">
                                            <i class="fas fa-home"></i> Address
                                        </label>
                                        <input type="text" id="address" class="form-control" name="address" value="<?php echo htmlspecialchars($user->address); ?>">
                                        <small class="error"><?php echo $_SESSION['errors']['address'] ?? ''; ?></small>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="gender">
                                            <i class="fas fa-venus-mars"></i> Gender
                                        </label>
                                        <div class="d-flex align-items-center">
                                            <div class="form-check form-check-inline">
                                                <input type="radio" id="genderMale" name="gender" value="Male" class="form-check-input" <?php echo ($user->gender === 'Male') ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="genderMale">Male</label>
                                            </div>
                                            <div class="form-check form-check-inline ml-3">
                                                <input type="radio" id="genderFemale" name="gender" value="Female" class="form-check-input" <?php echo ($user->gender === 'Female') ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="genderFemale">Female</label>
                                            </div>
                                        </div>
                                        <small class="error" id="genderError"></small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-right mt-3">
                    <button type="submit" class="btn btn-primary" name="update_profile">Save Changes</button>
                    <button type="button" class="btn btn-default"><a href="../index.php" style="text-decoration: none;">Cancel</a></button>
                </div>
            </div>
        </form>

        <!-- Pet Registration Form -->
        <form method="POST" enctype="multipart/form-data">
            <div class="card overflow-hidden mt-4">
                <div class="row no-gutters row-bordered row-border-light">
                    <div class="col-md-3 pt-0">
                        <div class="list-group list-group-flush account-settings-links">
                            <a class="list-group-item list-group-item-action" data-toggle="list" href="#account-info">Pet Info</a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="tab-content">
                            <div class="tab-pane fade show" id="account-info">
                                <div class="card-body pb-2">
                                    <h6 class="font-weight-bold">Pet Details</h6>
                                    <?php if (!empty($pets)): ?>
                                        <?php foreach ($pets as $pet): ?>
                                            <div class="media align-items-center mb-3">
                                                <img src="../img/petPhoto/<?php echo htmlspecialchars($pet->profilePhoto); ?>" alt="Pet Photo" class="pet-image mr-3">
                                                <div class="media-body">
                                                    <h5 class="mt-2">
                                                        <i class="fas fa-paw"></i> <?php echo htmlspecialchars($pet->name); ?>
                                                    </h5>
                                                    <p><i class="fas fa-dog"></i> Species: <?php echo htmlspecialchars($pet->species); ?></p>
                                                    <p><i class="fas fa-cat"></i> Breed: <?php echo htmlspecialchars($pet->breed); ?></p>
                                                    <p><i class="fas fa-venus-mars"></i> Gender: <?php echo htmlspecialchars($pet->gender); ?></p>
                                                    <p><i class="fas fa-birthday-cake"></i> Age: <?php echo htmlspecialchars($pet->age); ?></p>

                                                    <!-- Updated Button to Pass the Correct Pet ID -->
                                                    <button onclick="window.location.href='updatePet.php?id=<?php echo urlencode($pet->petID); ?>'">Update</button>

                                                </div>
                                            </div>
                                            <hr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <p>No pets registered for this account.</p>
                                    <?php endif; ?>

                                    <?php if (count($pets) < $max_pets): ?>
                                        <h6 class="font-weight-bold mt-4">Register a New Pet (<?php echo $max_pets - count($pets); ?> remaining)</h6>

                                        <div class="form-group">
                                            <label for="pet_profile_photo">Pet Profile Photo</label>
                                            <input type="file" class="form-control-file" id="pet_profile_photo" name="pet_profile_photo" accept=".jpg,.jpeg,.png">
                                            <small class="form-text text-muted">Accepted formats: JPG, JPEG, PNG. Max size: 800KB.</small>
                                            <small class="error"><?php echo $_SESSION['errors']['profile_photo'] ?? ''; ?></small>
                                        </div>
                                        <div class="form-group">
                                            <label for="pet_name">Pet Name</label>
                                            <input type="text" class="form-control" name="pet_name">
                                            <small class="error"><?php echo $_SESSION['errors']['pet_name'] ?? ''; ?></small>
                                        </div>
                                        <div class="form-group">
                                            <label for="species">Species</label>
                                            <input type="text" class="form-control" name="species">
                                            <small class="error"><?php echo $_SESSION['errors']['species'] ?? ''; ?></small>
                                        </div>
                                        <div class="form-group">
                                            <label for="breed">Breed</label>
                                            <input type="text" class="form-control" name="breed">
                                            <small class="error"><?php echo $_SESSION['errors']['breed'] ?? ''; ?></small>
                                        </div>
                                        <div class="form-group">
                                            <label for="age">Age</label>
                                            <input type="number" class="form-control" name="age">
                                            <small class="error"><?php echo $_SESSION['errors']['age'] ?? ''; ?></small>
                                        </div>
                                        <div class="form-group">
                                            <label for="gender">Gender</label>
                                            <select class="form-control" name="gender">
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                            <small class="error"><?php echo $_SESSION['errors']['gender'] ?? ''; ?></small>
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="add_pet">Register Pet</button>
                                    <?php else: ?>
                                        <p>You have reached the maximum number of pets allowed (<?php echo $max_pets; ?>).</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>


    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.js"></script>
    <script>
        document.getElementById('modeToggleBtn').addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');

            // Update the button icon and text
            if (document.body.classList.contains('dark-mode')) {
                this.innerHTML = '<i class="fas fa-sun"></i>';
            } else {
                this.innerHTML = '<i class="fas fa-moon"></i>';
            }
        });

        document.getElementById('fileInput').addEventListener('change', function() {
            const fileName = this.files[0] ? this.files[0].name : 'No file chosen';
            document.getElementById('fileChosen').textContent = fileName;
        });

        document.getElementById('resetBtn').addEventListener('click', function() {
            document.getElementById('fileInput').value = '';
            document.getElementById('fileChosen').textContent = 'No file chosen';
        });

        document.getElementById('fileInput').addEventListener('change', function() {
            const fileName = this.files[0] ? this.files[0].name : 'No file chosen';
            document.getElementById('fileChosen').textContent = fileName;
        });

        <?php if (isset($_GET['success']) && $_GET['success'] == 'pet'): ?>
            Swal.fire({
                title: 'Pet Registered!',
                text: 'Your new pet was registered successfully.',
                icon: 'success',
                confirmButtonText: 'OK'
            });
        <?php elseif (isset($_GET['success']) && $_GET['success'] == 'profile'): ?>
            Swal.fire({
                title: 'Profile Updated!',
                text: 'Your profile was updated successfully.',
                icon: 'success',
                confirmButtonText: 'OK'
            });
        <?php elseif (!empty($errors)): ?>
            Swal.fire({
                title: 'Error!',
                text: '<?php echo implode(", ", $errors); ?>',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        <?php endif; ?>
    </script>
</body>

</html>