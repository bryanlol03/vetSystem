<?php
include '../_base.php';
include("../config.php");
require __DIR__ . "/../vendor/autoload.php";

auth();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php"); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user information from the petOwner table
$stmt_user = $_db->prepare("SELECT * FROM petOwner WHERE petOwnerID = :user_id");
$stmt_user->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt_user->execute();
$user = $stmt_user->fetch(PDO::FETCH_OBJ);

if (isset($_GET['id'])) {
    // Retrieve the 'id' parameter from the URL
    $appointmentID = htmlspecialchars($_GET['id']); // Use htmlspecialchars to prevent XSS attacks

    // Example: Query to fetch appointment details
    $stmt = $_db->prepare('SELECT * FROM appointment WHERE appointmentID = ?');
    $stmt->execute([$appointmentID]);
    $appointment = $stmt->fetch(PDO::FETCH_OBJ);
}

if (!$user) {
    header("Location: login.php"); // Redirect to login page if user not found
    exit();
}

// Fetch user's pets from the pet table
$stmt_pets = $_db->prepare("SELECT * FROM pet WHERE petOwnerID = :user_id");
$stmt_pets->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt_pets->execute();
$pets = $stmt_pets->fetchAll(PDO::FETCH_OBJ);

$query = "
    SELECT 
        p.paymentID,
        p.totalAmount,
        p.paymentStatus,
        p.paymentDate,
        p.paymentTime,
        s.serviceName,
        m.medicineName
    FROM payment p
    LEFT JOIN service s ON p.serviceID = s.serviceID
    LEFT JOIN medicine m ON p.medicineID = m.medicineID
    WHERE p.paymentStatus = 'Unpaid';
";

$stmt = $_db->prepare($query);
$stmt->execute();
$payments = $stmt->fetchAll(PDO::FETCH_OBJ);

// $query = "
//     SELECT 
//         p.paymentID,
//         p.totalAmount,
//         p.paymentStatus,
//         p.paymentDate,
//         p.paymentTime,
//         s.serviceName,
//         s.servicePhoto,
//         m.medicineName,
//         m.medicinePrice,
//         m.medicineCategory,
//         pet.name AS petName
//     FROM payment p
//     LEFT JOIN service s ON p.serviceID = s.serviceID
//     LEFT JOIN medicine m ON p.medicineID = m.medicineID
//     LEFT JOIN appointment a ON p.appointmentID = a.appointmentID
//     LEFT JOIN pet pet ON a.petName = pet.petID
//     WHERE pet.petOwnerID = :user_id AND p.paymentStatus = 'Unpaid'
// ";


// $stmt = $_db->prepare($query);
// $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
// $stmt->execute();
// $payments = $stmt->fetchAll(PDO::FETCH_OBJ);

//stripe


?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="alert/dist/sweetalert.css">
    <!------ Include the above in your HEAD tag ---------->
    <title>Payment Page</title>
</head>

<body>
    <input type="hidden" id="status" value="">
    <div class="container wrapper">
        <div class="row cart-head">
            <div class="container">
                <div class="row">
                    <p></p>
                </div>
                <div class="row">
                    <div style="display: table; margin: auto;">
                        <span class="step step_complete"> <a href="appointmentHistory.php" class="check-bc">History</a> <span
                                class="step_line step_complete"> </span> <span class="step_line backline"> </span>
                        </span>
                        <span class="step step_complete"> <a href="../service/contactSupport.php" class="check-bc">Get Help</a> <span
                                class="step_line "> </span> <span class="step_line step_complete"> </span> </span>
                        <span class="step_thankyou check-bc step_complete">Thank you</span>
                    </div>
                </div>

                <div class="row">
                    <p></p>
                </div>
            </div>
        </div>
        <div class="row cart-body">
            <form class="form-horizontal" method="post" action="../service/checkout.php">

                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-push-6 col-sm-push-6">
                    <!--REVIEW ORDER-->

                    <div class="panel panel-info">
                        <div class="panel-heading">
                            Review Order <div class="pull-right"><small><a class="afix-1" href="../service/contactSupport.php">
                               Get Help <i class="fa fa-question-circle" style="font-size: 18px;"></i>
                            </a></small></div>
                        </div>


                        <div class="panel-body">
                        <?php if (!empty($payments)): ?>
                            <?php foreach ($payments as $payment): ?>
                                    <div class="form-group">
                                        <div class="col-sm-3 col-xs-3">
                                            <!-- Display Service Photo -->
                                            <img src="<?= htmlspecialchars($payment->servicePhoto) ?>" alt="Service Photo" width="120" height="120" />
                                        </div>
                                        <div class="col-sm-6 col-xs-6">
                                            <!-- Display Service Name -->
                                            <div class="col-xs-12"><?= htmlspecialchars($payment->serviceName) ?><span></span></div>
                                            <!-- Display Medicine Name and Category -->
                                            <?php if (!empty($payment->medicineName)): ?>
                                                <div class="col-xs-12"><small>Medicine: <?= htmlspecialchars($payment->medicineName) ?> (<?= htmlspecialchars($payment->medicineName) ?>)</small></div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-sm-3 col-xs-3 text-right">
                                            <!-- Display Total Amount -->
                                            <h6><span>MYR</span> <?= htmlspecialchars($payment->totalAmount) ?></h6>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <hr>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p>No unpaid payments found.</p>
                            <?php endif; ?>
                            

                            <div class="form-group">
                                <div class="col-xs-12">
                                    <strong>Total Payment:</strong>
                                    <div class="pull-right">
                                        <span>MYR</span>
                                        <span>
                                            <?php
                                            $totalSum = array_reduce($payments, function ($carry, $item) {
                                                return $carry + $item->totalAmount;
                                            }, 0);
                                            echo htmlspecialchars(number_format($totalSum, 2));
                                            ?>
                                        </span>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-pull-6 col-sm-pull-6">
                    <!--SHIPPING METHOD-->
                    <div class="panel panel-info">
                        <div class="panel-heading">Payment Details</div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-md-12">
                                    <h4><strong>Customers Details : </strong></h4>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-6 col-xs-12">
                                    <strong>Username:</strong>
                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($user->username); ?>" readonly />
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <strong>Theratement ID:</strong>
                                    <input type="text" name="cartId" class="form-control" value="T0001"
                                        readonly />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12"><strong>Street:</strong></div>
                                <div class="col-md-12">
                                    <input type="text" name="street" class="form-control"
                                        value="<?php echo htmlspecialchars($user->address); ?>" />
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="col-md-12"><strong>Phone Number:</strong></div>
                                <div class="col-md-12"><input type="text" name="phone_number" class="form-control"
                                        value="<?php echo htmlspecialchars($user->contact); ?>" /></div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12"><strong>Email Address:</strong></div>
                                <div class="col-md-12"><input type="text" name="email_address" class="form-control"
                                        value="<?php echo htmlspecialchars($user->email); ?>" /></div>
                            </div>
                        </div>

                    </div>
                    <!--SHIPPING METHOD END-->
                    <!--CREDIT CART PAYMENT-->
                    <div class="panel panel-info">
                        <div class="panel-heading"><span><i class="glyphicon glyphicon-lock"></i></span> Secure Payment
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-md-12"><strong>Payment Method:</strong></div>
                                <div class="col-md-12">
                                    <select id="paymentMethod" name="paymentMethod" class="form-control"
                                        onchange="handlePaymentMethodChange()">
                                        <option value="cash">Online Payment</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-12"><strong>Current Date:</strong></div>
                                <div class="col-md-12">
                                    <p id="p1" name="currentDate"></p>
                                </div>
                            </div>
                            <!-- 
                                <div id="creditCardFields" class="form-group" style="display: none;">
                                    <div class="col-md-12"><strong>Credit Card Number:</strong></div>
                                    <div class="col-md-12"><input type="text" class="form-control" name="creditCardNumber"
                                            placeholder="4917 4845 8989 7107" /></div>
                                </div>

                                <div id="cvvFields" class="form-group" style="display: none;">
                                    <div class="col-md-12"><strong>Card CVV:</strong></div>
                                    <div class="col-md-12"><input type="text" class="form-control" name="cardCvv"
                                            placeholder="XXX" /></div>
                                </div> -->

                            <div class="form-group" id="onlineBankingFields" style="display:none">
                                <div class="col-md-12"><strong>Online Banking :</strong></div>
                                <div class="col-md-12">
                                    <select id="onlineBanking" name="onlineBanking" class="form-control">
                                        <option value="">Choose the online banking</option>
                                        <option value="01">Maybank</option>
                                        <option value="02">Public Bank</option>
                                        <option value="03">Hong Leong Bank</option>
                                        <option value="04">RHB Bank</option>
                                        <option value="05">HSBC Bank</option>
                                        <option value="06">UOB Bank</option>
                                        <option value="07">Citi Bank</option>
                                        <option value="08">CIMB Bank</option>
                                        <option value="09">Standard Charted</option>
                                        <option value="10">UOB Bank</option>
                                        <option value="11">Am Bank</option>
                                        <option value="12">Affin Bank</option>
                                    </select>
                                </div>
                            </div>


                            <div id="expirationDateFields" class="form-group" style="display: none;">
                                <div class="col-md-12"><strong>Expiration Date:</strong></div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <select class="form-control" name="expirationMonth">
                                        <option value="">Month</option>
                                        <option value="01">01</option>
                                        <option value="02">02</option>
                                        <option value="03">03</option>
                                        <option value="04">04</option>
                                        <option value="05">05</option>
                                        <option value="06">06</option>
                                        <option value="07">07</option>
                                        <option value="08">08</option>
                                        <option value="09">09</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                    </select>
                                </div>

                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <select class="form-control" name="expirationYear">
                                        <option value="">Year</option>
                                        <option value="2020">2020</option>
                                        <option value="2021">2021</option>
                                        <option value="2022">2022</option>
                                        <option value="2023">2023</option>
                                        <option value="2024">2024</option>
                                        <option value="2025">2025</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-12">
                                    <span>Pay secure using your credit/debit card or cash.</span>
                                </div>
                                <div class="col-md-12">
                                    <ul class="cards">
                                        <li class="visa hand">Visa</li>
                                        <li class="mastercard hand">MasterCard</li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                           
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <button onclick="myFunction()" type="submit"
                                        class="btn btn-primary btn-submit-fix">Pay</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--CREDIT CART PAYMENT END-->
                </div>

            </form>
        </div>
        <div class="row cart-footer">

        </div>
    </div>


    </div>
    </div>
</body>
<script src="vendor/jquery/jquery.min.js"></script>
<script>
    var date = new Date();
    var current_date = date.getFullYear() + " / " + (date.getMonth() + 1) + " / " + date.getDate();
    document.getElementById("p1").innerHTML = current_date;

    function myFunction() {
        alert("Please take note there are no refundable once the payment is maded !");
    }

    function handlePaymentMethodChange() {
        var paymentMethod = document.getElementById("paymentMethod").value;
        var creditCardFields = document.getElementById("creditCardFields");
        var cvvFields = document.getElementById("cvvFields");
        var expirationDateFields = document.getElementById("expirationDateFields");
        var onlineBankingField = document.getElementById("onlineBanking").parentNode.parentNode;
        var cashField = document.getElementById("CashField");

        if (paymentMethod === "cash") {
            creditCardFields.style.display = "none";
            cvvFields.style.display = "none";
            expirationDateFields.style.display = "none";
            onlineBankingField.style.display = "none";
            cashField.style.display = "block";
        } else if (paymentMethod === "creditCard" || paymentMethod === "debitCard") {
            creditCardFields.style.display = "block";
            cvvFields.style.display = "block";
            expirationDateFields.style.display = "block";
            onlineBankingField.style.display = "block";
            cashField.style.display = "none";
        } else {
            creditCardFields.style.display = "none";
            cvvFields.style.display = "none";
            expirationDateFields.style.display = "none";
            onlineBankingField.style.display = "none";
        }
    }
</script>

<script type="text/javascript">
    var status = document.getElementById("status").value;
    if (status == "InvalidCashField") {
        swal("Sorry ! pay by cash field is required");
    } else if (status == "InvalidCash") {
        swal("Sorry ! the amount cannot be 0 and should be equals of more than");
    } else if (status == "invalidCardNumber") {
        swal("Sorry ! Credit or debit should be 16 digit");
    } else if (status == "InvalidCvv") {
        swal("Sorry ! Cvv should be a number");
    } else if (status == "invalidCvvLen") {
        swal("Sorry ! the cvv length should be only 3 only");
    } else if (status == "invalidPaymentMethod") {
        swal("Sorry ! No such payment");
    }
</script>

<style>
    html,
    body,
    .wrapper {
        background: linear-gradient(135deg, #71b7e6, #9b59b6);
    }

    .panel-body {
        padding: 30px;
    }

    .steps {
        margin-top: -41px;
        display: inline-block;
        float: right;
        font-size: 16px
    }

    .step {
        float: left;
        background: white;
        padding: 7px 13px;
        border-radius: 1px;
        text-align: center;
        width: 100px;
        position: relative
    }

    .step_line {
        margin: 0;
        width: 0;
        height: 0;
        border-left: 16px solid #fff;
        border-top: 16px solid transparent;
        border-bottom: 16px solid transparent;
        z-index: 1008;
        position: absolute;
        left: 99px;
        top: 1px
    }

    .step_line.backline {
        border-left: 20px solid #f7f7f7;
        border-top: 20px solid transparent;
        border-bottom: 20px solid transparent;
        z-index: 1006;
        position: absolute;
        left: 99px;
        top: -3px
    }

    .step_complete {
        background: #303030;
    }


    .step_complete a.check-bc,
    .step_complete a.check-bc:hover,
    .afix-1,
    .afix-1:hover {
        color: #eeeeee;
        text-decoration: none;
    }

    .step_line.step_complete {
        background: 0;
        border-left: 16px solid rgb(12, 12, 12);
    }


    .step_thankyou {
        float: left;
        background: linear-gradient(135deg, #71b7e6, #9b59b6);
        padding: 7px 13px;
        border-radius: 1px;
        text-align: center;
        width: 100px;
    }

    .step_thankyou:hover {
        color: white;
    }

    .step.check_step {
        margin-left: 5px;
    }

    .ch_pp {
        text-decoration: underline;
    }

    .ch_pp.sip {
        margin-left: 10px;
    }

    .check-bc,
    .check-bc:hover {
        color: #222;
    }

    .SuccessField {
        border-color: #458845 !important;
        -webkit-box-shadow: 0 0 7px #9acc9a !important;
        -moz-box-shadow: 0 0 7px #9acc9a !important;
        box-shadow: 0 0 7px #9acc9a !important;
        background: #f9f9f9 url(../images/valid.png) no-repeat 98% center !important
    }

    .btn-xs {
        line-height: 28px;
    }

    /*login form*/
    .login-container {
        margin-top: 30px;
    }

    .login-container input[type=submit] {
        width: 100%;
        display: block;
        margin-bottom: 10px;
        position: relative;
    }

    .login-container input[type=text],
    input[type=password] {
        height: 44px;
        font-size: 16px;
        width: 100%;
        margin-bottom: 10px;
        -webkit-appearance: none;
        background: #fff;
        border: 1px solid #d9d9d9;
        border-top: 1px solid #c0c0c0;
        /* border-radius: 2px; */
        padding: 0 8px;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
    }

    .login-container input[type=text]:hover,
    input[type=password]:hover {
        border: 1px solid #b9b9b9;
        border-top: 1px solid #a0a0a0;
        -moz-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
    }

    .login-container-submit {
        /* border: 1px solid #3079ed; */
        border: 0px;
        color: #fff;
        text-shadow: 0 1px rgba(0, 0, 0, 0.1);
        background-color: #357ebd;
        /*#4d90fe;*/
        padding: 17px 0px;
        font-family: roboto;
        font-size: 14px;
        /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#4787ed)); */
    }

    .login-container-submit:hover {
        /* border: 1px solid #2f5bb7; */
        border: 0px;
        text-shadow: 0 1px rgba(0, 0, 0, 0.3);
        background-color: #357ae8;
        /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#357ae8)); */
    }

    .login-help {
        font-size: 12px;
    }

    .asterix {
        background: #f9f9f9 url(../images/red_asterisk.png) no-repeat 98% center !important;
    }

    /* images*/
    ol,
    ul {
        list-style: none;
    }

    .hand {
        cursor: pointer;
        cursor: pointer;
    }

    .cards {
        padding-left: 0;
    }

    .cards li {
        -webkit-transition: all .2s;
        -moz-transition: all .2s;
        -ms-transition: all .2s;
        -o-transition: all .2s;
        transition: all .2s;
        background-image: url('//c2.staticflickr.com/4/3713/20116660060_f1e51a5248_m.jpg');
        background-position: 0 0;
        float: left;
        height: 32px;
        margin-right: 8px;
        text-indent: -9999px;
        width: 51px;
    }

    .cards .mastercard {
        background-position: -51px 0;
    }

    .cards li {
        -webkit-transition: all .2s;
        -moz-transition: all .2s;
        -ms-transition: all .2s;
        -o-transition: all .2s;
        transition: all .2s;
        background-image: url('//c2.staticflickr.com/4/3713/20116660060_f1e51a5248_m.jpg');
        background-position: 0 0;
        float: left;
        height: 32px;
        margin-right: 8px;
        text-indent: -9999px;
        width: 51px;
    }

    .cards .amex {
        background-position: -102px 0;
    }

    .cards li {
        -webkit-transition: all .2s;
        -moz-transition: all .2s;
        -ms-transition: all .2s;
        -o-transition: all .2s;
        transition: all .2s;
        background-image: url('//c2.staticflickr.com/4/3713/20116660060_f1e51a5248_m.jpg');
        background-position: 0 0;
        float: left;
        height: 32px;
        margin-right: 8px;
        text-indent: -9999px;
        width: 51px;
    }

    .cards li:last-child {
        margin-right: 0;
    }

    /* images end */



    /*
     * BOOTSTRAP
     */
    .container {
        border: none;
    }

    .panel-footer {
        background: #fff;
    }

    .btn {
        border-radius: 1px;
    }

    .btn-sm,
    .btn-group-sm>.btn {
        border-radius: 1px;
    }

    .input-sm,
    .form-horizontal .form-group-sm .form-control {
        border-radius: 5px;
    }

    .panel-info {
        border-color: #999;
    }

    .panel-heading {
        border-top-left-radius: 1px;
        border-top-right-radius: 1px;
    }

    .panel {
        border-radius: 2px;
    }

    .panel-info>.panel-heading {
        color: #eee;
        border-color: #000000;
    }

    .panel-info>.panel-heading {
        background-image: linear-gradient(to bottom, #000000 0px, #888 100%);
    }

    hr {
        border-color: #999 -moz-use-text-color -moz-use-text-color;
    }

    .panel-footer {
        border-bottom-left-radius: 1px;
        border-bottom-right-radius: 1px;
        border-top: 1px solid #999;
    }

    .btn-link {
        color: #888;
    }

    hr {
        margin-bottom: 10px;
        margin-top: 10px;
    }

    /** MEDIA QUERIES **/
    @media only screen and (max-width: 989px) {
        .span1 {
            margin-bottom: 15px;
            clear: both;
        }
    }

    @media only screen and (max-width: 764px) {
        .inverse-1 {
            float: right;
        }
    }

    @media only screen and (max-width: 586px) {
        .cart-titles {
            display: none;
        }

        .panel {
            margin-bottom: 1px;
        }
    }

    .form-control {
        border-radius: 1px;
    }

    @media only screen and (max-width: 486px) {
        .col-xss-12 {
            width: 100%;
        }

        .cart-img-show {
            display: none;
        }

        .btn-submit-fix {
            width: 100%;
        }

    }

    /*
    @media only screen and (max-width: 777px){
        .container{
            overflow-x: hidden;
        }
    }*/
</style>

</html>