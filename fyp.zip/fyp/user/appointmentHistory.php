<?php
include '../_base.php';
include '../helper/header.php';

auth(); // Ensure the user is authenticated

$petOwnerID = $_SESSION['user_id']; // Get the logged-in user's ID

// SQL Query
$query = "
    SELECT 
        a.appointmentID,
        a.date AS appointmentDate,
        a.time AS appointmentTime,
        a.status AS appointmentStatus,
        p.paymentStatus,
        p.totalAmount AS paymentAmount,
        pet.name AS petName,
        pet.species AS petSpecies,
        pet.breed AS petBreed,
        pet.age AS petAge
    FROM 
        appointment a
    LEFT JOIN 
        payment p ON a.appointmentID = p.appointmentID
    LEFT JOIN 
        pet pet ON a.petName = pet.name
    WHERE 
        pet.petOwnerID = :petOwnerID
    ORDER BY 
        a.date DESC;
";

$stmt = $_db->prepare($query);
$stmt->bindParam(':petOwnerID', $petOwnerID, PDO::PARAM_INT);
$stmt->execute();
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment History</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="icon" href="../img/logo.png">
    <style>
    
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background: #007bff;
            color: #fff;
        }

        tr:nth-child(odd) {
            background: #f9f9f9;
        }

        tr:hover {
            background: #f1f1f1;
        }

        .btn-back {
            display: inline-block;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 10px;
        }

        .btn-back:hover {
            background: #0056b3;
        }

        .status {
            padding: 5px 10px;
            border-radius: 4px;
            font-weight: bold;
        }

        .status.accepted {
            background-color: #28a745;
            color: #fff;
        }

        .status.cancelled {
            background-color: #dc3545;
            color: #fff;
        }

        .status.pending {
            background-color: #ffc107;
            color: #fff;
        }

        .status.pending-reschedule {
            background-color: #6c757d;
            color: #fff;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Appointment History</h1>
        <table>
            <thead>
                <tr>
                    <th>Appointment ID</th>
                    <th>Pet Name</th>
                    <th>Species</th>
                    <th>Breed</th>
                    <th>Age</th>
                    <th>Appointment Date</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Payment Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($appointments)) : ?>
                    <?php foreach ($appointments as $appointment) : ?>
                        <tr>
                            <td><?= htmlspecialchars($appointment['appointmentID']) ?></td>
                            <td><?= htmlspecialchars($appointment['petName']) ?></td>
                            <td><?= htmlspecialchars($appointment['petSpecies']) ?></td>
                            <td><?= htmlspecialchars($appointment['petBreed']) ?></td>
                            <td><?= htmlspecialchars($appointment['petAge']) ?></td>
                            <td><?= htmlspecialchars($appointment['appointmentDate']) ?></td>
                            <td><?= htmlspecialchars($appointment['appointmentTime']) ?></td>
                            <td>
                                <span class="status <?= strtolower(str_replace(' ', '-', $appointment['appointmentStatus'])) ?>">
                                    <?= htmlspecialchars($appointment['appointmentStatus']) ?>
                                </span>
                            </td>
                            <td>
                                <?= htmlspecialchars($appointment['paymentStatus'] ?? 'Not Paid') ?>
                            </td>
                            <td>
                                <?php if (in_array($appointment['appointmentStatus'], ['Accepted', 'Completed']) && $appointment['paymentStatus'] !== 'Paid') : ?>
                                    <a href="../service/checkOut.php?id=<?= htmlspecialchars($appointment['appointmentID']) ?>" class="btn btn-pay">Pay</a> |
                                <?php endif; ?>
                                <a href="appointment.php?id=<?= htmlspecialchars($appointment['appointmentID']) ?>" class="btn btn-view">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="10" style="text-align: center;">No appointment records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>


        <a href="../index.php" class="btn-back">Back to Dashboard</a>
    </div>
</body>

</html>
<?php 
include '../helper/footer.php';
?>