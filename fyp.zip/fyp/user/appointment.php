<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Vet Clinic Appointment</title>
    <link rel="icon" href="../img/logo.png">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,600,700,900" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<style>
    a {
        text-decoration: none;
        color: white;
    }

    .hover-link {
        color: #f0e68c;
        text-decoration: none;
        /* Optional: removes underline */
    }

    .hover-link:hover {
        color: blue;
    }
</style>
<?php
include '../_base.php'; // Database connection setup
auth();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$user_id = $_SESSION['user_id'];

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php"); // Redirect to login page if not logged in
    exit();
}

// Handle POST request for appointment booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_appointment'])) {
    $_err = []; // Initialize the error array
    $petIDs = $_POST['pet_ids'] ?? [];
    $serviceID = req('service_id');
    $doctorID = req('doctor');
    $appointmentDate = req('date');
    $appointmentTime = req('time');
    $symptoms = trim(req('symptom')) ?: '-'; // Default to '-' if no symptoms are provided

    // Validate: at least one pet is selected
    if (empty($petIDs)) {
        $_err['pet_ids'] = 'Please select at least one pet for the appointment.';
    }

    // Validate: service ID
    if (!$serviceID) {
        $_err['service'] = 'Service type is required';
    }

    // Validate: doctor ID
    if (!$doctorID) {
        $_err['doctor'] = 'Preferred doctor is required';
    }

    // Validate: appointment date
    if (!$appointmentDate) {
        $_err['date'] = 'Appointment date is required';
    }

    // Validate: appointment time
    if (!$appointmentTime) {
        $_err['time'] = 'Appointment time is required';
    }

    // Process appointment if no errors
    if (!$_err) {
        // Check for available rooms based on the service type
        $roomQuery = $_db->prepare('
            SELECT r.roomID FROM room r
            JOIN room_service rs ON r.roomID = rs.roomID
            WHERE rs.serviceID = ? AND r.roomStatus = "Available"
        ');
        $roomQuery->execute([$serviceID]);
        $availableRoom = $roomQuery->fetch(PDO::FETCH_ASSOC);

        if (!$availableRoom) {
            $_err['room'] = 'No available rooms for the selected service type.';
        } else {
            $roomID = $availableRoom['roomID'];

            foreach ($petIDs as $petID) {
                $petQuery = $_db->prepare('SELECT name FROM pet WHERE petID = :petID');
                $petQuery->bindParam(':petID', $petID, PDO::PARAM_INT);
                $petQuery->execute();
                $pet = $petQuery->fetch(PDO::FETCH_ASSOC);

                if ($pet) {
                    $petName = $pet['name'];

                    // Insert the appointment with pet name instead of pet ID
                    $stm = $_db->prepare('
                        INSERT INTO appointment (serviceID, staffID, date, time, status, petName, roomID, symptom)
                        VALUES (?, ?, ?, ?, "Pending", ?, ?, ?)
                    ');
                    $stm->execute([$serviceID, $doctorID, $appointmentDate, $appointmentTime, $petName, $roomID, $symptoms]);
                }
            }

            // Update room status
            $updateRoomStatus = $_db->prepare('
                UPDATE room SET roomStatus = "Occupied" WHERE roomID = ?
            ');
            $updateRoomStatus->execute([$roomID]);

            temp('info', 'Appointment(s) booked successfully!');
            header("Location: ../index.php");
            exit;
        }
    }

    // Store errors in session to display them on the form page
    $_SESSION['errors'] = $_err;
    header("Location: appointment.php");
    exit;
}
?>
<style>
    img {
        max-width: 100%;
        max-height: 300px;
        /* Adjust this value as needed */
        min-width: 150px;
        min-height: 150px;
        object-fit: cover;
        /* Ensures the image scales properly without distortion */
        margin: 0 auto;
        display: block;
        border-radius: 15px;
        /* Optional: Adds rounded corners to the image */
    }

    body {
        font-family: 'Raleway', sans-serif;
        font-weight: 400;
        color: #333;
        background-color: #f0f9ff;
        letter-spacing: 1px;
        margin: 0;
        padding: 0;
        background-image: url('https://example.com/paw-print-background.png');
        /* Replace with a proper background image URL related to vet clinic */
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }

    .container {
        background-color: #fff;
        max-width: 1000px;
        margin: 30px auto;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        display: flex;
        border-radius: 15px;
        overflow: hidden;
        animation: fadeIn 1s ease-in-out;
    }

    .container-time {
        background-color: #4e8d7c;
        padding: 50px;
        text-align: center;
        color: #fff;
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: center;
        animation: slideInLeft 1s ease-out;
    }

    .heading {
        font-size: 35px;
        text-transform: uppercase;
        margin-bottom: 20px;
    }

    .heading-days {
        color: #f0e68c;
        font-size: 24px;
        margin: 10px 0;
    }

    .heading-phone {
        font-size: 20px;
        margin-top: 30px;
    }

    .container-form {
        flex: 2;
        padding: 40px;
        background-color: #fafafa;
        animation: slideInRight 1s ease-out;
    }

    form {
        display: grid;
        grid-gap: 20px;
    }

    .form-field {
        display: flex;
        flex-direction: column;
    }

    .form-field label {
        font-weight: 600;
        margin-bottom: 5px;
        color: #4e8d7c;
    }

    .form-field i {
        margin-right: 10px;
        color: #4e8d7c;
    }

    input,
    select,
    textarea {
        padding: 12px;
        font-size: 16px;
        border: 2px solid #ccc;
        border-radius: 10px;
        background-color: #fff;
        transition: border-color 0.3s ease;
    }

    input:focus,
    select:focus,
    textarea:focus {
        border-color: #4e8d7c;
        outline: none;
    }

    .btn {
        background-color: #4e8d7c;
        color: #fff;
        padding: 15px 30px;
        border: none;
        font-size: 18px;
        border-radius: 100px;
        cursor: pointer;
        transition: all 0.3s;
        align-self: center;
        animation: scaleIn 0.5s ease-in-out;
    }

    .btn:hover {
        background-color: #3c6e62;
        transform: scale(1.05);
        box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
    }

    @media screen and (max-width: 768px) {
        .container {
            flex-direction: column;
        }

        .container-time {
            padding: 30px;
        }
    }

    /* Animations */
    @keyframes fadeIn {
        from {
            opacity: 0;
        }

        to {
            opacity: 1;
        }
    }

    @keyframes slideInLeft {
        from {
            transform: translateX(-100%);
        }

        to {
            transform: translateX(0);
        }
    }

    @keyframes slideInRight {
        from {
            transform: translateX(100%);
        }

        to {
            transform: translateX(0);
        }
    }

    @keyframes scaleIn {
        from {
            transform: scale(0);
        }

        to {
            transform: scale(1);
        }
    }

    /* Styling Radio Buttons */
    .form-gender {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .form-gender label {
        font-weight: 600;
        margin-right: 20px;
        color: #4e8d7c;
    }

    .form-gender input[type="radio"] {
        margin-right: 5px;
    }

    .form-field {
        display: flex;
        flex-direction: column;
    }

    .pet-checkbox-container {
        display: flex;
        flex-wrap: wrap;
    }

    .pet-checkbox {
        width: 50%;
        /* Display two items per row */
        padding: 5px 0;
    }

    .error {
        color: red;
        font-size: 0.875rem;
        margin-top: 5px;
    }
</style>

<body>

    <div class="wrapper">
        <div class="container">
            <div class="container-time">
                <img src="../img/docApp.png" alt="Vet Clinic Image">
                <h2 class="heading">Operation Hours</h2>
                <h3 class="heading-days">Monday-Friday</h3>
                <p>9am - 10pm</p>
                <h3 class="heading-days">Saturday</h3>
                <p>9am - 10pm</p>
                <h3 class="heading-days">Sunday</h3>
                <p>9am - 2pm</p>
                <hr>
                <h4 class="heading-phone">Call Us: (03)-4145 0123</h4>
                <a href="appAvailable.php" class="hover-link">Check Availability</a>
            </div>

            <div class="container-form">
                <form method="post" class="form" enctype="multipart/form-data">
                    <h2 class="heading" style="color: #4e8d7c;">Book an Appointment</h2>

                    <!-- Display error messages if they exist -->
                    <?php if (isset($_SESSION['errors']) && !empty($_SESSION['errors'])): ?>
                        <div class="error-messages">
                            <p style="color: red;">Please fix the following errors:</p>
                            <?php foreach ($_SESSION['errors'] as $field => $error): ?>
                                <p style="color: red;"><?php echo htmlspecialchars($error); ?></p>
                            <?php endforeach; ?>
                        </div>
                        <?php unset($_SESSION['errors']);
                        ?>
                    <?php endif; ?>

                    <div class="form-field">
                        <label><i class="fas fa-paw"></i> Select Pet<span id="selectedCount">0</span>'s for Appointment</label>
                        <div class="pet-checkbox-container">
                            <?php
                            $stmt_pets = $_db->prepare("SELECT petID, name FROM pet WHERE petOwnerID = :user_id");
                            $stmt_pets->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                            $stmt_pets->execute();
                            $pets = $stmt_pets->fetchAll(PDO::FETCH_OBJ);

                            foreach ($pets as $pet) {
                                echo '<div class="pet-checkbox">';
                                echo '<label>';
                                echo '<input type="checkbox" name="pet_ids[]" value="' . htmlspecialchars($pet->petID) . '" class="pet-checkbox-input"> ' . htmlspecialchars($pet->name);
                                echo '</label>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                        <small class="error" id="petError"><?php echo $_SESSION['errors']['pet_ids'] ?? ''; ?></small>
                    </div>

                    <div class="form-field">
                        <label for="service"><i class="fas fa-calendar-alt"></i>Service Type</label>
                        <select id="service" name="service_id" required>
                            <option value="" disabled selected>Select a service</option>
                            <?php
                            $stmt_services = $_db->prepare("SELECT serviceID, serviceName FROM service WHERE status = 'Active'");
                            $stmt_services->execute();
                            $services = $stmt_services->fetchAll(PDO::FETCH_OBJ);

                            foreach ($services as $service) {
                                echo '<option value="' . htmlspecialchars($service->serviceID) . '">' . htmlspecialchars($service->serviceName) . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-field">
                        <label for="doctor"><i class="fas fa-user-md"></i>Preferred Doctor</label>
                        <select id="doctor" name="doctor" required>
                            <option value="" disabled selected>Select a doctor</option>
                            <?php
                            $stmt_doctors = $_db->prepare("SELECT staffID, name FROM staff WHERE role IN ('Veterinarian', 'Surgeon')");
                            $stmt_doctors->execute();
                            $doctors = $stmt_doctors->fetchAll(PDO::FETCH_OBJ);

                            foreach ($doctors as $doctor) {
                                echo '<option value="' . htmlspecialchars($doctor->staffID) . '">' . htmlspecialchars($doctor->name) . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-field">
                        <label for="date"><i class="fas fa-calendar"></i>Date</label>
                        <input type="date" id="date" name="date" required>
                    </div>

                    <div class="form-field">
                        <label for="time"><i class="fas fa-clock"></i>Time</label>
                        <select id="time" name="time" required>
                            <option value="" disabled selected>Select Time</option>
                            <option value="09:00">09:00</option>
                            <option value="10:00">10:00</option>
                            <option value="11:00">11:00</option>
                            <option value="12:00">12:00</option>
                            <option value="13:00">13:00</option>
                            <option value="14:00">14:00</option>
                            <option value="15:00">15:00</option>
                            <option value="16:00">16:00</option>
                            <option value="17:00">17:00</option>
                            <option value="18:00">18:00</option>
                            <option value="19:00">19:00</option>
                            <option value="20:00">20:00</option>
                        </select>
                    </div>

                    <div class="form-field">
                        <label for="symptom"><i class="fas fa-notes-medical"></i>Symptoms <small>(Optional)</small></label>
                        <textarea id="symptom" name="symptom" rows="4" placeholder="Describe the symptoms to help the doctor diagnose quickly"></textarea>
                    </div>

                    <button type="submit" class="btn" name="book_appointment">Submit</button>
                    <button type="button" class="btn"><a href="../index.php">Go Back</a></button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
<script>
    function getQueryParam(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    }

    window.onload = function() {
        const doctorID = getQueryParam('doctor');
        const date = getQueryParam('date');
        const time = getQueryParam('time');

        if (doctorID) {
            document.getElementById('doctor').value = doctorID;
        }

        if (date) {
            document.getElementById('date').value = date;
        }

        if (time) {
            document.getElementById('time').value = time;
        }
    };

    function updateSelectedCount() {
        const checkboxes = document.querySelectorAll('.pet-checkbox-input');
        const selectedCountElement = document.getElementById('selectedCount');
        let selectedCount = 0;

        checkboxes.forEach((checkbox) => {
            if (checkbox.checked) {
                selectedCount++;
            }
        });

        selectedCountElement.textContent = selectedCount;
    }

    document.querySelectorAll('.pet-checkbox-input').forEach((checkbox) => {
        checkbox.addEventListener('change', updateSelectedCount);
    });

    // Validate at least one checkbox is selected before submitting
    document.querySelector("form").addEventListener("submit", function(event) {
        const petCheckboxes = document.querySelectorAll('input[name="pet_ids[]"]');
        const petError = document.getElementById("petError");
        let isChecked = false;

        petCheckboxes.forEach((checkbox) => {
            if (checkbox.checked) {
                isChecked = true;
            }
        });

        if (!isChecked) {
            petError.textContent = "Please select at least one pet for the appointment.";
            event.preventDefault(); // Prevent form submission
        } else {
            petError.textContent = ""; // Clear error message if valid
        }
    });
</script>