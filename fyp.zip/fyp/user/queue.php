<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Queue System</title>
    <link rel="icon" href="img/logo.png">
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        background: linear-gradient(to right, #4facfe, #00f2fe);
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .queue-system {
        background-color: #ffffff;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        width: 450px;
        padding: 20px;
        text-align: center;
    }

    h1 {
        color: #4CAF50;
        margin-bottom: 20px;
    }

    .queue-display {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    .queue-info {
        background-color: #4CAF50;
        color: white;
        padding: 10px;
        border-radius: 8px;
        width: 120px;
        text-align: center;
    }

    .queue-info h2 {
        margin: 0;
        font-size: 16px;
    }

    .queue-info p {
        font-size: 18px;
        margin: 5px 0;
    }

    .queue-form {
        margin-bottom: 20px;
    }

    .queue-form form {
        display: flex;
        flex-direction: column;
    }

    .queue-form label {
        margin-bottom: 5px;
        text-align: left;
        font-weight: bold;
    }

    .queue-form input {
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .queue-form button {
        background-color: #4CAF50;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
    }

    .queue-form button:hover {
        background-color: #45a049;
    }

    .help-section {
        margin-top: 20px;
    }

    #help-button {
        background-color: #ff4c4c;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
    }

    #help-button:hover {
        background-color: #ff3333;
    }

    .datetime {
        margin-top: 20px;
        font-size: 16px;
        color: #333;
    }
</style>
<body>
    <div class="queue-system">
        <h1>Queue System</h1>
        <div class="queue-display">
            <div class="queue-info">
                <h2>Current Queue</h2>
                <p id="current-queue">A001</p>
            </div>
            <div class="queue-info">
                <h2>Next Queue</h2>
                <p id="next-queue">A002</p>
            </div>
            <div class="queue-info">
                <h2>Estimated Waiting Time</h2>
                <p id="waiting-time">5 minutes</p>
            </div>
        </div>

        <div class="queue-form">
            <h2>Take a Number</h2>
            <form id="queue-form">
                <label for="name">Your Name:</label>
                <input type="text" id="name" name="name" required placeholder="Enter your name">

                <label for="pet-name">Pet's Name:</label>
                <input type="text" id="pet-name" name="pet-name" required placeholder="Enter your pet's name">

                <button type="submit">Get Number</button>
            </form>
        </div>

        <div class="help-section">
            <button id="help-button">Emergency Request</button>
        </div>

        <div class="datetime">
            <p id="current-date-time"></p>
        </div>
    </div>

    <script>
        let queueNumber = 3; // Start from the next available number

        function updateDateTime() {
            const now = new Date();
            const dateTimeString = now.toLocaleString();
            document.getElementById('current-date-time').textContent = "Current Date & Time: " + dateTimeString;
        }

        // Update date and time every second
        setInterval(updateDateTime, 1000);

        document.getElementById('queue-form').addEventListener('submit', function(event) {
            event.preventDefault();
            const name = document.getElementById('name').value;
            const petName = document.getElementById('pet-name').value;
            const generatedQueueNumber = `A00${queueNumber}`;
            alert(`Thank you, ${name}. Your queue number is ${generatedQueueNumber}. Your pet's name is ${petName}.`);

            // Update queue display
            document.getElementById('current-queue').textContent = generatedQueueNumber;
            queueNumber++; // Increment for the next person
            document.getElementById('next-queue').textContent = `A00${queueNumber}`;
        });

        document.getElementById('help-button').addEventListener('click', function() {
            alert("Help is on the way!");
        });
    </script>
</body>
</html>
