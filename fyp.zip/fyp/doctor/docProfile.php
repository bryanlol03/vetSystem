<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor | Staff Profile</title>
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    .pet-image {
        border-radius: 50%;
        object-fit: cover;
        width: 150px;
        /* Set the width for a consistent size */
        height: 150px;
        /* Set the height for a consistent size */
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        transition: transform 0.3s ease;
        display: block;
        margin: 0 auto 20px auto;
        /* Center the image */
    }

    .pet-image:hover {
        transform: scale(1.1);
    }

    .dark-mode .card {
        background-color: #1c1c1c;
        box-shadow: 0 6px 18px rgba(255, 255, 255, 0.2);
    }

    .dark-mode .form-label {
        color: white;
    }

    .dark-mode .list-group-item {
        background-color: #1c1c1c;
        color: #fff;
    }

    .dark-mode .list-group-item.active {
        background-color: #007bff;
    }

    .dark-mode .form-control {
        background-color: #333;
        border-color: #555;
        color: #fff;
    }

    .dark-mode .btn-default {
        background-color: #555;
        color: #ddd;
    }

    /* Mode Button Styling with Icons */
    .mode-toggle-btn {
        position: absolute;
        top: 20px;
        right: 20px;
        padding: 12px 15px;
        border-radius: 50px;
        font-size: 20px;
        background-color: #007bff;
        color: white;
        border: none;
        cursor: pointer;
        transition: all 0.3s ease;

        /* Use Flexbox to center content */
        display: flex;
        align-items: center;
        /* Center vertically */
        justify-content: center;
        /* Center horizontally */
    }

    .mode-toggle-btn i {
        margin-right: 12px;
        /* Space between icon and text */
    }


    .dark-mode .mode-toggle-btn {
        background-color: #f8f7f6;
        color: black;
    }

    .media-body {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        margin-top: 15px;
    }
</style>
<?php
include '../_base.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure the user is logged in by checking `staff_id`
if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php");
    exit();
}

$staff_id = $_SESSION['staff_id'];

// Fetch staff information from the staff table
$stmt_staff = $_db->prepare("SELECT * FROM staff WHERE staffID = :staff_id");
$stmt_staff->bindParam(':staff_id', $staff_id, PDO::PARAM_INT);
$stmt_staff->execute();
$staff = $stmt_staff->fetch(PDO::FETCH_OBJ);

if (!$staff) {
    header("Location: login.php"); // Redirect to login page if staff not found
    exit();
}

// Process profile updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = req('name');
    $contact = req('contact');
    $profile_photo = $staff->profilePhoto; // Use existing photo initially
    $errors = [];

    // Validate required fields
    if (empty($name)) {
        $errors['name'] = 'Name is required.';
    } elseif (strlen($name) < 3) {
        $errors['name'] = 'Name must be at least 3 characters.';
    } elseif (strlen($name) > 100) {
        $errors['name'] = 'Name cannot exceed 100 characters.';
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        $errors['name'] = 'Name can only contain letters and spaces.';
    }

    if (empty($contact)) {
        $errors['contact'] = 'Contact number is required.';
    } elseif (!preg_match("/^[0-9]{10}$/", $contact)) {
        $errors['contact'] = 'Contact number must be exactly 10 digits and contain only numbers.';
    }

    // Validate profile photo upload
    if (!empty($_FILES['profile_photo']['name'])) {
        $file = $_FILES['profile_photo'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

        if (!in_array($file['type'], $allowed_types)) {
            $errors['profile_photo'] = 'File must be an image (JPG, PNG, GIF).';
        } elseif ($file['size'] > 800 * 1024) { // Max 800 KB
            $errors['profile_photo'] = 'Image must be smaller than 800 KB.';
        } else {
            // Process photo upload
            $profile_photo = uniqid() . '_' . basename($file['name']);
            $upload_dir = '../img/staffPhoto/';
            $upload_path = $upload_dir . $profile_photo;

            if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
                $errors['profile_photo'] = 'Failed to upload photo.';
            } else {
                // Delete old photo if a new one is successfully uploaded
                if (!empty($staff->profilePhoto) && file_exists($upload_dir . $staff->profilePhoto) && $staff->profilePhoto !== 'unknown.jpg') {
                    unlink($upload_dir . $staff->profilePhoto);
                }
            }
        }
    }

    // Update database if no errors
    if (empty($errors)) {
        try {
            $stmt_update = $_db->prepare("
                UPDATE staff 
                SET name = :name, contact = :contact, profilePhoto = :profilePhoto 
                WHERE staffID = :staff_id
            ");
            $stmt_update->bindParam(':name', $name);
            $stmt_update->bindParam(':contact', $contact);
            $stmt_update->bindParam(':profilePhoto', $profile_photo);
            $stmt_update->bindParam(':staff_id', $staff_id, PDO::PARAM_INT);

            if ($stmt_update->execute()) {
                temp('info', 'Profile updated successfully.');
                header("Location: docProfile.php"); // Redirect to profile page
                exit();
            } else {
                $errors['general'] = 'Failed to update profile. Please try again.';
            }
        } catch (PDOException $e) {
            $errors['general'] = 'Database error: ' . $e->getMessage();
        }
    }

    // Store errors in session to display them on the form page
    $_SESSION['errors'] = $errors;
}
?>

<body>
    <!-- Button for Light/Dark Mode with Icons -->
    <button id="modeToggleBtn" class="btn mode-toggle-btn">
        <i class="fas fa-moon"></i>
    </button>
    <div class="container light-style flex-grow-1 container-p-y">
        <h4 class="font-weight-bold py-3 mb-4">Staff Profile Settings</h4>

        <!-- Profile Update Form -->
        <form method="POST" enctype="multipart/form-data">
            <div class="card overflow-hidden">
                <div class="row no-gutters row-bordered row-border-light">
                    <div class="col-md-3 pt-0">
                        <div class="list-group list-group-flush account-settings-links">
                            <a class="list-group-item list-group-item-action active" data-toggle="list" href="#account-general">General</a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="tab-content">
                            <div class="tab-pane fade active show" id="account-general">
                                <div class="card-body media align-items-center">
                                    <img src="../img/staffPhoto/<?php echo htmlspecialchars($staff->profilePhoto) ?: 'unknown.jpg'; ?>" alt="Staff Photo" class="pet-image">
                                    <div class="media-body">
                                        <label class="btn btn-outline-primary file-upload-label">
                                            Choose File
                                            <input type="file" class="account-settings-fileinput" id="fileInput" name="profile_photo" accept=".jpg,.jpeg,.png">
                                        </label>
                                        <div class="file-chosen text-muted small mt-1" id="fileChosen">No file chosen</div>
                                        <small class="error"><?php echo $_SESSION['errors']['profile_photo'] ?? ''; ?></small>
                                    </div>
                                </div>
                                <hr class="border-light m-0">
                                <div class="card-body">
                                    <!-- Editable Fields: Name, Contact -->
                                    <div class="form-group">
                                        <label class="form-label" for="name">
                                            <i class="fas fa-user"></i> Name
                                        </label>
                                        <input type="text" id="name" class="form-control" name="name" value="<?php echo htmlspecialchars($staff->name); ?>">
                                        <small class="error"><?php echo $_SESSION['errors']['name'] ?? ''; ?></small>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="contact">
                                            <i class="fas fa-phone"></i> Contact Number
                                        </label>
                                        <input type="text" id="contact" class="form-control" name="contact" value="<?php echo htmlspecialchars($staff->contact); ?>">
                                        <small class="error"><?php echo $_SESSION['errors']['contact'] ?? ''; ?></small>
                                    </div>

                                    <!-- Non-editable Fields: Role, Email, Password -->
                                    <div class="form-group">
                                        <label class="form-label" for="email">
                                            <i class="fas fa-envelope"></i> Email
                                        </label>
                                        <input type="email" id="email" class="form-control mb-1" name="email" value="<?php echo htmlspecialchars($staff->email); ?>" readonly>
                                        <small class="form-text text-muted">Email is not editable.</small>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="role">
                                            <i class="fas fa-briefcase"></i> Role
                                        </label>
                                        <input type="text" id="role" class="form-control mb-1" name="role" value="<?php echo htmlspecialchars($staff->role); ?>" readonly>
                                        <small class="form-text text-muted">Role is not editable.</small>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="password">
                                            <i class="fas fa-lock"></i> Password
                                        </label>
                                        <input type="password" id="password" class="form-control mb-1" name="password" value="********" readonly>
                                        <small class="form-text text-muted">Password is not editable.</small>
                                        <br>
                                        <a href="../user/forgotPsw.php" class="form-text text-primary" style="text-decoration: none;">
                                            <i class="fas fa-key"></i> Forgot Password?
                                        </a>
                                    </div>

                                    <!-- Editable Gender Field -->
                                    <div class="form-group">
                                        <label class="form-label" for="gender">
                                            <i class="fas fa-venus-mars"></i> Gender
                                        </label>
                                        <div class="d-flex align-items-center">
                                            <div class="form-check form-check-inline">
                                                <input type="radio" id="genderMale" name="gender" value="Male" class="form-check-input" <?php echo ($staff->gender === 'Male') ? 'checked' : ''; ?> disabled>
                                                <label class="form-check-label" for="genderMale">Male</label>
                                            </div>
                                            <div class="form-check form-check-inline ml-3">
                                                <input type="radio" id="genderFemale" name="gender" value="Female" class="form-check-input" <?php echo ($staff->gender === 'Female') ? 'checked' : ''; ?> disabled>
                                                <label class="form-check-label" for="genderFemale">Female</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-right mt-3">
                    <button type="submit" class="btn btn-primary" name="update_profile">Save Changes</button>
                    <button type="button" class="btn btn-default"><a href="docDashboard.php" style="text-decoration: none;">Cancel</a></button>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.js"></script>
    <script>
        // Toggle between light and dark mode using button
        document.getElementById('modeToggleBtn').addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            if (document.body.classList.contains('dark-mode')) {
                this.innerHTML = '<i class="fas fa-sun"></i>';
            } else {
                this.innerHTML = '<i class="fas fa-moon"></i>';
            }
        });

        document.getElementById('fileInput').addEventListener('change', function() {
            const fileName = this.files[0] ? this.files[0].name : 'No file chosen';
            document.getElementById('fileChosen').textContent = fileName;
        });

        <?php if (isset($_SESSION['errors']) && !empty($_SESSION['errors'])): ?>
            Swal.fire({
                title: 'Error!',
                text: '<?php echo implode(", ", $_SESSION['errors']); ?>',
                icon: 'error',
                confirmButtonText: 'OK'
            });
            <?php unset($_SESSION['errors']); ?>
        <?php endif; ?>
    </script>
</body>

</html>