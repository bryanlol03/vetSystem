<?php
include_once '../_base.php'; // Ensures session_start and DB connection
include '../helper/docHeader.php';

// Ensure staff_id is set via session
if (!isset($_SESSION['staff_id'])) {
    echo "Staff ID is not set.";
    exit();
}

$staff_id = $_SESSION['staff_id']; // Logged-in staff ID

// Fetch appointments associated with this staff ID
$sql = "
    SELECT a.appointmentID, a.date, a.time, a.status, a.petName, a.symptom, s.serviceName
    FROM appointment a
    JOIN service s ON a.serviceID = s.serviceID
    WHERE a.staffID = :staff_id
    ORDER BY a.date ASC, a.time ASC
";

// Prepare and execute query
$stmt = $_db->prepare($sql);
$stmt->bindParam(':staff_id', $staff_id, PDO::PARAM_INT);
$stmt->execute();
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group appointments by date
$groupedAppointments = [];
foreach ($appointments as $appointment) {
    $date = $appointment['date'];
    if (!isset($groupedAppointments[$date])) {
        $groupedAppointments[$date] = [];
    }
    $groupedAppointments[$date][] = $appointment;
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nurse | View Appointment</title>
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="../css/swiper.css">
    <link rel="stylesheet" href="../css/dashboard.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .status-pending {
            color: #FFC107;
        }

        .status-accepted {
            color: #28A745;
        }

        .status-rejected,
        .status-cancelled {
            color: #DC3545;
        }

        .status-default {
            color: #6C757D;
        }

        .timeline__header {
            background-color: #f4f4f4;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            margin-bottom: 10px;
        }

        .timeline__header-day {
            font-size: 1.5em;
            font-weight: bold;
        }

        .timeline__header-month {
            font-size: 1em;
            color: #888;
        }

        .timeline__row {
            padding: 8px;
            padding-bottom: 30px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .timeline__hour {
            font-weight: bold;
            font-size: 1.2em;
            color: #0056b3;
            margin-bottom: 5px;
        }

        .timeline__details {
            font-size: 1.1em;
            color: #333;
        }

        .timeline__symptom {
            margin-top: 10px;
            font-size: 1em;
            color: #777;
            white-space: pre-line;
            word-wrap: break-word;
        }

        .timeline__status {
            font-weight: bold;
            font-size: 1.1em;
            margin-top: 5px;
        }

        .timeline__doctor {
            color: #0056b3;
        }
        
    </style>
</head>

<body>
    <div class="content-subheader">
        <div class="content-subheader__titles">
            <h2 class="content-subheader__title">Appointments</h2>
            <nav class="content-subheader__breadcrumb-menu">
                <ul>
                    <li><a href="dashboard.html">Dashboard</a></li>
                </ul>
            </nav>
        </div>
    </div>

    <div class="timeline">
        <div class="timeline__content swiper-wrapper">
            <?php if (!empty($groupedAppointments)): ?>
                <?php foreach ($groupedAppointments as $date => $appointments): ?>
                    <div class="timeline__slide swiper-slide">
                        <div class="timeline__header">
                            <span class="timeline__header-day"><?php echo htmlspecialchars(date("d M", strtotime($date))); ?></span>
                            <span class="timeline__header-month"><?php echo htmlspecialchars(date("l", strtotime($date))); ?></span>
                        </div>
                        <div class="timeline__grid scrollbar-macosx">
                            <?php foreach ($appointments as $appointment): ?>
                                <div class="timeline__row">
                                    <div class="timeline__hour"><?php echo htmlspecialchars(date("h A", strtotime($appointment['time']))); ?></div>
                                    <div class="timeline__details">
                                        <h3 class="timeline__user"><?php echo htmlspecialchars($appointment['petName']); ?></h3>
                                        <div class="timeline__info"><?php echo htmlspecialchars($appointment['serviceName']); ?></div>
                                        <div class="timeline__status <?php echo 'status-' . strtolower($appointment['status']); ?>">
                                            <?php echo htmlspecialchars($appointment['status']); ?>
                                        </div>
                                        <div class="timeline__symptom"><?php echo htmlspecialchars($appointment['symptom']); ?></div>

                                        <!-- Add the show-more icon and dropdown for Thereament link -->
                                        <span class="show-more show-more--ellipsis show-more--ellipsis-vertical has-dropdown" onclick="toggleDropdownMenu(this)"></span>
                                        <nav class="dropdown-menu dropdown-menu--content dropdown-menu--timeline" style="display: none;">
                                            <ul>
                                                <li><a href="docThereament.php?id=<?= htmlspecialchars($appointment['appointmentID']) ?>">Treatment</a></lis>
                                                <li><a href="docMedicineRecommend.php?id=<?= htmlspecialchars($appointment['appointmentID']) ?>">open medicine</a></lis>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="timeline__slide swiper-slide">
                    <div class="timeline__header">
                        <span class="timeline__header-day">No</span>
                        <span class="timeline__header-month">Appointments Found</span>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/moment.min.js"></script>
    <script src="js/daterangepicker.min.js"></script>
    <script src="js/jquery.scrollbar.js"></script>
    <script src="js/swiper.min.js"></script>
    <script src="js/select2.min.js"></script>
    <script src="js/ion.rangeSlider.min.js"></script>
    <script src="js/jquery.dashboard-custom.js"></script>

    <script>
        function toggleDropdownMenu(element) {
            const dropdownMenu = element.nextElementSibling;
            if (dropdownMenu.style.display === 'none' || dropdownMenu.style.display === '') {
                dropdownMenu.style.display = 'block';
            } else {
                dropdownMenu.style.display = 'none';
            }
        }

        function validateAppointmentDate(appointmentDate, appointmentTime) {
            const now = new Date();
            const appointmentDateTime = new Date(`${appointmentDate}T${appointmentTime}`);
            if (appointmentDateTime <= now) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'You cannot accept an appointment for a past date or a time that has already passed.',
                });
                return false;
            }
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'Appointment is valid and ready to be accepted.',
            });
            return true;
        }

        function confirmCancellation(event, appointmentID) {
            event.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Cancel Appointment',
                text: 'Are you sure you want to cancel this appointment?',
                showCancelButton: true,
                confirmButtonText: 'Yes, cancel it!',
                cancelButtonText: 'No, keep it',
            }).then((result) => {
                if (result.isConfirmed) {
                    document.querySelector(`#cancelForm-${appointmentID}`).submit();
                }
            });
        }

        document.addEventListener("DOMContentLoaded", function() {
            const showMoreButtons = document.querySelectorAll(".show-more");
            showMoreButtons.forEach(button => {
                button.addEventListener("click", function() {
                    const dropdownMenu = this.nextElementSibling;
                    if (dropdownMenu) {
                        dropdownMenu.classList.toggle("active");
                    }
                });
            });

            document.addEventListener("click", function(event) {
                if (!event.target.closest(".show-more") && !event.target.closest(".dropdown-menu")) {
                    document.querySelectorAll(".dropdown-menu").forEach(menu => {
                        menu.classList.remove("active");
                    });
                }
            });
        });
    </script>
</body>

</html>