<?php
include('../_base.php');

// Retrieve medical record details using recordID from URL
$recordID = $_GET['id'] ?? null;

if ($recordID) {
    // Fetch the medical record details, including the human-readable service name
    $query = "
        SELECT mr.recordID, 
               mr.serviceType, 
               mr.medicineName, 
               mr.date, 
               mr.notes, 
               mr.diagnosis, 
               p.name AS petName 
        FROM medicalRecord mr
        JOIN pet p ON mr.petID = p.petID
        WHERE mr.recordID = :recordID";
    $stmt = $_db->prepare($query);
    $stmt->bindParam(':recordID', $recordID);
    $stmt->execute();
    $medicalRecord = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$medicalRecord) {
        echo "Medical record not found.";
        exit;
    }
} else {
    echo "Invalid record ID.";
    exit;
}
//code can work ----
// if ($_SERVER["REQUEST_METHOD"] == "POST") {
//     // Get the new values from the form
//     $newServiceType = $_POST['serviceType'];
//     $newMedicineIDs = isset($_POST['medicineID']) ? $_POST['medicineID'] : []; // Array of selected medicine IDs
//     $newNotes = $_POST['notes'];
//     $newDiagnosis = $_POST['diagnosis'];

//     // Fetch medicine names from the database
//     $newMedicineNames = [];
//     if (!empty($newMedicineIDs)) {
//         $placeholders = implode(',', array_fill(0, count($newMedicineIDs), '?'));
//         $query = "SELECT medicineName FROM medicine WHERE medicineID IN ($placeholders)";
//         $stmt = $_db->prepare($query);
//         $stmt->execute($newMedicineIDs);
//         $newMedicineNames = $stmt->fetchAll(PDO::FETCH_COLUMN); // Fetch medicine names as an array
//     }

//     // Convert the medicine names to a comma-separated string
//     $medicineNamesString = implode(', ', $newMedicineNames);

//     // Update the medical record
//     $updateQuery = "
//         UPDATE medicalRecord 
//         SET serviceType = :newServiceType, 
//             medicineName = :medicineNamesString, 
//             notes = :newNotes, 
//             diagnosis = :newDiagnosis
//         WHERE recordID = :recordID";
//     $updateStmt = $_db->prepare($updateQuery);
//     $updateStmt->bindParam(':newServiceType', $newServiceType);
//     $updateStmt->bindParam(':medicineNamesString', $medicineNamesString);
//     $updateStmt->bindParam(':newNotes', $newNotes);
//     $updateStmt->bindParam(':newDiagnosis', $newDiagnosis);
//     $updateStmt->bindParam(':recordID', $recordID);

//     if ($updateStmt->execute()) {
//         echo "<div class='alert alert-success'>Medical record updated successfully.</div>";
//         header("Location: adGeneratePayment.php");
//         exit;
//     } else {
//         echo "<div class='alert alert-danger'>Failed to update medical record.</div>";
//     }
// }

//testing
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $petID = $_POST['petID']; // Now storing petID
    $serviceID = $_POST['serviceType']; // Service ID selected by user
    $medicineIDs = isset($_POST['medicineID']) ? $_POST['medicineID'] : [];
    $notes = $_POST['notes'];
    $diagnosis = $_POST['diagnosis'];
    $appointmentID = $_POST['appointmentID']; // Link to the appointment ID

    // Convert medicine IDs to names for storing in medicalRecord
    if (!empty($medicineIDs)) {
        $placeholders = implode(',', array_fill(0, count($medicineIDs), '?'));
        $query = "SELECT medicineName FROM medicine WHERE medicineID IN ($placeholders)";
        $stmt = $_db->prepare($query);
        $stmt->execute($medicineIDs);
        $medicineNames = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // Join medicine names into a comma-separated string
        $medicineNamesString = implode(', ', $medicineNames);
    } else {
        $medicineNamesString = ''; // No medicines selected
    }

    // Update medical record with new details
    $updateQuery = "
        UPDATE medicalRecord 
        SET serviceType = :serviceID, 
            medicineName = :medicineNames, 
            notes = :notes, 
            diagnosis = :diagnosis,
            petID = :petID
        WHERE recordID = :recordID";
    $stmt = $_db->prepare($updateQuery);
    $stmt->bindParam(':serviceID', $serviceID);
    $stmt->bindParam(':medicineNames', $medicineNamesString);
    $stmt->bindParam(':notes', $notes);
    $stmt->bindParam(':diagnosis', $diagnosis);
    $stmt->bindParam(':petID', $petID);
    $stmt->bindParam(':recordID', $recordID);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Medical record updated successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Failed to update medical record.</div>";
    }

    // Retrieve service price from database
    $query = "SELECT servicePrice FROM service WHERE serviceID = :serviceID";
    $stmt = $_db->prepare($query);
    $stmt->bindParam(':serviceID', $serviceID);
    $stmt->execute();
    $servicePrice = $stmt->fetchColumn();

    if ($servicePrice === false) {
        echo "<div class='alert alert-danger'>Invalid service ID.</div>";
        exit;
    }

    // Calculate total medicine price
    $totalMedicinePrice = 0;
    if (!empty($medicineIDs)) {
        $placeholders = implode(',', array_fill(0, count($medicineIDs), '?'));
        $query = "SELECT SUM(medicinePrice) FROM medicine WHERE medicineID IN ($placeholders)";
        $stmt = $_db->prepare($query);
        $stmt->execute($medicineIDs);
        $totalMedicinePrice = $stmt->fetchColumn() ?: 0;
    }

    $totalAmount = $servicePrice + $totalMedicinePrice;

    // Insert into payment table
    $insertPaymentQuery = "
        INSERT INTO payment (totalAmount, paymentStatus, paymentDate, paymentTime, serviceID, medicineID, appointmentID, petID)
        VALUES (:totalAmount, 'Unpaid', '-', '-', :serviceID, :medicineIDs, :appointmentID, :petID)";
    $stmt = $_db->prepare($insertPaymentQuery);
    $stmt->bindParam(':totalAmount', $totalAmount);
    $stmt->bindParam(':serviceID', $serviceID);
    $stmt->bindParam(':medicineIDs', implode(',', $medicineIDs));
    $stmt->bindParam(':appointmentID', $appointmentID);
    $stmt->bindParam(':petID', $petID);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Payment record created successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Failed to create payment record.</div>";
    }
}

// Fetch all active service names for the dropdown
$stmt = $_db->prepare("SELECT serviceName FROM service WHERE status = 'Active'");
$stmt->execute();
$serviceTypes = $stmt->fetchAll(PDO::FETCH_ASSOC);

try {
    // Fetch medical records grouped by date
    $stmt = $_db->prepare("
        SELECT 
            m.recordID, 
            m.date, 
            m.notes, 
            m.diagnosis, 
            p.name AS petName, 
            m.serviceType, 
            m.medicineName, 
            a.symptom, 
            a.status, 
            a.time, 
            a.appointmentID, 
            s.serviceName
        FROM medicalrecord m
        INNER JOIN pet p ON m.petID = p.petID
        INNER JOIN appointment a ON m.appointmentID = a.appointmentID
        INNER JOIN service s ON a.serviceID = s.serviceID
        ORDER BY m.date DESC
    ");
    $stmt->execute();
    $medicalRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Group records by date
    $groupedAppointments = [];
    foreach ($medicalRecords as $record) {
        $groupedAppointments[$record['date']][] = $record;
    }
} catch (Exception $e) {
    die("Error fetching records: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Medical Record</title>
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag@3.1.0/dist/css/multi-select-tag.css">
    <script src="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag@3.1.0/dist/js/multi-select-tag.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');

        * {
            margin: 0;
            padding: 0;
            outline: none;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 10px;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(115deg, #56d8e4 10%, #9f01ea 90%);
        }

        .container {
            max-width: 800px;
            background: #fff;
            width: 800px;
            padding: 25px 40px 10px 40px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .container .text {
            text-align: center;
            font-size: 41px;
            font-weight: 600;
            font-family: 'Poppins', sans-serif;
            background: -webkit-linear-gradient(right, #56d8e4, #9f01ea, #56d8e4, #9f01ea);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .container form {
            padding: 30px 0 0 0;
        }

        .container form .form-row {
            display: flex;
            margin: 32px 0;
        }

        form .form-row .input-data {
            width: 100%;
            height: 40px;
            margin: 0 20px;
            position: relative;
        }

        form .form-row .textarea {
            height: 70px;
        }

        .input-data input,
        .textarea textarea {
            display: block;
            width: 100%;
            height: 100%;
            border: none;
            font-size: 17px;
            border-bottom: 2px solid rgba(0, 0, 0, 0.12);
        }

        .input-data input:focus~label,
        .textarea textarea:focus~label,
        .input-data input:valid~label,
        .textarea textarea:valid~label {
            transform: translateY(-20px);
            font-size: 14px;
            color: #3498db;
        }

        .textarea textarea {
            resize: none;
            padding-top: 10px;
        }

        .input-data label {
            position: absolute;
            pointer-events: none;
            bottom: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .textarea label {
            width: 100%;
            bottom: 40px;
            background: #fff;
        }

        .input-data .underline {
            position: absolute;
            bottom: 0;
            height: 2px;
            width: 100%;
        }

        .input-data .underline:before {
            position: absolute;
            content: "";
            height: 2px;
            width: 100%;
            background: #3498db;
            transform: scaleX(0);
            transform-origin: center;
            transition: transform 0.3s ease;
        }

        .input-data input:focus~.underline:before,
        .input-data input:valid~.underline:before,
        .textarea textarea:focus~.underline:before,
        .textarea textarea:valid~.underline:before {
            transform: scale(1);
        }

        .submit-btn .input-data {
            overflow: hidden;
            height: 45px !important;
            width: 25% !important;
        }

        .submit-btn .input-data .inner {
            height: 100%;
            width: 300%;
            position: absolute;
            left: -100%;
            background: -webkit-linear-gradient(right, #56d8e4, #9f01ea, #56d8e4, #9f01ea);
            transition: all 0.4s;
        }

        .submit-btn .input-data:hover .inner {
            left: 0;
        }

        .submit-btn .input-data input {
            background: none;
            border: none;
            color: #fff;
            font-size: 17px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
            cursor: pointer;
            position: relative;
            z-index: 2;
        }

        @media (max-width: 700px) {
            .container .text {
                font-size: 30px;
            }

            .container form {
                padding: 10px 0 0 0;
            }

            .container form .form-row {
                display: block;
            }

            form .form-row .input-data {
                margin: 35px 0 !important;
            }

            .submit-btn .input-data {
                width: 40% !important;
            }
        }

        textarea {
            width: 100%;
            height: 50px;
            padding: 12px 20px;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
            background-color: #f8f8f8;
            font-size: 16px;
            resize: none;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="text">Edit Medical Record</div>
        <form method="POST" action="">
      
            <div class="form-row">
                <label class="input-label">Pet Name</label>
                <div class="input-data">
                    <input type="text" name="petName" value="<?= htmlspecialchars($medicalRecord['petName']) ?>" readonly>
                </div>
            </div>
            <div class="form-row">
                <label>Service Type:</label>
                <select name="serviceType" required>
                    <?php foreach ($serviceTypes as $service): ?>
                        <option value="<?= htmlspecialchars($service['serviceName']) ?>"
                            <?= $service['serviceName'] === $medicalRecord['serviceType'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($service['serviceName']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row">
                <label for="input-label">Medicine Name</label>
                <select name="medicineID[]" id="medicineName" multiple>
                    <?php
                    // Fetch medicines from the database
                    $query = "SELECT medicineID, medicineName FROM medicine WHERE expiryDate >= CURDATE()";
                    $stmt = $_db->prepare($query);
                    $stmt->execute();
                    $medicines = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    // Loop through the medicines and populate the dropdown
                    foreach ($medicines as $medicine) {
                        echo '<option value="' . htmlspecialchars($medicine['medicineID']) . '">' . htmlspecialchars($medicine['medicineName']) . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="form-row">
                <label class="input-label">Notes</label>
                <div class="input-data">
                    <textarea name="notes" rows="4" required><?= htmlspecialchars($medicalRecord['notes']) ?></textarea>
                </div>
            </div>
            <div class="form-row">
                <label class="input-label">Diagnosis</label>
                <div class="input-data">
                    <textarea name="diagnosis" rows="4" required><?= htmlspecialchars($medicalRecord['diagnosis']) ?></textarea>
                </div>
            </div>
            <div class="form-row submit-btn">
                <input type="submit" value="Update Medical Record" class="btn">
                <a href="adGeneratePayment.php">Back</a>
            </div>
        </form>
    </div>
</body>

</html>

<script>
    new MultiSelectTag('medicineName') // id
</script>