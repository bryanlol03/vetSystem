<?php
include '../_base.php';
include '../helper/docHeader.php';
$patients = []; // Initialize an empty array for patients
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $appointmentID = htmlspecialchars($_GET['id']); // Retrieve and sanitize the ID

    // Query the database to get details for the given appointment ID
    $stmt = $_db->prepare("SELECT * FROM appointment WHERE appointmentID = ?");
    $stmt->execute([$appointmentID]);
    $appointmentDetails = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($appointmentDetails) {
        // Use petName from appointment details to fetch pet information
        if (isset($appointmentDetails['petName']) && !empty($appointmentDetails['petName'])) {
            $petStmt = $_db->prepare("SELECT * FROM pet WHERE name = ?");
            $petStmt->execute([$appointmentDetails['petName']]);
            $petDetails = $petStmt->fetch(PDO::FETCH_ASSOC);

            if ($petDetails) {
                // Add pet details to the patients array for dynamic display
                $patients[] = [
                    'petID' => $petDetails['petID'],  // Correctly fetch and use petID
                    'name' => $petDetails['name'],
                    'species' => $petDetails['species'],
                    'age' => $petDetails['age'],
                    'breed' => $petDetails['breed'],
                    'photo' => $petDetails['profilePhoto']
                ];
                $petID = $petDetails['petID']; // Assign petID for medical record usage
            } else {
                echo "<p>No pet details found for the pet name: " . htmlspecialchars($appointmentDetails['petName']) . "</p>";
            }
        } else {
            echo "<p>Pet Name not found in this appointment record.</p>";
        }
    } else {
        echo "<p>No appointment details found for the provided ID.</p>";
    }
} else {
    echo "<p>Invalid or missing appointment ID.</p>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $treatmentDate = date('Y-m-d'); // Set today's date
    $notes = !empty($_POST['notes']) ? $_POST['notes'] : '-';
    $diagnosis = !empty($_POST['diagnosis']) ? $_POST['diagnosis'] : '-';
    $serviceType = !empty($_POST['serviceType']) ? $_POST['serviceType'] : '-';
    $remarks = !empty($_POST['remarks']) ? $_POST['remarks'] : '-';
    $medicineName = !empty($_POST['medicineName']) ? $_POST['medicineName'] : '-';

    // Ensure $petName is coming from either the form or appointment details
    $petName = !empty($_POST['petName']) ? $_POST['petName'] : $appointmentDetails['petName'];

    // Fetch petID based on petName
    $petIDStmt = $_db->prepare("SELECT petID FROM pet WHERE name = ?");
    $petIDStmt->execute([$petName]);
    $petID = $petIDStmt->fetchColumn();

    if (!$petID) {
        echo "<p>Error: Pet ID not found for the provided Pet Name.</p>";
    } else {
        // Insert data into the medicalRecord table
        $stmt = $_db->prepare("
            INSERT INTO medicalRecord (date, notes, diagnosis, petID, serviceType, remarks, medicineName) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$treatmentDate, $notes, $diagnosis, $petID, $serviceType, $remarks, $medicineName]);

        if ($stmt) {
            echo "<p>Treatment record has been added successfully.</p>";
            echo "<script>window.location.href = 'docMedicineRecommend.php';</script>";
            exit();
        } else {
            echo "<p>Failed to add the treatment record.</p>";
        }
    }
}

$serviceTypes = [];
$stmt = $_db->prepare("SELECT serviceID, serviceName FROM service");
$stmt->execute();
$serviceTypes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Default selected service type from the appointment
$selectedServiceType = $appointmentDetails['serviceType'] ?? '';
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1; maximum-scale=1" />
    <link rel="stylesheet" href="../css/daterangepicker.css">
    <link rel="stylesheet" href="../css/select2.css">
    <link rel="stylesheet" href="../css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="../css/dashboard.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
</head>

<style>
    .button--back {
        background-color: #6c757d;
        color: #ffffff;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        text-decoration: none;
        display: inline-block;
        transition: background-color 0.3s ease;
        margin-top: 10px;
    }

    .button--back:hover {
        background-color: #5a6268;
    }

    body {
        font-family: 'Roboto', sans-serif;
    }

    textarea {
        width: 100%;
        height: 150px;
        padding: 15px;
        box-sizing: border-box;
        border: 1px solid #ddd;
        border-radius: 8px;
        background-color: #f9f9f9;
        font-size: 16px;
        font-family: 'Roboto', sans-serif;
        resize: vertical;
        transition: border-color 0.3s ease;
    }

    textarea:focus {
        border-color: #007BFF;
        outline: none;
        background-color: #ffffff;
    }

    .form__label {
        font-weight: 500;
        font-size: 14px;
        color: #333;
        margin-bottom: 8px;
        display: inline-block;
    }

    .button--submit {
        background-color: #007BFF;
        color: #ffffff;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .button--submit:hover {
        background-color: #0056b3;
    }

    .grid__col {
        margin-bottom: 15px;
    }

    .grid__row {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
    }

    .grid__col--half {
        flex: 1;
        min-width: 300px;
    }
</style>

<body>
    <div class="grid grid--margin bg-white">
        <div class="grid__row">
            <div class="grid__col grid__col--padding">
                <h3 class="grid__col-title">Patient Details</h3>

                <div class="patient-details">
                    <?php if (!empty($patients)) : ?>
                        <?php foreach ($patients as $index => $patient) : ?>
                            <div class="patient-card" id="patient-<?php echo $index; ?>" style="display: <?php echo $index === 0 ? 'block' : 'none'; ?>">
                                <img src="../img/petPhoto/<?php echo htmlspecialchars($patient['photo']); ?>" alt="Pet Photo">
                                <p><strong>Name:</strong> <?php echo htmlspecialchars($patient['name']); ?></p>
                                <p><strong>ID:</strong> <?php echo htmlspecialchars($patient['petID']); ?></p>
                                <p><strong>Species:</strong> <?php echo htmlspecialchars($patient['species']); ?></p>
                                <p><strong>Age:</strong> <?php echo htmlspecialchars($patient['age']); ?> years</p>
                                <p><strong>Breed:</strong> <?php echo htmlspecialchars($patient['breed']); ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <p>No patient details available.</p>
                    <?php endif; ?>
                </div>

                <div class="pagination">
                    <?php foreach ($patients as $index => $patient) : ?>
                        <button onclick="showPatient(<?php echo $index; ?>)" class="<?php echo $index === 0 ? 'active' : ''; ?>"><?php echo $index + 1; ?></button>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="grid__row">
            <div class="grid__col grid__col--padding">
                <h3 class="grid__col-title">Treatment Form</h3>
                <form method="POST">
                    <div class="grid__row">
                        <div class="grid__col grid__col--half">
                            <label class="form__label">Date *</label>
                            <input type="text" name="date" class="form__input" value="<?php echo date('Y-m-d'); ?>" readonly />
                        </div>

                        <div class="grid__col grid__col--half">
                            <label class="form__label">Service Type *</label>
                            <select name="serviceType" class="custom-select" required>
                                <?php foreach ($serviceTypes as $service): ?>
                                    <option value="<?= htmlspecialchars($service['serviceName']) ?>"
                                        <?= $service['serviceName'] === $selectedServiceType ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($service['serviceName']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="grid__row">
                            <div class="grid__col grid__col--half">
                                <label class="form__label">Notes (Symptoms) *</label>
                                <textarea name="notes"></textarea>
                            </div>

                            <div class="grid__col grid__col--half">
                                <label class="form__label">Diagnosis *</label>
                                <textarea name="diagnosis"></textarea>
                            </div>
                        </div>

                        <div class="grid__row">
                            <div class="grid__col grid__col--full">
                                <label class="form__label">Remarks</label>
                                <textarea name="remarks"></textarea>
                            </div>
                        </div>

                        <div class="grid__row">
                            <div class="grid__col grid__col--margin">
                                <button type="submit" class="button button--submit button--blue-bg">Submit Treatment</button>
                            </div>
                            <a href="docAppointment.php" class="button--back">Back to Appointment</a>
                        </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showPatient(index) {
            $('.patient-card').hide();
            $('#patient-' + index).show();
            $('.pagination button').removeClass('active');
            $('.pagination button').eq(index).addClass('active');
        }
    </script>
</body>

</html>