<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/logo.png">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/petCareSystem.css">
    <title>Contact Us - Pet Care Management System</title>
</head>

<body>
    <?php include 'helper/header.php'; ?>

    <!-- Contact Us Section Start -->
    <section class="contact-us-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mb-4">
                    <h2 class="font-weight-bold mb-3">Get in Touch with Us</h2>
                    <p>If you have any questions or need more information, feel free to reach out to us. We're here to help you and your furry friends!</p>
                    <form action="" method="post" style="background: #f8f9fa; padding: 20px; border: 1px solid #ddd; border-radius: 5px;">
                        <div class="form-group">
                            <label for="name">Your Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                    <?php
                    require_once 'lib/PHPMailer.php';
                    require_once 'lib/SMTP.php';

                    // Handling form submission
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        $name = htmlspecialchars(strip_tags(trim($_POST['name'])));
                        $email = htmlspecialchars(strip_tags(trim($_POST['email'])));
                        $message = htmlspecialchars(strip_tags(trim($_POST['message'])));

                        $mail = get_mail();

                        try {
                            // Set email recipients and content
                            $mail->addAddress('petprocare123@gmail.com', 'Pet Pro Care');
                            $mail->addReplyTo($email, $name);
                            $mail->isHTML(true);
                            $mail->Subject = 'Contact Request from ' . $name;
                            $mail->Body = "
                                <p>Dear Admin,</p>
                                <h1 style='color: red'>Contact Request</h1>
                                <p><strong>Message:</strong> $message</p>
                                <p><strong>From:</strong> {$name} ({$email})</p>
                                <p>From, 😺 {$name}</p>
                            ";
                            $mail->AltBody = "Name: $name\nEmail: $email\n\nMessage:\n$message";

                            $mail->send();
                            echo "<div class='alert alert-success mt-3'>Thank you for contacting us, $name. We will get back to you shortly.</div>";
                        } catch (Exception $e) {
                            echo "<div class='alert alert-danger mt-3'>Oops! Something went wrong, and we couldn't send your message. Mailer Error: {$mail->ErrorInfo}</div>";
                        }
                    }
                    ?>
                </div>
                <div class="col-lg-6 mb-4">
                    <h2 class="font-weight-bold mb-3">Our Location</h2>
                    <p>Visit us at our clinic or find us on the map below:</p>
                    <div class="map-responsive">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8354345094076!2d144.95373531567853!3d-37.81627944202166!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0xf577d8e44eae7e33!2sVeterinary%20Clinic!5e0!3m2!1sen!2sus!4v1601234567890!5m2!1sen!2sus" width="100%" height="350" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                    </div>
                    <div class="mt-3">
                        <p><i class="fas fa-map-marker-alt text-primary mr-2"></i>123 Pet Street, Pet City, PC 12345</p>
                        <p><i class="fas fa-phone-alt text-primary mr-2"></i>+60 123456789</p>
                        <p><i class="fas fa-envelope text-primary mr-2"></i><a href="mailto:petprocare123@gmail.com" class="text-primary">petprocare123@gmail.com</a></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Us Section End -->

    <?php include 'helper/footer.php'; ?>

    <!-- Back to Top Button -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>

    <!-- Custom JavaScript -->
    <script>
        $(document).ready(function() {
            // Back to top button
            $(window).scroll(function() {
                if ($(this).scrollTop() > 100) {
                    $('.back-to-top').fadeIn();
                } else {
                    $('.back-to-top').fadeOut();
                }
            });
            $('.back-to-top').click(function() {
                $('html, body').animate({
                    scrollTop: 0
                }, 1000);
                return false;
            });
        });
    </script>
</body>

</html>
