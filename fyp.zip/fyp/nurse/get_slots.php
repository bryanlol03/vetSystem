<?php
include('../_base.php');

// Ensure the script receives the required parameters
if (isset($_GET['date']) && isset($_GET['staffID'])) {
    $selectedDate = $_GET['date'];
    $staffID = $_GET['staffID'];

    // Predefined time slots
    $timeSlots = ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"];

    $availableSlots = [];

    foreach ($timeSlots as $timeSlot) {
        // Check if the time slot is already booked
        $query = "
            SELECT COUNT(*) 
            FROM appointment 
            WHERE staffID = :staffID 
            AND date = :selectedDate 
            AND time = :timeSlot 
            AND status IN ('Pending', 'Accepted')
        ";
        $stmt = $_db->prepare($query);
        $stmt->execute([
            ':staffID' => $staffID,
            ':selectedDate' => $selectedDate,
            ':timeSlot' => $timeSlot,
        ]);

        // If the time slot is not booked, mark it as available
        if ($stmt->fetchColumn() == 0) {
            $availableSlots[] = $timeSlot;
        }
    }

    // Return the available slots as a JSON response
    echo json_encode($availableSlots);
} else {
    echo json_encode([]);
}
?>
