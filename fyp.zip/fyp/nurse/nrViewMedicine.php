<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Medicine</title>
    <link rel="icon" href="../img/logo.png">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #007bff;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #ffffff;
            margin: 20px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: #ffffff;
            text-transform: uppercase;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #e9f5ff;
        }
    </style>
</head>
<body>

<h1>Medicine List</h1>

<table>
    <thead>
        <tr>
            <th>Medicine Name</th>
            <th>Category</th>
            <th>Description</th>
            <th>Price</th>
            <th>Recommended Dosage</th>
        </tr>
    </thead>
    <tbody>
        <?php
        include_once '../_base.php'; // Ensures the database connection is included
       
        try {
            // Query to fetch medicine details
            $stmt = $_db->query("SELECT medicineName, medicineCategory, description, medicinePrice, recommendedDosage FROM medicine");

            // Loop through the results and display them
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['medicineName']) . "</td>";
                echo "<td>" . htmlspecialchars($row['medicineCategory']) . "</td>";
                echo "<td>" . htmlspecialchars($row['description']) . "</td>";
                echo "<td>" . htmlspecialchars($row['medicinePrice']) . "</td>";
                echo "<td>" . htmlspecialchars($row['recommendedDosage']) . "</td>";
                echo "</tr>";
            }
        } catch (PDOException $e) {
            echo "<tr><td colspan='5'>Error: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
        }
        ?>
    </tbody>
</table>
<a href="nrDashBoard.php">Back</a>
</body>
</html>
