<?php
// Start output buffering to prevent header issues
ob_start();

// Include the base connection and helper files
include_once '../_base.php';
include '../helper/nrHelper.php';

// Start the session if it hasn't already been started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Validate the request method and check for appointmentID
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['appointmentID'])) {
    $appointmentID = (int)$_POST['appointmentID']; // Ensure appointmentID is an integer

    try {
        // Fetch the current status of the appointment
        $stmt = $_db->prepare("SELECT status FROM appointment WHERE appointmentID = :appointmentID");
        $stmt->bindParam(':appointmentID', $appointmentID, PDO::PARAM_INT);
        $stmt->execute();
        $appointment = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if the appointment exists
        if ($appointment) {
            // Check if the appointment status is "Pending"
            if ($appointment['status'] === 'Pending') {
                // Update the status to "Accepted"
                $updateStmt = $_db->prepare("UPDATE appointment SET status = 'Accepted' WHERE appointmentID = :appointmentID");
                $updateStmt->bindParam(':appointmentID', $appointmentID, PDO::PARAM_INT);

                if ($updateStmt->execute()) {
                    // Success message
                    $_SESSION['success'] = "Appointment accepted successfully.";
                } else {
                    // Database execution failure
                    $_SESSION['error'] = "Failed to accept the appointment. Please try again later.";
                }
            } else {
                // The status is not "Pending"
                $_SESSION['error'] = "Appointment cannot be accepted as it is not in a pending status.";
            }
        } else {
            // Appointment not found
            $_SESSION['error'] = "Appointment not found.";
        }
    } catch (Exception $e) {
        // Handle any unexpected errors
        $_SESSION['error'] = "An error occurred: " . $e->getMessage();
    }

    // Redirect back to the appointment management page
    header("Location: nrMakeAppointment.php");
    exit();
} else {
    // If the request is not POST or appointmentID is missing
    $_SESSION['error'] = "Invalid request.";
    header("Location: nrMakeAppointment.php");
    exit();
}

// End output buffering and flush output
ob_end_flush();
